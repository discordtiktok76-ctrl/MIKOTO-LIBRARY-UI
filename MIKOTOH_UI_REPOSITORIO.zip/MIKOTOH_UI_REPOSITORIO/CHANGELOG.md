# Histórico

## 3.2.0 — 06/10/2026

- Recuperados os relevos: face, brilho interno e sombra inferior usam tons distintos de cada paleta.
- Preservados os pontos e a distribuição dos gradientes originais, inclusive o brilho dos textos.
- Sombras e contornos reforçados no cabeçalho, no botão de fechar, nos Toggles e nos Sliders.
- Cópia da paleta original fica imutável: a seleção das páginas não modifica as cores registradas.
- Restauração das propriedades alteradas pelo tema inclui suas opacidades, preservando valores e edição dos controles.
- Teste de todas as cores, opacidades e gradientes de Original após iniciar em cada tema e fazer trocas repetidas.

## 3.1.0 — 06/10/2026

- Corrigida a aplicação das cores em todas as páginas e camadas de seus botões.
- Seleção de página mantém o tema escolhido e recebe destaque próprio.
- Paletas personalizadas com fundos discretos, bordas suaves, texto claro e gradientes menos intensos.
- Páginas, seções e controles criados depois de escolher o tema recebem a mesma paleta.
- Espaço entre os botões das páginas, com ajuste de altura em janelas pequenas.
- A imagem por ID ocupa todo o botão de abrir/fechar, com recorte proporcional e formato redondo ou quadrado.
- Teste completo inicia em Dark; regressões visuais cobertas por testes de propriedades.

## 3.0.0 — 06/10/2026

- Páginas criadas pelo usuário, com limite fixo de cinco incluindo a principal.
- `CreateTab`, `SelectTab`, `GetTab`, `GetTabs`, `GetTabCount` e exclusão de páginas secundárias.
- Dez temas: Dark, Original, Rose, Roxo, Verde, VermelhoEscuro, Azul, Preto, Lilas e Dourado.
- Button de ação usando o construtor visual original da Chilli, com `Press()`.
- Botão de abrir/fechar com posição, ID de imagem, tamanho, arraste e formato configuráveis.
- Exemplo com seleção visual de todos os temas.
- Documentação de API, exemplos para Studio e testes locais portáveis.

## 2.0.0 — 06/10/2026

- Substituição da interface redesenhada por trechos da estrutura visual original da Chilli.
- Toggle, Slider, seções e página principal sem páginas automáticas.
