# Origem dos componentes

Esta biblioteca contém trechos dos construtores visuais do arquivo legível **Chilli Library 3.22.0**, consultado em 06/10/2026.

Fonte de referência:

- https://github.com/tienkhanh1/spicy
- https://raw.githubusercontent.com/tienkhanh1/spicy/main/Chilli%20Library

A implementação visual de base permanece atribuída ao projeto Chilli. A API adaptada, os limites, a configuração do botão flutuante, os temas, a documentação e a validação local são alterações desta edição MIKOTOH.

A edição não incorpora o ChilliLibraryEngine ofuscado. Este arquivo registra atribuição de origem; não atribui uma nova licença ao código de terceiros.
