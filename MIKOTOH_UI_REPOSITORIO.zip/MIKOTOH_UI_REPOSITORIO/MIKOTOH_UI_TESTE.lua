-- TESTE COMPLETO CORRIGIDO: estrutura visual da Chilli.
local UI = (function()
-- MIKOTOH UI 3.2 — componentes da estrutura VISUAL original da Chilli.
-- Fonte visual: Chilli Library 3.22.0, arquivo visivel consultado em 06/10/2026.
-- Construtores originais de toggle, slider, linhas, fontes e botoes preservados.
-- API: ate 5 paginas, secoes, Toggle, Slider, Button, 10 temas e botao de abrir/fechar.
-- Sem ChilliLibraryEngine, HttpGet, chaves ou paginas automaticas.
-- Theme="Original" preserva a paleta original. Consulte UI:GetThemes().
local MAX_TABS = 5
local THEME_NAMES = {"Dark", "Original", "Rose", "Roxo", "Verde",
    "VermelhoEscuro", "Azul", "Preto", "Lilas", "Dourado"}
local function resolveThemeName(name)
    local key = string.lower(tostring(name or "Original")):gsub("[%s_%-]", "")
    local aliases = {dark="Dark", original="Original", rose="Rose", ["rosé"]="Rose",
        roxo="Roxo", purple="Roxo", verde="Verde", green="Verde",
        vermelhoescuro="VermelhoEscuro", darkred="VermelhoEscuro",
        azul="Azul", blue="Azul", preto="Preto", black="Preto",
        lilas="Lilas", ["lilás"]="Lilas", lilac="Lilas", dourado="Dourado", gold="Dourado"}
    assert(aliases[key], "Tema invalido. Consulte UI:GetThemes().")
    return aliases[key]
end
local function normalizeImageId(value)
    if value == nil or value == "" or value == 0 then return "" end
    local str = tostring(value)
    if str:match("^%d+$") then return "rbxassetid://" .. str end
    assert(str:match("^rbxassetid://%d+$") or str:match("^rbxasset://"),
        "Image deve ser um ID numerico ou rbxassetid://ID.")
    return str
end
local function normalizeOpenOptions(options, previous)
    assert(options == nil or type(options) == "table", "OpenButton deve ser uma tabela.")
    local result = {
        Enabled=true, Position=UDim2.fromScale(0.08, 0.5), Size=54,
        Draggable=true, Shape="Round", Image="", Text="M",
    }
    for key, value in pairs(previous or {}) do result[key] = value end
    for key, value in pairs(options or {}) do result[key] = value end
    local rawImage = result.Image
    if options and options.ImageId ~= nil then rawImage = options.ImageId end
    if options and options.Id ~= nil then rawImage = options.Id end
    result.Image = normalizeImageId(rawImage)
    result.ImageId, result.Id = nil, nil
    assert(typeof(result.Position) == "UDim2", "Position deve ser UDim2.")
    local size = tonumber(result.Size)
    assert(size and size == size and size ~= math.huge and size ~= -math.huge, "Size deve ser um numero finito.")
    result.Size = math.clamp(math.floor(size + 0.5), 32, 160)
    local shape = string.lower(tostring(result.Shape))
    if shape == "round" or shape == "circle" or shape == "redondo" then result.Shape = "Round"
    elseif shape == "square" or shape == "quadrado" then result.Shape = "Square"
    else error("Shape deve ser Round ou Square.", 3) end
    assert(type(result.Enabled) == "boolean" and type(result.Draggable) == "boolean",
        "Enabled e Draggable devem ser booleanos.")
    result.Text = tostring(result.Text or "M")
    return result
end

local function buildOriginal(config)
local player = game:GetService("Players").LocalPlayer
local CoreGui = game:GetService("CoreGui")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local GuiService = game:GetService("GuiService")
local camera = workspace.CurrentCamera
assert(player, "ChilliLibrary chi co the chay mot lan o phia client")
local playerGui = player:WaitForChild("PlayerGui")

local ROOT_GUI_NAME = "MIKOTOH_ChilliUI"
local LAUNCHER_GUI_NAME = "MIKOTOH_ChilliLauncher"
local OWNER_ATTRIBUTE = "MIKOTOHChilliOwned"
local parent = config.Parent or CoreGui
local parentName = "CoreGui"
do
    local hiddenOk, hiddenParent = pcall(function()
        return gethui()
    end)
    if not config.Parent and hiddenOk and typeof(hiddenParent) == "Instance" then
        parent = hiddenParent
        parentName = "HiddenUI"
    end

    local ok, problem = pcall(function()
        local probe = Instance.new("ScreenGui")
        probe.Name = "ChilliLibraryUIProbe"
        probe.Parent = parent
        probe:Destroy()
    end)
    if not ok then
        parent = config.Parent or playerGui
    end
end

local function createEmbeddedSpider()
    local spider = Instance.new("MeshPart")
    spider.Name = "Spider"
    spider.Archivable = true
    spider.Anchored = true
    spider.BackSurface = Enum.SurfaceType.Smooth
    spider.BottomSurface = Enum.SurfaceType.Smooth
    spider.BrickColor = BrickColor.new("Institutional white")
    spider.CanCollide = false
    spider.CanQuery = false
    spider.CanTouch = false
    spider.CastShadow = true
    spider.Color = Color3.new(1, 1, 1)
    spider.FrontSurface = Enum.SurfaceType.Smooth
    spider.LeftSurface = Enum.SurfaceType.Smooth
    spider.Massless = true
    spider.Material = Enum.Material.Plastic
    spider.Reflectance = 0
    spider.RightSurface = Enum.SurfaceType.Smooth
    spider.RootPriority = -5
    spider.Size = Vector3.new(
        0.9052265286445618,
        0.24434703588485718,
        0.9125359058380127
    )
    spider.TopSurface = Enum.SurfaceType.Smooth
    spider.Transparency = 0
    spider.MeshId = "rbxassetid://135715081992798"
    spider.TextureID = ""
    spider.DoubleSided = false
    spider.RenderFidelity = Enum.RenderFidelity.Automatic
    spider.CollisionFidelity = Enum.CollisionFidelity.Box
    spider.CFrame = CFrame.new()

    local headAttachment = Instance.new("Attachment")
    headAttachment.Name = "HeadAttachment"
    headAttachment.CFrame = CFrame.new(
        0.72625732421875,
        -0.504150390625,
        0.3289794921875,
        0.7071012258529663,
        -0.7068588733673096,
        -0.01893438585102558,
        -0.000011771917343139648,
        0.026765286922454834,
        -0.9996418952941895,
        0.7071123719215393,
        0.70684814453125,
        0.018917446956038475
    )
    headAttachment.Parent = spider

    return spider
end



local cleanupNames = {
    [ROOT_GUI_NAME] = true,
    [LAUNCHER_GUI_NAME] = true,
}
local function cleanupOldUiScreens(excludedRoot, excludedLauncher)
    for _, old in ipairs(parent:GetChildren()) do
        if old ~= excludedRoot
            and old ~= excludedLauncher
            and old:IsA("ScreenGui")
            and cleanupNames[old.Name]
        then
            local restorePosition = old:GetAttribute(
                "HudRestorePosition"
            )
            local hiddenByLibrary = old:GetAttribute(
                "LeftCenterHiddenByLibrary"
            ) == true
            local screenDisabledByLibrary = old:GetAttribute(
                "LeftCenterScreenDisabledByLibrary"
            ) == true
            if typeof(restorePosition) == "UDim2"
                or hiddenByLibrary
                or screenDisabledByLibrary
            then
                local oldLeftCenterScreen = playerGui:FindFirstChild(
                    "LeftCenter"
                )
                local oldLeftCenter = oldLeftCenterScreen
                    and oldLeftCenterScreen:FindFirstChild("LeftCenter")
                if oldLeftCenter then
                    if typeof(restorePosition) == "UDim2" then
                        while restorePosition.X.Scale <= -0.5 do
                            restorePosition = UDim2.new(
                                restorePosition.X.Scale + 1,
                                restorePosition.X.Offset,
                                restorePosition.Y.Scale,
                                restorePosition.Y.Offset
                            )
                        end
                        oldLeftCenter.Position = restorePosition
                    end
                    if hiddenByLibrary then
                        oldLeftCenter.Visible = true
                    end
                end
                if screenDisabledByLibrary
                    and oldLeftCenterScreen
                    and oldLeftCenterScreen:IsA("ScreenGui")
                then
                    oldLeftCenterScreen.Enabled = true
                end
            end
            old:Destroy()
        end
    end
end
cleanupOldUiScreens()




local function chilliSetProperty(instance, key, value)
    instance[key] = value
end
local objects = {}

objects.obj1 = Instance.new("ScreenGui")
pcall(chilliSetProperty, objects.obj1, "Name", ROOT_GUI_NAME)
pcall(chilliSetProperty, objects.obj1, "Archivable", true)
objects.obj1:SetAttribute("MenuSize", UDim2.new(0.44999998807907104,0,0.550000011920929,0))
objects.obj1:SetAttribute(OWNER_ATTRIBUTE, true)
objects.obj1.Parent = parent

objects.obj2 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj2, "Name", "Frame")
pcall(chilliSetProperty, objects.obj2, "Archivable", true)
pcall(chilliSetProperty, objects.obj2, "Visible", true)
pcall(chilliSetProperty, objects.obj2, "Active", false)
pcall(chilliSetProperty, objects.obj2, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj2, "BackgroundColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj2, "BackgroundTransparency", 0.4000000059604645)
pcall(chilliSetProperty, objects.obj2, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj2, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj2, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj2, "Position", UDim2.new(0.5,0,0.4749999940395355,0))
pcall(chilliSetProperty, objects.obj2, "Rotation", 0)
pcall(chilliSetProperty, objects.obj2, "Selectable", false)
pcall(chilliSetProperty, objects.obj2, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj2, "Size", UDim2.new(0.44999998807907104,0,0.550000011920929,0))
pcall(chilliSetProperty, objects.obj2, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj2, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj2, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj2, "LayoutOrder", 0)
objects.obj2.Parent = objects.obj1

objects.obj3 = Instance.new("UIStroke")
pcall(chilliSetProperty, objects.obj3, "Name", "UIStroke")
pcall(chilliSetProperty, objects.obj3, "Archivable", true)
pcall(chilliSetProperty, objects.obj3, "ApplyStrokeMode", Enum.ApplyStrokeMode.Border)
pcall(chilliSetProperty, objects.obj3, "Color", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj3, "Enabled", true)
pcall(chilliSetProperty, objects.obj3, "LineJoinMode", Enum.LineJoinMode.Round)
pcall(chilliSetProperty, objects.obj3, "Thickness", 0.00800000037997961)
pcall(chilliSetProperty, objects.obj3, "Transparency", 0)
objects.obj3.Parent = objects.obj2

objects.obj4 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj4, "Name", "Top")
pcall(chilliSetProperty, objects.obj4, "Archivable", true)
pcall(chilliSetProperty, objects.obj4, "Visible", true)
pcall(chilliSetProperty, objects.obj4, "Active", false)
pcall(chilliSetProperty, objects.obj4, "AnchorPoint", Vector2.new(0.5,0))
pcall(chilliSetProperty, objects.obj4, "BackgroundColor3", Color3.fromRGB(111,0,2))
pcall(chilliSetProperty, objects.obj4, "BackgroundTransparency", 0)
pcall(chilliSetProperty, objects.obj4, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj4, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj4, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj4, "Position", UDim2.new(0.5,0,0,0))
pcall(chilliSetProperty, objects.obj4, "Rotation", 0)
pcall(chilliSetProperty, objects.obj4, "Selectable", false)
pcall(chilliSetProperty, objects.obj4, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj4, "Size", UDim2.new(1,0,0.13500000536441803,0))
pcall(chilliSetProperty, objects.obj4, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj4, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj4, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj4, "LayoutOrder", 0)
objects.obj4.Parent = objects.obj2

objects.obj5 = Instance.new("UIStroke")
pcall(chilliSetProperty, objects.obj5, "Name", "UIStroke")
pcall(chilliSetProperty, objects.obj5, "Archivable", true)
pcall(chilliSetProperty, objects.obj5, "ApplyStrokeMode", Enum.ApplyStrokeMode.Border)
pcall(chilliSetProperty, objects.obj5, "Color", Color3.fromRGB(58,0,0))
pcall(chilliSetProperty, objects.obj5, "Enabled", true)
pcall(chilliSetProperty, objects.obj5, "LineJoinMode", Enum.LineJoinMode.Round)
pcall(chilliSetProperty, objects.obj5, "Thickness", 0.05999999865889549)
pcall(chilliSetProperty, objects.obj5, "Transparency", 0)
objects.obj5.Parent = objects.obj4

objects.obj6 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj6, "Name", "Color")
pcall(chilliSetProperty, objects.obj6, "Archivable", true)
pcall(chilliSetProperty, objects.obj6, "Visible", true)
pcall(chilliSetProperty, objects.obj6, "Active", false)
pcall(chilliSetProperty, objects.obj6, "AnchorPoint", Vector2.new(0.5,0))
pcall(chilliSetProperty, objects.obj6, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj6, "BackgroundTransparency", 0)
pcall(chilliSetProperty, objects.obj6, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj6, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj6, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj6, "Position", UDim2.new(0.5,0,0,0))
pcall(chilliSetProperty, objects.obj6, "Rotation", 0)
pcall(chilliSetProperty, objects.obj6, "Selectable", false)
pcall(chilliSetProperty, objects.obj6, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj6, "Size", UDim2.new(1,0,0.8799999952316284,0))
pcall(chilliSetProperty, objects.obj6, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj6, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj6, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj6, "LayoutOrder", 0)
objects.obj6.Parent = objects.obj4

objects.obj7 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj7, "Name", "Transparent")
pcall(chilliSetProperty, objects.obj7, "Archivable", true)
pcall(chilliSetProperty, objects.obj7, "Visible", true)
pcall(chilliSetProperty, objects.obj7, "Active", false)
pcall(chilliSetProperty, objects.obj7, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj7, "BackgroundColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj7, "BackgroundTransparency", 0.8999999761581421)
pcall(chilliSetProperty, objects.obj7, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj7, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj7, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj7, "Position", UDim2.new(0.5,0,0.5,0))
pcall(chilliSetProperty, objects.obj7, "Rotation", 0)
pcall(chilliSetProperty, objects.obj7, "Selectable", false)
pcall(chilliSetProperty, objects.obj7, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj7, "Size", UDim2.new(0.9879999756813049,0,0.8700000047683716,0))
pcall(chilliSetProperty, objects.obj7, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj7, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj7, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj7, "LayoutOrder", 0)
objects.obj7.Parent = objects.obj6

objects.obj8 = Instance.new("ImageLabel")
pcall(chilliSetProperty, objects.obj8, "Name", "Pattern")
pcall(chilliSetProperty, objects.obj8, "Archivable", true)
pcall(chilliSetProperty, objects.obj8, "Visible", true)
pcall(chilliSetProperty, objects.obj8, "Active", false)
pcall(chilliSetProperty, objects.obj8, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj8, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj8, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj8, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj8, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj8, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj8, "Position", UDim2.new(0.5,0,0.5,0))
pcall(chilliSetProperty, objects.obj8, "Rotation", 0)
pcall(chilliSetProperty, objects.obj8, "Selectable", false)
pcall(chilliSetProperty, objects.obj8, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj8, "Size", UDim2.new(1,0,1,0))
pcall(chilliSetProperty, objects.obj8, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj8, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj8, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj8, "LayoutOrder", 0)
pcall(chilliSetProperty, objects.obj8, "Image", "")
pcall(chilliSetProperty, objects.obj8, "ImageColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj8, "ImageTransparency", 0.5)
pcall(chilliSetProperty, objects.obj8, "ScaleType", Enum.ScaleType.Tile)
pcall(chilliSetProperty, objects.obj8, "SliceCenter", Rect.new(0,0,0,0))
pcall(chilliSetProperty, objects.obj8, "SliceScale", 1)
pcall(chilliSetProperty, objects.obj8, "TileSize", UDim2.new(0.15000000596046448,0,2,0))
pcall(chilliSetProperty, objects.obj8, "ResampleMode", Enum.ResamplerMode.Default)
objects.obj8.Parent = objects.obj7

objects.obj9 = Instance.new("TextLabel")
pcall(chilliSetProperty, objects.obj9, "Name", "Label")
pcall(chilliSetProperty, objects.obj9, "Archivable", true)
pcall(chilliSetProperty, objects.obj9, "Visible", true)
pcall(chilliSetProperty, objects.obj9, "Active", false)
pcall(chilliSetProperty, objects.obj9, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj9, "BackgroundColor3", Color3.fromRGB(239,220,203))
pcall(chilliSetProperty, objects.obj9, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj9, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj9, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj9, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj9, "Position", UDim2.new(0.5687711238861084,0,0.5,0))
pcall(chilliSetProperty, objects.obj9, "Rotation", 0)
pcall(chilliSetProperty, objects.obj9, "Selectable", false)
pcall(chilliSetProperty, objects.obj9, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj9, "Size", UDim2.new(0.8620089292526245,0,0.7499999403953552,0))
pcall(chilliSetProperty, objects.obj9, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj9, "ZIndex", 6)
pcall(chilliSetProperty, objects.obj9, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj9, "LayoutOrder", 0)
pcall(chilliSetProperty, objects.obj9, "Text", "Chilli Hub")
pcall(chilliSetProperty, objects.obj9, "TextColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj9, "TextTransparency", 0)
pcall(chilliSetProperty, objects.obj9, "TextStrokeColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj9, "TextStrokeTransparency", 1)
pcall(chilliSetProperty, objects.obj9, "TextSize", 14)
pcall(chilliSetProperty, objects.obj9, "TextScaled", true)
pcall(chilliSetProperty, objects.obj9, "TextWrapped", true)
pcall(chilliSetProperty, objects.obj9, "TextXAlignment", Enum.TextXAlignment.Left)
pcall(chilliSetProperty, objects.obj9, "TextYAlignment", Enum.TextYAlignment.Center)
pcall(chilliSetProperty, objects.obj9, "Font", Enum.Font.FredokaOne)
pcall(chilliSetProperty, objects.obj9, "RichText", false)
pcall(chilliSetProperty, objects.obj9, "LineHeight", 1)
pcall(chilliSetProperty, objects.obj9, "MaxVisibleGraphemes", -1)
objects.obj9.Parent = objects.obj6

objects.obj10 = Instance.new("UIStroke")
pcall(chilliSetProperty, objects.obj10, "Name", "UIStroke")
pcall(chilliSetProperty, objects.obj10, "Archivable", true)
pcall(chilliSetProperty, objects.obj10, "ApplyStrokeMode", Enum.ApplyStrokeMode.Contextual)
pcall(chilliSetProperty, objects.obj10, "Color", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj10, "Enabled", true)
pcall(chilliSetProperty, objects.obj10, "LineJoinMode", Enum.LineJoinMode.Round)
pcall(chilliSetProperty, objects.obj10, "Thickness", 0.07999999821186066)
pcall(chilliSetProperty, objects.obj10, "Transparency", 0)
objects.obj10.Parent = objects.obj9

objects.obj11 = Instance.new("UIGradient")
pcall(chilliSetProperty, objects.obj11, "Name", "UIGradient")
pcall(chilliSetProperty, objects.obj11, "Archivable", true)
pcall(chilliSetProperty, objects.obj11, "Color", ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(253,86,89)),ColorSequenceKeypoint.new(1,Color3.fromRGB(255,11,15))}))
pcall(chilliSetProperty, objects.obj11, "Enabled", true)
pcall(chilliSetProperty, objects.obj11, "Offset", Vector2.new(0,0))
pcall(chilliSetProperty, objects.obj11, "Rotation", 90)
pcall(chilliSetProperty, objects.obj11, "Transparency", NumberSequence.new({NumberSequenceKeypoint.new(0,0,0),NumberSequenceKeypoint.new(1,0,0)}))
objects.obj11.Parent = objects.obj6

objects.obj12 = Instance.new("ImageLabel")
pcall(chilliSetProperty, objects.obj12, "Name", "Icon")
pcall(chilliSetProperty, objects.obj12, "Archivable", true)
pcall(chilliSetProperty, objects.obj12, "Visible", true)
pcall(chilliSetProperty, objects.obj12, "Active", false)
pcall(chilliSetProperty, objects.obj12, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj12, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj12, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj12, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj12, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj12, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj12, "Position", UDim2.new(0.06700000166893005,0,0.44999998807907104,0))
pcall(chilliSetProperty, objects.obj12, "Rotation", 0)
pcall(chilliSetProperty, objects.obj12, "Selectable", false)
pcall(chilliSetProperty, objects.obj12, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj12, "Size", UDim2.new(0.11656716465950012,0,1.1833335161209106,0))
pcall(chilliSetProperty, objects.obj12, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj12, "ZIndex", 4)
pcall(chilliSetProperty, objects.obj12, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj12, "LayoutOrder", 0)
pcall(chilliSetProperty, objects.obj12, "Image", "")
pcall(chilliSetProperty, objects.obj12, "ImageColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj12, "ImageTransparency", 0)
pcall(chilliSetProperty, objects.obj12, "ScaleType", Enum.ScaleType.Fit)
pcall(chilliSetProperty, objects.obj12, "SliceCenter", Rect.new(0,0,0,0))
pcall(chilliSetProperty, objects.obj12, "SliceScale", 1)
pcall(chilliSetProperty, objects.obj12, "TileSize", UDim2.new(0,60,0,60))
pcall(chilliSetProperty, objects.obj12, "ResampleMode", Enum.ResamplerMode.Default)
objects.obj12.Parent = objects.obj4

objects.obj13 = Instance.new("UIAspectRatioConstraint")
pcall(chilliSetProperty, objects.obj13, "Name", "UIAspectRatioConstraint")
pcall(chilliSetProperty, objects.obj13, "Archivable", true)
pcall(chilliSetProperty, objects.obj13, "AspectRatio", 1)
pcall(chilliSetProperty, objects.obj13, "AspectType", Enum.AspectType.FitWithinMaxSize)
pcall(chilliSetProperty, objects.obj13, "DominantAxis", Enum.DominantAxis.Width)
objects.obj13.Parent = objects.obj12

objects.obj14 = Instance.new("TextButton")
pcall(chilliSetProperty, objects.obj14, "Name", "Close")
pcall(chilliSetProperty, objects.obj14, "Archivable", true)
pcall(chilliSetProperty, objects.obj14, "Visible", true)
pcall(chilliSetProperty, objects.obj14, "Active", true)
pcall(chilliSetProperty, objects.obj14, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj14, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj14, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj14, "BorderColor3", Color3.fromRGB(27,42,53))
pcall(chilliSetProperty, objects.obj14, "BorderSizePixel", 1)
pcall(chilliSetProperty, objects.obj14, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj14, "Position", UDim2.new(0.9549999833106995,0,0.4339999854564667,0))
pcall(chilliSetProperty, objects.obj14, "Rotation", 0)
pcall(chilliSetProperty, objects.obj14, "Selectable", true)
pcall(chilliSetProperty, objects.obj14, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj14, "Size", UDim2.new(0.06637302041053772,0,0.6588137149810791,0))
pcall(chilliSetProperty, objects.obj14, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj14, "ZIndex", 99)
pcall(chilliSetProperty, objects.obj14, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj14, "LayoutOrder", 1)
pcall(chilliSetProperty, objects.obj14, "Text", "")
pcall(chilliSetProperty, objects.obj14, "TextColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj14, "TextTransparency", 0)
pcall(chilliSetProperty, objects.obj14, "TextStrokeColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj14, "TextStrokeTransparency", 1)
pcall(chilliSetProperty, objects.obj14, "TextSize", 14)
pcall(chilliSetProperty, objects.obj14, "TextScaled", false)
pcall(chilliSetProperty, objects.obj14, "TextWrapped", false)
pcall(chilliSetProperty, objects.obj14, "TextXAlignment", Enum.TextXAlignment.Center)
pcall(chilliSetProperty, objects.obj14, "TextYAlignment", Enum.TextYAlignment.Center)
pcall(chilliSetProperty, objects.obj14, "Font", Enum.Font.SourceSans)
pcall(chilliSetProperty, objects.obj14, "RichText", false)
pcall(chilliSetProperty, objects.obj14, "LineHeight", 1)
pcall(chilliSetProperty, objects.obj14, "AutoButtonColor", true)
pcall(chilliSetProperty, objects.obj14, "Modal", false)
objects.obj14.Parent = objects.obj4

objects.obj15 = Instance.new("UIAspectRatioConstraint")
pcall(chilliSetProperty, objects.obj15, "Name", "UIAspectRatioConstraint")
pcall(chilliSetProperty, objects.obj15, "Archivable", true)
pcall(chilliSetProperty, objects.obj15, "AspectRatio", 1)
pcall(chilliSetProperty, objects.obj15, "AspectType", Enum.AspectType.FitWithinMaxSize)
pcall(chilliSetProperty, objects.obj15, "DominantAxis", Enum.DominantAxis.Width)
objects.obj15.Parent = objects.obj14

objects.obj16 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj16, "Name", "Main")
pcall(chilliSetProperty, objects.obj16, "Archivable", true)
pcall(chilliSetProperty, objects.obj16, "Visible", true)
pcall(chilliSetProperty, objects.obj16, "Active", false)
pcall(chilliSetProperty, objects.obj16, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj16, "BackgroundColor3", Color3.fromRGB(126,0,0))
pcall(chilliSetProperty, objects.obj16, "BackgroundTransparency", 0)
pcall(chilliSetProperty, objects.obj16, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj16, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj16, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj16, "Position", UDim2.new(0.5,0,0.5,0))
pcall(chilliSetProperty, objects.obj16, "Rotation", 0)
pcall(chilliSetProperty, objects.obj16, "Selectable", false)
pcall(chilliSetProperty, objects.obj16, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj16, "Size", UDim2.new(1,0,1,0))
pcall(chilliSetProperty, objects.obj16, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj16, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj16, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj16, "LayoutOrder", 0)
objects.obj16.Parent = objects.obj14

objects.obj17 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj17, "Name", "Color")
pcall(chilliSetProperty, objects.obj17, "Archivable", true)
pcall(chilliSetProperty, objects.obj17, "Visible", true)
pcall(chilliSetProperty, objects.obj17, "Active", false)
pcall(chilliSetProperty, objects.obj17, "AnchorPoint", Vector2.new(0.5,0))
pcall(chilliSetProperty, objects.obj17, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj17, "BackgroundTransparency", 0)
pcall(chilliSetProperty, objects.obj17, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj17, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj17, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj17, "Position", UDim2.new(0.5,0,0,0))
pcall(chilliSetProperty, objects.obj17, "Rotation", 0)
pcall(chilliSetProperty, objects.obj17, "Selectable", false)
pcall(chilliSetProperty, objects.obj17, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj17, "Size", UDim2.new(1,0,0.8999999761581421,0))
pcall(chilliSetProperty, objects.obj17, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj17, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj17, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj17, "LayoutOrder", 0)
objects.obj17.Parent = objects.obj16

objects.obj18 = Instance.new("Frame")
pcall(chilliSetProperty, objects.obj18, "Name", "Transparent")
pcall(chilliSetProperty, objects.obj18, "Archivable", true)
pcall(chilliSetProperty, objects.obj18, "Visible", true)
pcall(chilliSetProperty, objects.obj18, "Active", false)
pcall(chilliSetProperty, objects.obj18, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj18, "BackgroundColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj18, "BackgroundTransparency", 0.8999999761581421)
pcall(chilliSetProperty, objects.obj18, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj18, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj18, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj18, "Position", UDim2.new(0.5,0,0.5,0))
pcall(chilliSetProperty, objects.obj18, "Rotation", 0)
pcall(chilliSetProperty, objects.obj18, "Selectable", false)
pcall(chilliSetProperty, objects.obj18, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj18, "Size", UDim2.new(0.9599999785423279,0,0.8799999952316284,0))
pcall(chilliSetProperty, objects.obj18, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj18, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj18, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj18, "LayoutOrder", 0)
objects.obj18.Parent = objects.obj17

objects.obj19 = Instance.new("ImageLabel")
pcall(chilliSetProperty, objects.obj19, "Name", "Pattern")
pcall(chilliSetProperty, objects.obj19, "Archivable", true)
pcall(chilliSetProperty, objects.obj19, "Visible", true)
pcall(chilliSetProperty, objects.obj19, "Active", false)
pcall(chilliSetProperty, objects.obj19, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj19, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj19, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj19, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj19, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj19, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj19, "Position", UDim2.new(0.5,0,0.5,0))
pcall(chilliSetProperty, objects.obj19, "Rotation", 0)
pcall(chilliSetProperty, objects.obj19, "Selectable", false)
pcall(chilliSetProperty, objects.obj19, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj19, "Size", UDim2.new(1,0,1,0))
pcall(chilliSetProperty, objects.obj19, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj19, "ZIndex", 1)
pcall(chilliSetProperty, objects.obj19, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj19, "LayoutOrder", 0)
pcall(chilliSetProperty, objects.obj19, "Image", "")
pcall(chilliSetProperty, objects.obj19, "ImageColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj19, "ImageTransparency", 0.5)
pcall(chilliSetProperty, objects.obj19, "ScaleType", Enum.ScaleType.Tile)
pcall(chilliSetProperty, objects.obj19, "SliceCenter", Rect.new(0,0,0,0))
pcall(chilliSetProperty, objects.obj19, "SliceScale", 1)
pcall(chilliSetProperty, objects.obj19, "TileSize", UDim2.new(2,0,2,0))
pcall(chilliSetProperty, objects.obj19, "ResampleMode", Enum.ResamplerMode.Default)
objects.obj19.Parent = objects.obj18

objects.obj20 = Instance.new("TextLabel")
pcall(chilliSetProperty, objects.obj20, "Name", "Label")
pcall(chilliSetProperty, objects.obj20, "Archivable", true)
pcall(chilliSetProperty, objects.obj20, "Visible", true)
pcall(chilliSetProperty, objects.obj20, "Active", false)
pcall(chilliSetProperty, objects.obj20, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj20, "BackgroundColor3", Color3.fromRGB(239,220,203))
pcall(chilliSetProperty, objects.obj20, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj20, "BorderColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj20, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj20, "ClipsDescendants", false)
pcall(chilliSetProperty, objects.obj20, "Position", UDim2.new(0.5,0,0.5,0))
pcall(chilliSetProperty, objects.obj20, "Rotation", 0)
pcall(chilliSetProperty, objects.obj20, "Selectable", false)
pcall(chilliSetProperty, objects.obj20, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj20, "Size", UDim2.new(0.949999988079071,0,0.800000011920929,0))
pcall(chilliSetProperty, objects.obj20, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj20, "ZIndex", 6)
pcall(chilliSetProperty, objects.obj20, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj20, "LayoutOrder", 0)
pcall(chilliSetProperty, objects.obj20, "Text", "X")
pcall(chilliSetProperty, objects.obj20, "TextColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj20, "TextTransparency", 0)
pcall(chilliSetProperty, objects.obj20, "TextStrokeColor3", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj20, "TextStrokeTransparency", 1)
pcall(chilliSetProperty, objects.obj20, "TextSize", 14)
pcall(chilliSetProperty, objects.obj20, "TextScaled", true)
pcall(chilliSetProperty, objects.obj20, "TextWrapped", true)
pcall(chilliSetProperty, objects.obj20, "TextXAlignment", Enum.TextXAlignment.Center)
pcall(chilliSetProperty, objects.obj20, "TextYAlignment", Enum.TextYAlignment.Center)
pcall(chilliSetProperty, objects.obj20, "Font", Enum.Font.FredokaOne)
pcall(chilliSetProperty, objects.obj20, "RichText", false)
pcall(chilliSetProperty, objects.obj20, "LineHeight", 1)
pcall(chilliSetProperty, objects.obj20, "MaxVisibleGraphemes", -1)
objects.obj20.Parent = objects.obj17

objects.obj21 = Instance.new("UIStroke")
pcall(chilliSetProperty, objects.obj21, "Name", "UIStroke")
pcall(chilliSetProperty, objects.obj21, "Archivable", true)
pcall(chilliSetProperty, objects.obj21, "ApplyStrokeMode", Enum.ApplyStrokeMode.Contextual)
pcall(chilliSetProperty, objects.obj21, "Color", Color3.fromRGB(0,0,0))
pcall(chilliSetProperty, objects.obj21, "Enabled", true)
pcall(chilliSetProperty, objects.obj21, "LineJoinMode", Enum.LineJoinMode.Round)
pcall(chilliSetProperty, objects.obj21, "Thickness", 0.10999999940395355)
pcall(chilliSetProperty, objects.obj21, "Transparency", 0)
objects.obj21.Parent = objects.obj20

objects.obj22 = Instance.new("UIGradient")
pcall(chilliSetProperty, objects.obj22, "Name", "UIGradient")
pcall(chilliSetProperty, objects.obj22, "Archivable", true)
pcall(chilliSetProperty, objects.obj22, "Color", ColorSequence.new({ColorSequenceKeypoint.new(0,Color3.fromRGB(255,130,130)),ColorSequenceKeypoint.new(1,Color3.fromRGB(239,28,28))}))
pcall(chilliSetProperty, objects.obj22, "Enabled", true)
pcall(chilliSetProperty, objects.obj22, "Offset", Vector2.new(0,0))
pcall(chilliSetProperty, objects.obj22, "Rotation", 90)
pcall(chilliSetProperty, objects.obj22, "Transparency", NumberSequence.new({NumberSequenceKeypoint.new(0,0,0),NumberSequenceKeypoint.new(1,0,0)}))
objects.obj22.Parent = objects.obj17

objects.obj23 = Instance.new("UIStroke")
pcall(chilliSetProperty, objects.obj23, "Name", "UIStroke")
pcall(chilliSetProperty, objects.obj23, "Archivable", true)
pcall(chilliSetProperty, objects.obj23, "ApplyStrokeMode", Enum.ApplyStrokeMode.Border)
pcall(chilliSetProperty, objects.obj23, "Color", Color3.fromRGB(76,0,0))
pcall(chilliSetProperty, objects.obj23, "Enabled", true)
pcall(chilliSetProperty, objects.obj23, "LineJoinMode", Enum.LineJoinMode.Round)
pcall(chilliSetProperty, objects.obj23, "Thickness", 0.09000000357627869)
pcall(chilliSetProperty, objects.obj23, "Transparency", 0)
objects.obj23.Parent = objects.obj16

objects.obj24 = Instance.new("UIAspectRatioConstraint")
pcall(chilliSetProperty, objects.obj24, "Name", "UIAspectRatioConstraint")
pcall(chilliSetProperty, objects.obj24, "Archivable", true)
pcall(chilliSetProperty, objects.obj24, "AspectRatio", 1.340000033378601)
pcall(chilliSetProperty, objects.obj24, "AspectType", Enum.AspectType.FitWithinMaxSize)
pcall(chilliSetProperty, objects.obj24, "DominantAxis", Enum.DominantAxis.Width)
objects.obj24.Parent = objects.obj2

objects.obj25 = Instance.new("ScrollingFrame")
pcall(chilliSetProperty, objects.obj25, "Name", "List")
pcall(chilliSetProperty, objects.obj25, "Archivable", true)
pcall(chilliSetProperty, objects.obj25, "Visible", true)
pcall(chilliSetProperty, objects.obj25, "Active", true)
pcall(chilliSetProperty, objects.obj25, "AnchorPoint", Vector2.new(0.5,0.5))
pcall(chilliSetProperty, objects.obj25, "BackgroundColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj25, "BackgroundTransparency", 1)
pcall(chilliSetProperty, objects.obj25, "BorderColor3", Color3.fromRGB(27,42,53))
pcall(chilliSetProperty, objects.obj25, "BorderSizePixel", 0)
pcall(chilliSetProperty, objects.obj25, "ClipsDescendants", true)
pcall(chilliSetProperty, objects.obj25, "Position", UDim2.new(0.5000000596046448,0,0.5701961517333984,0))
pcall(chilliSetProperty, objects.obj25, "Rotation", 0)
pcall(chilliSetProperty, objects.obj25, "Selectable", true)
pcall(chilliSetProperty, objects.obj25, "SelectionOrder", 0)
pcall(chilliSetProperty, objects.obj25, "Size", UDim2.new(0.9900000095367432,0,0.8296076059341431,0))
pcall(chilliSetProperty, objects.obj25, "SizeConstraint", Enum.SizeConstraint.RelativeXY)
pcall(chilliSetProperty, objects.obj25, "ZIndex", 5)
pcall(chilliSetProperty, objects.obj25, "AutomaticSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj25, "LayoutOrder", 1)
pcall(chilliSetProperty, objects.obj25, "CanvasPosition", Vector2.new(0,0))
pcall(chilliSetProperty, objects.obj25, "CanvasSize", UDim2.new(0,0,0,642))
pcall(chilliSetProperty, objects.obj25, "AutomaticCanvasSize", Enum.AutomaticSize.None)
pcall(chilliSetProperty, objects.obj25, "ScrollBarThickness", 6)
pcall(chilliSetProperty, objects.obj25, "ScrollBarImageColor3", Color3.fromRGB(255,255,255))
pcall(chilliSetProperty, objects.obj25, "ScrollBarImageTransparency", 0)
pcall(chilliSetProperty, objects.obj25, "ScrollingDirection", Enum.ScrollingDirection.XY)
pcall(chilliSetProperty, objects.obj25, "ScrollingEnabled", true)
pcall(chilliSetProperty, objects.obj25, "VerticalScrollBarInset", Enum.ScrollBarInset.None)
pcall(chilliSetProperty, objects.obj25, "HorizontalScrollBarInset", Enum.ScrollBarInset.None)
objects.obj25.Parent = objects.obj2








local rootGui = objects.obj1
local mainFrame = objects.obj2
local topBar = objects.obj4
local closeButton = objects.obj14

local Runtime = {}
local Protected = {}

local rootConnections = {}

local function trackRootConnection(connection)
    table.insert(rootConnections, connection)
    return connection
end

local function disconnectRootConnections()
    for index = #rootConnections, 1, -1 do
        local connection = rootConnections[index]
        if connection and connection.Connected then
            connection:Disconnect()
        end
        rootConnections[index] = nil
    end
end

rootGui.ResetOnSpawn = false



rootGui.IgnoreGuiInset = true
rootGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling




local function findLeftCenterSources()
    if not config.UseGameHud then return nil end
    local screen = playerGui:FindFirstChild("LeftCenter")
    local frame = screen and screen:FindFirstChild("LeftCenter")
    local buttons = frame and frame:FindFirstChild("Buttons")
    local shop = buttons and buttons:FindFirstChild("Shop")
    local icon = shop and shop:FindFirstChild("Icon")
    local text = shop and shop:FindFirstChild("Txt")
    if not (screen and frame and buttons and shop and icon and text) then
        return nil
    end

    return screen, frame, buttons, shop, icon, text
end

local sourceLeftCenterScreen
local sourceLeftCenter
local sourceButtons
local sourceShop
local sourceShopIcon
local sourceShopText
sourceLeftCenterScreen, sourceLeftCenter, sourceButtons,
    sourceShop, sourceShopIcon, sourceShopText = findLeftCenterSources()

local leftCenterFrame = sourceLeftCenter
local hudRestorePosition = leftCenterFrame
    and sourceLeftCenter.Position
    or UDim2.fromScale(0, 0.5)
local hudTween = nil
local hudTweenConnection = nil
local hudAnimationSerial = 0
Runtime.chilliIsOpen = false

local function cancelHudTween()
    if hudTweenConnection then
        hudTweenConnection:Disconnect()
        hudTweenConnection = nil
    end
    if hudTween then
        hudTween:Cancel()
        hudTween = nil
    end
end

local launcherGui = Instance.new("ScreenGui")
launcherGui.Name = LAUNCHER_GUI_NAME
launcherGui.ResetOnSpawn = false
launcherGui.IgnoreGuiInset = sourceLeftCenterScreen
    and sourceLeftCenterScreen.IgnoreGuiInset
    or false
launcherGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
launcherGui.DisplayOrder = sourceLeftCenterScreen
    and sourceLeftCenterScreen.DisplayOrder
    or 0
launcherGui:SetAttribute(OWNER_ATTRIBUTE, true)
if sourceLeftCenterScreen then
    pcall(function()
        launcherGui.ScreenInsets = sourceLeftCenterScreen.ScreenInsets
        launcherGui.SafeAreaCompatibility = sourceLeftCenterScreen.SafeAreaCompatibility
        launcherGui.ClipToDeviceSafeArea = sourceLeftCenterScreen.ClipToDeviceSafeArea
    end)
end
local gameId = game.GameId
if gameId ~= 7709344486 then
    launcherGui.Enabled = false
end
launcherGui.Parent = parent

local launcherRoot = Instance.new("Frame")
launcherRoot.Name = "LeftCenter"
launcherRoot.AnchorPoint = sourceLeftCenter
    and sourceLeftCenter.AnchorPoint
    or Vector2.new(0, 0.5)
launcherRoot.Position = sourceLeftCenter
    and sourceLeftCenter.Position
    or UDim2.fromScale(0, 0.5)
launcherRoot.Size = sourceLeftCenter
    and sourceLeftCenter.Size
    or UDim2.fromScale(1, 1)
launcherRoot.BackgroundTransparency = 1
launcherRoot.BorderSizePixel = 0
launcherRoot.Parent = launcherGui

local sourceRootAspect = sourceLeftCenter
    and sourceLeftCenter:FindFirstChildOfClass("UIAspectRatioConstraint")
local launcherRootAspect = Instance.new("UIAspectRatioConstraint")
launcherRootAspect.AspectRatio = sourceRootAspect and sourceRootAspect.AspectRatio or 2.15
launcherRootAspect.AspectType = sourceRootAspect and sourceRootAspect.AspectType or Enum.AspectType.FitWithinMaxSize
launcherRootAspect.DominantAxis = sourceRootAspect and sourceRootAspect.DominantAxis or Enum.DominantAxis.Width
launcherRootAspect.Parent = launcherRoot

local launcherButtons = Instance.new("Frame")
launcherButtons.Name = "Buttons"
launcherButtons.AnchorPoint = sourceButtons
    and sourceButtons.AnchorPoint
    or Vector2.new(0, 0.5)
launcherButtons.Position = sourceButtons
    and sourceButtons.Position
    or UDim2.fromScale(0.015625, 0.5)
launcherButtons.Size = sourceButtons
    and sourceButtons.Size
    or UDim2.fromScale(0.062, 0.38)
launcherButtons.BackgroundTransparency = 1
launcherButtons.BorderSizePixel = 0
launcherButtons.Parent = launcherRoot

local sourceButtonsAspect = sourceButtons
    and sourceButtons:FindFirstChildOfClass("UIAspectRatioConstraint")
local launcherButtonsAspect = Instance.new("UIAspectRatioConstraint")
launcherButtonsAspect.AspectRatio = sourceButtonsAspect and sourceButtonsAspect.AspectRatio or 0.3
launcherButtonsAspect.AspectType = sourceButtonsAspect and sourceButtonsAspect.AspectType or Enum.AspectType.FitWithinMaxSize
launcherButtonsAspect.DominantAxis = sourceButtonsAspect and sourceButtonsAspect.DominantAxis or Enum.DominantAxis.Width
launcherButtonsAspect.Parent = launcherButtons

local chilliButton = Instance.new("ImageButton")
chilliButton.Name = "Chilli"
chilliButton.AnchorPoint = Vector2.new(0.5, 0.5)
chilliButton.Position = sourceShop
    and UDim2.fromScale(0.5, 0)
    or UDim2.fromScale(0.42, -0.1885267)
chilliButton.Size = sourceShop
    and UDim2.fromScale(1, 0.3)
    or UDim2.fromScale(1, 0.3015267)
chilliButton.BackgroundColor3 = sourceShop
    and sourceShop.BackgroundColor3
    or Color3.fromRGB(255, 255, 255)
chilliButton.BackgroundTransparency = sourceShop
    and sourceShop.BackgroundTransparency
    or 1
chilliButton.BorderSizePixel = 0
chilliButton.AutoButtonColor = sourceShop == nil or sourceShop.AutoButtonColor
chilliButton.Image = sourceShop
    and sourceShop.Image
    or "rbxassetid://88734015663903"
chilliButton.HoverImage = sourceShop
    and sourceShop.HoverImage
    or "rbxassetid://119376130178381"
chilliButton.PressedImage = sourceShop and sourceShop.PressedImage or ""
chilliButton.ImageColor3 = sourceShop
    and sourceShop.ImageColor3
    or Color3.fromRGB(255, 255, 255)
chilliButton.ImageTransparency = sourceShop
    and sourceShop.ImageTransparency
    or 0
chilliButton.ImageRectOffset = sourceShop
    and sourceShop.ImageRectOffset
    or Vector2.new()
chilliButton.ImageRectSize = sourceShop
    and sourceShop.ImageRectSize
    or Vector2.new()
chilliButton.ResampleMode = sourceShop
    and sourceShop.ResampleMode
    or Enum.ResamplerMode.Default
chilliButton.ScaleType = sourceShop
    and sourceShop.ScaleType
    or Enum.ScaleType.Fit
chilliButton.SliceCenter = sourceShop
    and sourceShop.SliceCenter
    or Rect.new()
chilliButton.SliceScale = sourceShop and sourceShop.SliceScale or 1
chilliButton.ZIndex = sourceShop and sourceShop.ZIndex or 2
chilliButton.Parent = launcherButtons

local fallbackButtonGradient = Instance.new("UIGradient")
fallbackButtonGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(111, 145, 161)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(52, 72, 84)),
})
fallbackButtonGradient.Rotation = 90
fallbackButtonGradient.Enabled = false
fallbackButtonGradient.Parent = chilliButton

local fallbackButtonStroke = Instance.new("UIStroke")
fallbackButtonStroke.Color = Color3.fromRGB(34, 45, 52)
fallbackButtonStroke.Thickness = 0.025
fallbackButtonStroke.Enabled = false
pcall(function()
    fallbackButtonStroke.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
end)
fallbackButtonStroke.Parent = chilliButton

local chilliViewport = Instance.new("ViewportFrame")
chilliViewport.Name = "ChilliViewport"
chilliViewport.AnchorPoint = sourceShopIcon and sourceShopIcon.AnchorPoint
    or Vector2.new(0.5, 0.5)
chilliViewport.Position = sourceShopIcon and sourceShopIcon.Position
    or UDim2.fromScale(0.5, 0.5)
chilliViewport.Size = sourceShopIcon and sourceShopIcon.Size
    or UDim2.fromScale(0.76055, 0.76055)
chilliViewport.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
chilliViewport.BackgroundTransparency = 1
chilliViewport.BorderSizePixel = 0
chilliViewport.Ambient = Color3.fromRGB(255, 255, 255)
chilliViewport.LightColor = Color3.fromRGB(255, 255, 255)
chilliViewport.LightDirection = Vector3.new(-1, -1, -1)
chilliViewport.ImageColor3 = Color3.fromRGB(255, 255, 255)
chilliViewport.ImageTransparency = 0
chilliViewport.LayoutOrder = 0
chilliViewport.ZIndex = sourceShopIcon and sourceShopIcon.ZIndex or 0
chilliViewport.Visible = true
chilliViewport.Active = false
pcall(function()
    chilliViewport.Interactable = false
end)
chilliViewport.Parent = chilliButton

local chilliWorldModel = Instance.new("WorldModel")
chilliWorldModel.Name = "WorldModel"
chilliWorldModel.Parent = chilliViewport

local chilliSpider = createEmbeddedSpider()
chilliSpider.Parent = chilliWorldModel
chilliSpider.CFrame = CFrame.Angles(
    math.rad(82.5),
    math.rad(-153.95),
    math.rad(0)
)

local chilliViewportCamera = Instance.new("Camera")
chilliViewportCamera.Name = "Camera"
chilliViewportCamera.CameraType = Enum.CameraType.Fixed
chilliViewportCamera.FieldOfView = 50
chilliViewportCamera.FieldOfViewMode = Enum.FieldOfViewMode.Vertical
chilliViewportCamera.Parent = chilliViewport
chilliViewport.CurrentCamera = chilliViewportCamera

local function frameChilliSpider()
    local boxCFrame = chilliSpider.CFrame
    local right = boxCFrame.RightVector
    local up = boxCFrame.UpVector
    local look = boxCFrame.LookVector
    local size = chilliSpider.Size
    local boxSize = Vector3.new(
        math.abs(right.X) * size.X
            + math.abs(up.X) * size.Y
            + math.abs(look.X) * size.Z,
        math.abs(right.Y) * size.X
            + math.abs(up.Y) * size.Y
            + math.abs(look.Y) * size.Z,
        math.abs(right.Z) * size.X
            + math.abs(up.Z) * size.Y
            + math.abs(look.Z) * size.Z
    )

    local verticalFieldOfView = math.rad(chilliViewportCamera.FieldOfView)
    local viewportSize = chilliViewport.AbsoluteSize
    local aspectRatio = 1
    if viewportSize.X > 0 and viewportSize.Y > 0 then
        aspectRatio = viewportSize.X / viewportSize.Y
    end
    local horizontalFieldOfView = 2 * math.atan(
        math.tan(verticalFieldOfView * 0.5) * aspectRatio
    )
    local verticalDistance = boxSize.Y
        / (2 * math.tan(verticalFieldOfView * 0.5))
    local horizontalDistance = boxSize.X
        / (2 * math.tan(horizontalFieldOfView * 0.5))
    local distance = math.max(verticalDistance, horizontalDistance)
        + boxSize.Z * 0.5
    distance = distance * 3

    local target = boxCFrame.Position
    local cameraPosition = target + Vector3.new(0, boxSize.Y * 0.04, distance)
    chilliViewportCamera.CFrame = CFrame.lookAt(cameraPosition, target)
    chilliViewportCamera.Focus = CFrame.new(target)
end

frameChilliSpider()
task.defer(function()
    RunService.RenderStepped:Wait()
    frameChilliSpider()
end)

local chilliText = Instance.new("TextLabel")
chilliText.Name = "Txt"
chilliText.AnchorPoint = sourceShopText and sourceShopText.AnchorPoint or Vector2.new(0.5, 0.5)
chilliText.Position = sourceShopText and sourceShopText.Position or UDim2.fromScale(0.5, 0.9367089)
chilliText.Size = sourceShopText and sourceShopText.Size or UDim2.fromScale(1, 0.2278481)
chilliText.BackgroundTransparency = 1
chilliText.BorderSizePixel = 0
chilliText.FontFace = sourceShopText and sourceShopText.FontFace or Font.new(
    "rbxasset://fonts/families/GothamSSm.json",
    Enum.FontWeight.ExtraBold
)
chilliText.Text = "Chilli Hub"
chilliText.TextColor3 = sourceShopText and sourceShopText.TextColor3 or Color3.fromRGB(255, 255, 255)
chilliText.TextTransparency = sourceShopText and sourceShopText.TextTransparency or 0
chilliText.TextScaled = sourceShopText == nil or sourceShopText.TextScaled
chilliText.TextWrapped = sourceShopText == nil or sourceShopText.TextWrapped
chilliText.TextXAlignment = sourceShopText and sourceShopText.TextXAlignment or Enum.TextXAlignment.Center
chilliText.TextYAlignment = sourceShopText and sourceShopText.TextYAlignment or Enum.TextYAlignment.Center
chilliText.ZIndex = sourceShopText and sourceShopText.ZIndex or 1
chilliText.Parent = chilliButton

local sourceTextStroke = sourceShopText and sourceShopText:FindFirstChildOfClass("UIStroke")
local chilliTextStroke = Instance.new("UIStroke")
chilliTextStroke.ApplyStrokeMode = sourceTextStroke and sourceTextStroke.ApplyStrokeMode or Enum.ApplyStrokeMode.Contextual
chilliTextStroke.Color = sourceTextStroke and sourceTextStroke.Color or Color3.fromRGB(0, 0, 0)
chilliTextStroke.LineJoinMode = sourceTextStroke and sourceTextStroke.LineJoinMode or Enum.LineJoinMode.Round
chilliTextStroke.Thickness = sourceTextStroke and sourceTextStroke.Thickness or 2
chilliTextStroke.Transparency = sourceTextStroke and sourceTextStroke.Transparency or 0.35
if sourceTextStroke then
    local originalThickness = sourceTextStroke:GetAttribute("OriginalThickness")
    if originalThickness ~= nil then
        chilliTextStroke:SetAttribute("OriginalThickness", originalThickness)
    end
end
chilliTextStroke.Parent = chilliText

local function getLiveVerticalStep()
    if not (sourceButtons and sourceButtons.Parent and sourceShop and sourceShop.Parent) then
        return nil
    end

    local shopPosition = sourceShop.AbsolutePosition
    local shopSize = sourceShop.AbsoluteSize
    local bestStep = nil

    for _, child in ipairs(sourceButtons:GetChildren()) do
        if child ~= sourceShop and child:IsA("GuiButton") and child.Visible then
            local deltaX = math.abs(child.AbsolutePosition.X - shopPosition.X)
            local deltaY = child.AbsolutePosition.Y - shopPosition.Y
            if deltaX <= shopSize.X * 0.25 and deltaY > 0 then
                if not bestStep or deltaY < bestStep then
                    bestStep = deltaY
                end
            end
        end
    end

    if bestStep then
        return bestStep
    end

    local grid = sourceButtons:FindFirstChildOfClass("UIGridLayout")
    if grid then
        return grid.AbsoluteCellSize.Y
            + grid.CellPadding.Y.Scale * sourceButtons.AbsoluteSize.Y
            + grid.CellPadding.Y.Offset
    end

    return shopSize.Y
end

local function updateChilliLauncherLayout()
    if not (sourceButtons and sourceButtons.Parent and sourceShop and sourceShop.Parent) then
        return
    end

    local buttonsSize = sourceButtons.AbsoluteSize
    local shopSize = sourceShop.AbsoluteSize
    if buttonsSize.X <= 0 or buttonsSize.Y <= 0 or shopSize.X <= 0 or shopSize.Y <= 0 then
        return
    end

    local buttonsPosition = sourceButtons.AbsolutePosition
    local shopPosition = sourceShop.AbsolutePosition
    local verticalStep = getLiveVerticalStep()
    if not verticalStep then
        return
    end
    local centerX = shopPosition.X + shopSize.X * 0.5
    local centerY = shopPosition.Y - verticalStep + shopSize.Y * 0.5

    chilliButton.Position = UDim2.fromScale(
        (centerX - buttonsPosition.X) / buttonsSize.X,
        (centerY - buttonsPosition.Y) / buttonsSize.Y
    )
    chilliButton.Size = UDim2.fromScale(
        shopSize.X / buttonsSize.X,
        shopSize.Y / buttonsSize.Y
    )
end

local launcherLayoutQueued = false
local function queueChilliLauncherLayout()
    
    
    if hudTween or launcherLayoutQueued then
        return
    end
    launcherLayoutQueued = true
    task.defer(function()
        RunService.RenderStepped:Wait()
        launcherLayoutQueued = false
        if launcherGui.Parent then
            updateChilliLauncherLayout()
        end
    end)
end

local sourceConnections = {}
local sourceBound = false

local function disconnectSourceConnections()
    for _, connection in ipairs(sourceConnections) do
        connection:Disconnect()
    end
    table.clear(sourceConnections)
    sourceBound = false
end

local function connectSource(signal, callback)
    local connection = signal:Connect(callback)
    table.insert(sourceConnections, connection)
end

local function shiftOneScreenLeft(position)
    return UDim2.new(
        position.X.Scale - 1,
        position.X.Offset,
        position.Y.Scale,
        position.Y.Offset
    )
end

local function refreshEffectiveLeftCenterHidden()
    local unavailable = not sourceLeftCenterScreen
        or not sourceLeftCenterScreen.Parent
        or not sourceLeftCenterScreen.Enabled
        or not leftCenterFrame
        or not leftCenterFrame.Parent
        or not leftCenterFrame.Visible
    local shiftedLeft = false
    if leftCenterFrame and leftCenterFrame.Parent then
        local currentX = leftCenterFrame.Position.X
        local restoreX = hudRestorePosition.X
        shiftedLeft = currentX.Scale < restoreX.Scale - 0.05
            or (
                math.abs(currentX.Scale - restoreX.Scale) <= 0.05
                and currentX.Offset < restoreX.Offset - 4
            )
    end
    local effectiveHidden =
        launcherGui:GetAttribute("QuickHudHidden") == true
        or Runtime.chilliIsOpen
        or unavailable
        or shiftedLeft
    if launcherGui:GetAttribute("EffectiveLeftCenterHidden")
        ~= effectiveHidden
    then
        launcherGui:SetAttribute(
            "EffectiveLeftCenterHidden",
            effectiveHidden
        )
    end
end

local function adoptLeftCenterSources(screen, frame, buttons, shop, icon, text)
    if sourceBound
        or not (screen and frame and buttons and shop and icon and text)
    then
        return false
    end

    sourceBound = true

    sourceLeftCenterScreen = screen
    sourceLeftCenter = frame
    sourceButtons = buttons
    sourceShop = shop
    sourceShopIcon = icon
    sourceShopText = text
    sourceTextStroke = sourceShopText:FindFirstChildOfClass("UIStroke")

    launcherGui.IgnoreGuiInset = sourceLeftCenterScreen.IgnoreGuiInset
    launcherGui.DisplayOrder = sourceLeftCenterScreen.DisplayOrder
    pcall(function()
        launcherGui.ScreenInsets = sourceLeftCenterScreen.ScreenInsets
        launcherGui.SafeAreaCompatibility = sourceLeftCenterScreen.SafeAreaCompatibility
        launcherGui.ClipToDeviceSafeArea = sourceLeftCenterScreen.ClipToDeviceSafeArea
    end)

    launcherRoot.AnchorPoint = sourceLeftCenter.AnchorPoint
    launcherRoot.Size = sourceLeftCenter.Size
    sourceRootAspect = sourceLeftCenter:FindFirstChildOfClass("UIAspectRatioConstraint")
    if sourceRootAspect then
        launcherRootAspect.AspectRatio = sourceRootAspect.AspectRatio
        launcherRootAspect.AspectType = sourceRootAspect.AspectType
        launcherRootAspect.DominantAxis = sourceRootAspect.DominantAxis
    end

    launcherButtons.AnchorPoint = sourceButtons.AnchorPoint
    launcherButtons.Position = sourceButtons.Position
    launcherButtons.Size = sourceButtons.Size
    sourceButtonsAspect = sourceButtons:FindFirstChildOfClass("UIAspectRatioConstraint")
    if sourceButtonsAspect then
        launcherButtonsAspect.AspectRatio = sourceButtonsAspect.AspectRatio
        launcherButtonsAspect.AspectType = sourceButtonsAspect.AspectType
        launcherButtonsAspect.DominantAxis = sourceButtonsAspect.DominantAxis
    end

    chilliButton.BackgroundColor3 = sourceShop.BackgroundColor3
    chilliButton.BackgroundTransparency = sourceShop.BackgroundTransparency
    chilliButton.AutoButtonColor = sourceShop.AutoButtonColor
    chilliButton.Image = sourceShop.Image
    chilliButton.HoverImage = sourceShop.HoverImage
    chilliButton.PressedImage = sourceShop.PressedImage
    chilliButton.ImageColor3 = sourceShop.ImageColor3
    chilliButton.ImageTransparency = sourceShop.ImageTransparency
    chilliButton.ImageRectOffset = sourceShop.ImageRectOffset
    chilliButton.ImageRectSize = sourceShop.ImageRectSize
    chilliButton.ResampleMode = sourceShop.ResampleMode
    chilliButton.ScaleType = sourceShop.ScaleType
    chilliButton.SliceCenter = sourceShop.SliceCenter
    chilliButton.SliceScale = sourceShop.SliceScale
    chilliButton.ZIndex = sourceShop.ZIndex
    fallbackButtonGradient.Enabled = false
    fallbackButtonStroke.Enabled = false

    chilliViewport.AnchorPoint = sourceShopIcon.AnchorPoint
    chilliViewport.Position = sourceShopIcon.Position
    chilliViewport.Size = sourceShopIcon.Size
    chilliViewport.ZIndex = sourceShopIcon.ZIndex

    chilliText.AnchorPoint = sourceShopText.AnchorPoint
    chilliText.Position = sourceShopText.Position
    chilliText.Size = sourceShopText.Size
    chilliText.FontFace = sourceShopText.FontFace
    chilliText.TextColor3 = sourceShopText.TextColor3
    chilliText.TextTransparency = sourceShopText.TextTransparency
    chilliText.TextScaled = sourceShopText.TextScaled
    chilliText.TextWrapped = sourceShopText.TextWrapped
    chilliText.TextXAlignment = sourceShopText.TextXAlignment
    chilliText.TextYAlignment = sourceShopText.TextYAlignment
    chilliText.ZIndex = sourceShopText.ZIndex

    if sourceTextStroke then
        local boundStroke = sourceTextStroke
        chilliTextStroke.ApplyStrokeMode = boundStroke.ApplyStrokeMode
        chilliTextStroke.Color = boundStroke.Color
        chilliTextStroke.LineJoinMode = boundStroke.LineJoinMode
        chilliTextStroke.Thickness = boundStroke.Thickness
        chilliTextStroke.Transparency = boundStroke.Transparency
        connectSource(
            boundStroke:GetPropertyChangedSignal("Thickness"),
            function()
                chilliTextStroke.Thickness = boundStroke.Thickness
            end
        )
        connectSource(
            boundStroke:GetPropertyChangedSignal("Transparency"),
            function()
                chilliTextStroke.Transparency = boundStroke.Transparency
            end
        )
    end

    leftCenterFrame = sourceLeftCenter
    hudAnimationSerial = hudAnimationSerial + 1
    cancelHudTween()
    local savedRestorePosition = launcherGui:GetAttribute(
        "HudRestorePosition"
    )
    if typeof(savedRestorePosition) == "UDim2" then
        hudRestorePosition = savedRestorePosition
    else
        hudRestorePosition = leftCenterFrame.Position
    end
    
    
    while hudRestorePosition.X.Scale <= -0.5 do
        hudRestorePosition = UDim2.new(
            hudRestorePosition.X.Scale + 1,
            hudRestorePosition.X.Offset,
            hudRestorePosition.Y.Scale,
            hudRestorePosition.Y.Offset
        )
    end
    if Runtime.chilliIsOpen
        or launcherGui:GetAttribute("QuickHudHidden") == true
    then
        leftCenterFrame.Position = shiftOneScreenLeft(
            hudRestorePosition
        )
        launcherGui:SetAttribute(
            "HudRestorePosition",
            hudRestorePosition
        )
        if launcherGui:GetAttribute("QuickHudHidden") == true then
            leftCenterFrame.Visible = false
            sourceLeftCenterScreen.Enabled = false
            launcherGui:SetAttribute("LeftCenterHiddenByLibrary", true)
            launcherGui:SetAttribute(
                "LeftCenterScreenDisabledByLibrary",
                true
            )
        end
    else
        leftCenterFrame.Position = hudRestorePosition
        launcherGui:SetAttribute("HudRestorePosition", nil)
    end
    launcherRoot.Position = Runtime.chilliIsOpen
        and shiftOneScreenLeft(hudRestorePosition)
        or hudRestorePosition

    connectSource(
        leftCenterFrame:GetPropertyChangedSignal("Position"),
        function()
            local shouldStayHidden =
                launcherGui:GetAttribute("QuickHudHidden") == true
                or Runtime.chilliIsOpen
            if shouldStayHidden then
                
                
                
                if not hudTween then
                    local hiddenPosition = shiftOneScreenLeft(
                        hudRestorePosition
                    )
                    if leftCenterFrame.Position ~= hiddenPosition then
                        leftCenterFrame.Position = hiddenPosition
                    end
                end
                refreshEffectiveLeftCenterHidden()
                return
            end
            launcherRoot.Position = leftCenterFrame.Position
            refreshEffectiveLeftCenterHidden()
        end
    )
    connectSource(
        leftCenterFrame:GetPropertyChangedSignal("Visible"),
        function()
            if launcherGui:GetAttribute("QuickHudHidden") == true
                and leftCenterFrame.Visible
            then
                leftCenterFrame.Visible = false
            end
            refreshEffectiveLeftCenterHidden()
        end
    )
    connectSource(
        sourceLeftCenterScreen:GetPropertyChangedSignal("Enabled"),
        function()
            if launcherGui:GetAttribute("QuickHudHidden") == true
                and sourceLeftCenterScreen.Enabled
            then
                sourceLeftCenterScreen.Enabled = false
            end
            refreshEffectiveLeftCenterHidden()
        end
    )
    for _, instance in ipairs({ sourceLeftCenter, sourceButtons, sourceShop }) do
        connectSource(
            instance:GetPropertyChangedSignal("AbsolutePosition"),
            queueChilliLauncherLayout
        )
        connectSource(
            instance:GetPropertyChangedSignal("AbsoluteSize"),
            queueChilliLauncherLayout
        )
    end
    connectSource(sourceButtons.ChildAdded, queueChilliLauncherLayout)
    connectSource(sourceButtons.ChildRemoved, queueChilliLauncherLayout)

    queueChilliLauncherLayout()
    refreshEffectiveLeftCenterHidden()
    task.defer(frameChilliSpider)
    return true
end

if sourceLeftCenterScreen then
    adoptLeftCenterSources(
        sourceLeftCenterScreen,
        sourceLeftCenter,
        sourceButtons,
        sourceShop,
        sourceShopIcon,
        sourceShopText
    )
else
    task.spawn(function()
        local retryDeadline = os.clock() + 10
        while launcherGui.Parent
            and not sourceBound
            and os.clock() < retryDeadline
        do
            local screen, frame, buttons, shop, icon, text =
                findLeftCenterSources()
            if adoptLeftCenterSources(
                screen,
                frame,
                buttons,
                shop,
                icon,
                text
            ) then
                break
            end
            task.wait(0.25)
        end
    end)
end



trackRootConnection(playerGui.DescendantAdded:Connect(function()
    local screen, frame, buttons, shop, icon, text = findLeftCenterSources()
    if frame
        and (frame ~= leftCenterFrame or screen ~= sourceLeftCenterScreen)
    then
        disconnectSourceConnections()
        adoptLeftCenterSources(screen, frame, buttons, shop, icon, text)
    end
end))




local HUD_RENDER_GUARD_NAME = "MIKOTOHChilliLeftCenterRenderGuard"

local function enforceHiddenLeftCenterBeforeRender()
    if not rootGui.Parent
        or not leftCenterFrame
        or not leftCenterFrame.Parent
    then
        return
    end

    local manuallyHidden =
        launcherGui:GetAttribute("QuickHudHidden") == true
    if manuallyHidden and not hudTween then
        if leftCenterFrame.Visible then
            leftCenterFrame.Visible = false
        end
        if sourceLeftCenterScreen and sourceLeftCenterScreen.Enabled then
            sourceLeftCenterScreen.Enabled = false
        end
        launcherGui:SetAttribute("LeftCenterHiddenByLibrary", true)
        launcherGui:SetAttribute(
            "LeftCenterScreenDisabledByLibrary",
            true
        )
    elseif not manuallyHidden
        and launcherGui:GetAttribute("LeftCenterHiddenByLibrary") == true
    then
        leftCenterFrame.Visible = true
        launcherGui:SetAttribute("LeftCenterHiddenByLibrary", nil)
        if sourceLeftCenterScreen
            and launcherGui:GetAttribute(
                "LeftCenterScreenDisabledByLibrary"
            ) == true
        then
            sourceLeftCenterScreen.Enabled = true
            launcherGui:SetAttribute(
                "LeftCenterScreenDisabledByLibrary",
                nil
            )
        end
    end

    if hudTween then
        return
    end

    local shouldStayHidden = manuallyHidden or Runtime.chilliIsOpen
    if not shouldStayHidden then
        return
    end

    local hiddenPosition = shiftOneScreenLeft(hudRestorePosition)
    if leftCenterFrame.Position ~= hiddenPosition then
        leftCenterFrame.Position = hiddenPosition
    end
end

pcall(function()
    RunService:UnbindFromRenderStep(HUD_RENDER_GUARD_NAME)
end)
RunService:BindToRenderStep(
    HUD_RENDER_GUARD_NAME,
    Enum.RenderPriority.Last.Value + 10000,
    enforceHiddenLeftCenterBeforeRender
)

rootGui.Destroying:Connect(function()
    pcall(function()
        RunService:UnbindFromRenderStep(HUD_RENDER_GUARD_NAME)
    end)
    disconnectRootConnections()
    disconnectSourceConnections()
end)

local function applyOriginalStrokeSizing()
    
    
    
    
    pcall(function()
        for _, inst in ipairs(rootGui:GetDescendants()) do
            if inst:IsA("UIStroke") then
                inst.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
                inst.BorderStrokePosition = Enum.BorderStrokePosition.Outer
                inst.BorderOffset = UDim.new(0, 0)
            end
        end
    end)
end

local function makeDraggable(handle, target, canStart, moved)
    handle.Active = true

    local dragging = false
    local dragInput = nil
    local dragStart = Vector2.new(0, 0)
    local startPosition = Vector2.new(0, 0)

    local function cancelDrag()
        dragging = false
        dragInput = nil
    end

    trackRootConnection(handle.InputBegan:Connect(function(input)
        if dragging or input.UserInputState ~= Enum.UserInputState.Begin then
            return
        end
        if input.UserInputType ~= Enum.UserInputType.MouseButton1
            and input.UserInputType ~= Enum.UserInputType.Touch
        then
            return
        end
        if canStart and not canStart() then
            return
        end

        local region = rootGui.AbsoluteSize
        if region.X <= 0 or region.Y <= 0 then
            return
        end

        local pointer = Vector2.new(input.Position.X, input.Position.Y)
        local handlePosition = handle.AbsolutePosition
        local handleSize = handle.AbsoluteSize
        if pointer.X < handlePosition.X
            or pointer.X > handlePosition.X + handleSize.X
            or pointer.Y < handlePosition.Y
            or pointer.Y > handlePosition.Y + handleSize.Y
        then
            return
        end
        
        
        for _, child in ipairs(handle:GetDescendants()) do
            if child:IsA("GuiButton") and child.Visible then
                local childPosition = child.AbsolutePosition
                local childSize = child.AbsoluteSize
                if pointer.X >= childPosition.X
                    and pointer.X <= childPosition.X + childSize.X
                    and pointer.Y >= childPosition.Y
                    and pointer.Y <= childPosition.Y + childSize.Y
                then
                    return
                end
            end
        end

        dragging = true
        dragInput = input.UserInputType == Enum.UserInputType.Touch
            and input
            or nil
        dragStart = pointer
        startPosition = Vector2.new(
            target.Position.X.Scale + target.Position.X.Offset / region.X,
            target.Position.Y.Scale + target.Position.Y.Offset / region.Y
        )
    end))

    trackRootConnection(UserInputService.InputChanged:Connect(function(input)
        if not dragging then
            return
        end
        local inputMoved = (dragInput and input == dragInput)
            or (not dragInput
                and input.UserInputType == Enum.UserInputType.MouseMovement)
        if not inputMoved then
            return
        end

        local region = rootGui.AbsoluteSize
        if region.X <= 0 or region.Y <= 0 then
            return
        end

        local delta = Vector2.new(input.Position.X, input.Position.Y)
            - dragStart
        local targetFraction = Vector2.new(
            target.AbsoluteSize.X / region.X,
            target.AbsoluteSize.Y / region.Y
        )
        local anchor = target.AnchorPoint
        local minX = targetFraction.X * anchor.X
        local maxX = 0.998 - targetFraction.X * (1 - anchor.X)
        local minY = targetFraction.Y * anchor.Y
        
        
        
        local maxY = 0.98 + targetFraction.Y * anchor.Y

        target.Position = UDim2.fromScale(
            math.clamp(
                startPosition.X + delta.X / region.X,
                math.min(minX, maxX),
                math.max(minX, maxX)
            ),
            math.clamp(
                startPosition.Y + delta.Y / region.Y,
                math.min(minY, maxY),
                math.max(minY, maxY)
            )
        )
        if moved then
            moved(target.Position)
        end
    end))

    trackRootConnection(UserInputService.InputEnded:Connect(function(input)
        if not dragging then
            return
        end
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input == dragInput
        then
            cancelDrag()
        end
    end))

    return {
        Cancel = cancelDrag,
        IsDragging = function()
            return dragging
        end,
    }
end




local SAFE_TOUCH_TAP_DISTANCE = 10
local safeTouchPresses = setmetatable({}, { __mode = "k" })

local function pointInsideGui(guiObject, point)
    if not guiObject or not guiObject.Parent or not guiObject.Visible then
        return false
    end
    local position = guiObject.AbsolutePosition
    local size = guiObject.AbsoluteSize
    return point.X >= position.X
        and point.X <= position.X + size.X
        and point.Y >= position.Y
        and point.Y <= position.Y + size.Y
end

trackRootConnection(UserInputService.InputChanged:Connect(function(input)
    local press = safeTouchPresses[input]
    if not press then
        return
    end
    local point = Vector2.new(input.Position.X, input.Position.Y)
    press.Position = point
    if (point - press.Start).Magnitude > SAFE_TOUCH_TAP_DISTANCE then
        press.Cancelled = true
    end
end))

trackRootConnection(UserInputService.InputEnded:Connect(function(input)
    local press = safeTouchPresses[input]
    if not press then
        return
    end
    local point = Vector2.new(input.Position.X, input.Position.Y)
    press.Position = point
    press.Ended = true
    if (point - press.Start).Magnitude > SAFE_TOUCH_TAP_DISTANCE
        or not pointInsideGui(press.Button, point)
    then
        press.Cancelled = true
    end
    
    
    task.delay(0.2, function()
        if safeTouchPresses[input] == press then
            safeTouchPresses[input] = nil
        end
    end)
end))

local function connectSafeActivation(button, callback)
    button.Active = true
    button.InputBegan:Connect(function(input)
        if input.UserInputType ~= Enum.UserInputType.Touch
            or input.UserInputState ~= Enum.UserInputState.Begin
        then
            return
        end
        local point = Vector2.new(input.Position.X, input.Position.Y)
        if not pointInsideGui(button, point) then
            return
        end
        safeTouchPresses[input] = {
            Button = button,
            Start = point,
            Position = point,
            Cancelled = false,
            Ended = false,
        }
    end)

    return button.Activated:Connect(function(input)
        if input and input.UserInputType == Enum.UserInputType.Touch then
            local press = safeTouchPresses[input]
            if not press
                or press.Button ~= button
                or press.Cancelled
                or not pointInsideGui(button, press.Position)
            then
                return
            end
        end
        callback(input)
    end)
end

local function makeButtonFeedback(button)
    local normalSize = button.Size
    local hovered = false
    local activeTween = nil

    local function scaledSize(multiplier)
        return UDim2.new(
            normalSize.X.Scale * multiplier,
            normalSize.X.Offset * multiplier,
            normalSize.Y.Scale * multiplier,
            normalSize.Y.Offset * multiplier
        )
    end

    local function tweenSize(size, duration)
        if activeTween then
            activeTween:Cancel()
        end
        activeTween = TweenService:Create(
            button,
            TweenInfo.new(duration, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
            { Size = size }
        )
        activeTween:Play()
    end

    button.MouseEnter:Connect(function()
        hovered = true
        tweenSize(scaledSize(1.04), 0.12)
    end)

    button.MouseLeave:Connect(function()
        hovered = false
        tweenSize(normalSize, 0.12)
    end)

    button.MouseButton1Down:Connect(function()
        tweenSize(scaledSize(0.96), 0.06)
    end)

    button.MouseButton1Up:Connect(function()
        tweenSize(hovered and scaledSize(1.04) or normalSize, 0.09)
    end)
end

Runtime.menuSize = rootGui:GetAttribute("MenuSize") or mainFrame.Size
local defaultOpenPosition = UDim2.fromScale(0.5, 0.475)
Runtime.windowRestPosition = defaultOpenPosition
Runtime.windowDragController = nil
local function offsetWindowPosition(position, yScale)
    return UDim2.new(
        position.X.Scale,
        position.X.Offset,
        position.Y.Scale + yScale,
        position.Y.Offset
    )
end
local function openingWindowPosition()
    return offsetWindowPosition(Runtime.windowRestPosition, 0.245)
end
local function closedWindowPosition()
    return UDim2.new(
        Runtime.windowRestPosition.X.Scale,
        Runtime.windowRestPosition.X.Offset,
        1.55,
        0
    )
end
local WINDOW_OPEN_DURATION = 0.34
local WINDOW_CLOSE_DURATION = 0.26
local animationLocked = false
local windowTween = nil
local windowTweenConnection = nil
local windowAnimationSerial = 0


Runtime.windowAnimating = false




















local ContentScale = {
    Base = Runtime.menuSize,
    Listeners = {},
    ReflowTabs = nil,
    X = 1,
    Y = 1,
}


function ContentScale.OnChanged(callback)
    table.insert(ContentScale.Listeners, callback)
    callback(ContentScale.X, ContentScale.Y)
    return callback
end

function ContentScale.Refresh()
    local function axisScale(baseValue, currentValue)
        if baseValue > 0 and currentValue > 0 then
            return math.max(1, currentValue / baseValue)
        end
        return 1
    end

    local nextX = axisScale(
        ContentScale.Base.X.Scale,
        Runtime.menuSize.X.Scale
    )
    local nextY = axisScale(
        ContentScale.Base.Y.Scale,
        Runtime.menuSize.Y.Scale
    )
    if math.abs(nextX - ContentScale.X) < 0.0001
        and math.abs(nextY - ContentScale.Y) < 0.0001
    then
        return
    end
    ContentScale.X = nextX
    ContentScale.Y = nextY

    for index = #ContentScale.Listeners, 1, -1 do
        local callback = ContentScale.Listeners[index]
        local ok, keep = pcall(callback, nextX, nextY)
        if not ok then
        elseif keep == false then
            table.remove(ContentScale.Listeners, index)
        end
    end
    if ContentScale.ReflowTabs then
        ContentScale.ReflowTabs()
    end
end









do
    local aspectConstraint = objects.obj24
    local ratio = aspectConstraint.AspectRatio
    
    
    
    
    aspectConstraint.Parent = nil

    
    
    local viewport = camera and camera.ViewportSize or Vector2.new(1280, 720)
    if viewport.X < 1 or viewport.Y < 1 then
        viewport = Vector2.new(1280, 720)
    end

    local topLeftInset, bottomRightInset = Vector2.new(0, 0), Vector2.new(0, 0)
    pcall(function()
        topLeftInset, bottomRightInset = GuiService:GetGuiInset()
    end)

    local regionX = math.max(
        viewport.X - topLeftInset.X - bottomRightInset.X,
        1
    )
    local regionY = math.max(
        viewport.Y - topLeftInset.Y - bottomRightInset.Y,
        1
    )

    local width = Runtime.menuSize.X.Scale * regionX
    local height = Runtime.menuSize.Y.Scale * regionY
    if ratio > 0 then
        if width / height > ratio then
            width = height * ratio
        else
            height = width / ratio
        end
    end

    
    
    
    if UserInputService.TouchEnabled
        and not UserInputService.KeyboardEnabled
        and not UserInputService.MouseEnabled
    then
        local mobileMultiplier = math.min(
            1.3,
            (regionX * 0.98) / math.max(width, 1),
            (regionY * 0.98) / math.max(height, 1)
        )
        width = width * mobileMultiplier
        height = height * mobileMultiplier
    end

    Runtime.menuSize = UDim2.fromScale(width / regionX, height / regionY)
    rootGui:SetAttribute("MenuSize", Runtime.menuSize)
    mainFrame.Size = Runtime.menuSize
    ContentScale.Base = Runtime.menuSize
end

local function setLeftCenterHidden(hidden)
    hudAnimationSerial = hudAnimationSerial + 1
    local serial = hudAnimationSerial
    cancelHudTween()

    if hidden then
        
        
        
        local savedRestorePosition = launcherGui:GetAttribute(
            "HudRestorePosition"
        )
        if typeof(savedRestorePosition) == "UDim2" then
            hudRestorePosition = savedRestorePosition
        end
        while hudRestorePosition.X.Scale <= -0.5 do
            hudRestorePosition = UDim2.new(
                hudRestorePosition.X.Scale + 1,
                hudRestorePosition.X.Offset,
                hudRestorePosition.Y.Scale,
                hudRestorePosition.Y.Offset
            )
        end
        launcherGui:SetAttribute(
            "HudRestorePosition",
            hudRestorePosition
        )
    elseif leftCenterFrame
        and launcherGui:GetAttribute("LeftCenterHiddenByLibrary") == true
    then
        leftCenterFrame.Visible = true
        launcherGui:SetAttribute("LeftCenterHiddenByLibrary", nil)
        if sourceLeftCenterScreen
            and launcherGui:GetAttribute(
                "LeftCenterScreenDisabledByLibrary"
            ) == true
        then
            sourceLeftCenterScreen.Enabled = true
            launcherGui:SetAttribute(
                "LeftCenterScreenDisabledByLibrary",
                nil
            )
        end
    end

    local target = hidden
        and shiftOneScreenLeft(hudRestorePosition)
        or hudRestorePosition
    refreshEffectiveLeftCenterHidden()
    local tweenInfo = TweenInfo.new(0.5, Enum.EasingStyle.Quint)

    if leftCenterFrame then
        hudTween = TweenService:Create(
            leftCenterFrame,
            tweenInfo,
            { Position = target }
        )
        
        
        TweenService:Create(
            launcherRoot,
            tweenInfo,
            {
                Position = hudRestorePosition,
            }
        ):Play()
    else
        
        hudTween = TweenService:Create(
            launcherRoot,
            tweenInfo,
            {
                Position = hudRestorePosition,
            }
        )
    end
    local activeHudTween = hudTween
    hudTweenConnection = activeHudTween.Completed:Connect(function()
        if serial ~= hudAnimationSerial
            or hudTween ~= activeHudTween
        then
            return
        end
        
        
        if hudTweenConnection then
            hudTweenConnection:Disconnect()
            hudTweenConnection = nil
        end
        hudTween = nil

        local manuallyHidden =
            launcherGui:GetAttribute("QuickHudHidden") == true
        local shouldStayHidden = manuallyHidden or Runtime.chilliIsOpen
        if shouldStayHidden then
            if leftCenterFrame then
                leftCenterFrame.Position = shiftOneScreenLeft(
                    hudRestorePosition
                )
                if manuallyHidden then
                    leftCenterFrame.Visible = false
                    launcherGui:SetAttribute(
                        "LeftCenterHiddenByLibrary",
                        true
                    )
                end
            end
            launcherGui:SetAttribute(
                "HudRestorePosition",
                hudRestorePosition
            )
            if manuallyHidden and sourceLeftCenterScreen then
                sourceLeftCenterScreen.Enabled = false
                launcherGui:SetAttribute(
                    "LeftCenterScreenDisabledByLibrary",
                    true
                )
            end
        else
            if leftCenterFrame then
                leftCenterFrame.Position = hudRestorePosition
                if launcherGui:GetAttribute(
                    "LeftCenterHiddenByLibrary"
                ) == true then
                    leftCenterFrame.Visible = true
                    launcherGui:SetAttribute(
                        "LeftCenterHiddenByLibrary",
                        nil
                    )
                end
            end
            if sourceLeftCenterScreen
                and launcherGui:GetAttribute(
                    "LeftCenterScreenDisabledByLibrary"
                ) == true
            then
                sourceLeftCenterScreen.Enabled = true
                launcherGui:SetAttribute(
                    "LeftCenterScreenDisabledByLibrary",
                    nil
                )
            end
            launcherGui:SetAttribute("HudRestorePosition", nil)
        end
        launcherRoot.Position = hudRestorePosition
        refreshEffectiveLeftCenterHidden()
        queueChilliLauncherLayout()
    end)
    activeHudTween:Play()
end

local function cancelWindowTween()
    windowAnimationSerial = windowAnimationSerial + 1
    if windowTweenConnection then
        windowTweenConnection:Disconnect()
        windowTweenConnection = nil
    end
    if windowTween then
        windowTween:Cancel()
        windowTween = nil
    end
end

local function tweenWindowPosition(target, info, completed)
    cancelWindowTween()
    local serial = windowAnimationSerial
    local tween = TweenService:Create(mainFrame, info, {
        Position = target,
    })
    windowTween = tween
    windowTweenConnection = tween.Completed:Connect(function(playbackState)
        if serial ~= windowAnimationSerial or windowTween ~= tween then
            return
        end
        if windowTweenConnection then
            windowTweenConnection:Disconnect()
            windowTweenConnection = nil
        end
        windowTween = nil
        if playbackState == Enum.PlaybackState.Completed then
            completed()
        end
    end)
    tween:Play()
end

local function playOpenAnimation(completed)
    if Runtime.chilliIsOpen then
        return
    end
    local resumeFromCurrentPosition = windowTween ~= nil
    animationLocked = true
    Runtime.windowAnimating = true
    Runtime.chilliIsOpen = true
    setLeftCenterHidden(true)

    if not resumeFromCurrentPosition then
        mainFrame.Position = openingWindowPosition()
    end
    mainFrame.Size = Runtime.menuSize

    tweenWindowPosition(Runtime.windowRestPosition, TweenInfo.new(
        WINDOW_OPEN_DURATION,
        Enum.EasingStyle.Quart,
        Enum.EasingDirection.Out
    ), function()
        animationLocked = false
        Runtime.windowAnimating = false
        if completed then
            completed()
        end
    end)
end

local function playCloseAnimation()
    if not Runtime.chilliIsOpen then
        return
    end
    
    
    if Runtime.windowDragController then
        Runtime.windowDragController.Cancel()
    end
    animationLocked = true
    Runtime.windowAnimating = true
    Runtime.chilliIsOpen = false
    setLeftCenterHidden(
        launcherGui:GetAttribute("QuickHudHidden") == true
    )

    mainFrame.Size = Runtime.menuSize
    tweenWindowPosition(closedWindowPosition(), TweenInfo.new(
        WINDOW_CLOSE_DURATION,
        Enum.EasingStyle.Quart,
        Enum.EasingDirection.In
    ), function()
        animationLocked = false
        Runtime.windowAnimating = false
    end)
end















local RESIZE_LIMITS = {
    MinWidth = 0.20,
    MaxWidth = 0.98,
    MinHeight = 0.22,
    MaxHeight = 0.98,
}





local RESIZE_KEEPS_OPTION_WIDTH = false

local resizeGrip = Instance.new("TextButton")
resizeGrip.Name = "ResizeGrip"
resizeGrip.Active = true
resizeGrip.AutoButtonColor = false
resizeGrip.AnchorPoint = Vector2.new(1, 1)
resizeGrip.BackgroundTransparency = 1
resizeGrip.BorderSizePixel = 0
resizeGrip.Position = UDim2.fromScale(0.998, 0.995)
resizeGrip.Selectable = false
resizeGrip.Size = UDim2.fromScale(0.05, 0.05)
resizeGrip.Text = ""
resizeGrip.ZIndex = 120
resizeGrip.Parent = mainFrame

local resizeGripAspect = Instance.new("UIAspectRatioConstraint")
resizeGripAspect.AspectRatio = 1
resizeGripAspect.AspectType = Enum.AspectType.FitWithinMaxSize
resizeGripAspect.DominantAxis = Enum.DominantAxis.Width
resizeGripAspect.Parent = resizeGrip


local resizeGripBars = {}
for _, bar in ipairs({
    { 0.5, 0.5, 0.9 },
    { 0.68, 0.68, 0.54 },
    { 0.84, 0.84, 0.22 },
}) do
    local piece = Instance.new("Frame")
    piece.Name = "GripBar"
    piece.Active = false
    piece.AnchorPoint = Vector2.new(0.5, 0.5)
    piece.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    piece.BackgroundTransparency = 0.35
    piece.BorderSizePixel = 0
    piece.Position = UDim2.fromScale(bar[1], bar[2])
    piece.Rotation = -45
    piece.Size = UDim2.fromScale(bar[3], 0.13)
    piece.ZIndex = 121
    piece.Parent = resizeGrip
    table.insert(resizeGripBars, piece)
end

local function setResizeGripHighlight(highlighted)
    for _, piece in ipairs(resizeGripBars) do
        TweenService:Create(piece, TweenInfo.new(0.1), {
            BackgroundTransparency = highlighted and 0.05 or 0.35,
        }):Play()
    end
end

local resizeDragging = false
local resizeActiveTouch = nil
local resizeStartPointer = Vector2.new(0, 0)
local resizeStartSize = Vector2.new(0, 0)

local function applyResizeSize(widthPixels, heightPixels)
    local region = rootGui.AbsoluteSize
    if region.X <= 0 or region.Y <= 0 then
        return
    end
    Runtime.menuSize = UDim2.fromScale(
        math.clamp(
            widthPixels / region.X,
            RESIZE_LIMITS.MinWidth,
            RESIZE_LIMITS.MaxWidth
        ),
        math.clamp(
            heightPixels / region.Y,
            RESIZE_LIMITS.MinHeight,
            RESIZE_LIMITS.MaxHeight
        )
    )
    rootGui:SetAttribute("MenuSize", Runtime.menuSize)
    mainFrame.Size = Runtime.menuSize
    ContentScale.Refresh()
end

local function resizeFromInputPosition(position)
    local delta = Vector2.new(position.X, position.Y) - resizeStartPointer
    applyResizeSize(
        resizeStartSize.X + delta.X * 2,
        resizeStartSize.Y + delta.Y * 2
    )
end

resizeGrip.MouseEnter:Connect(function()
    setResizeGripHighlight(true)
end)

resizeGrip.MouseLeave:Connect(function()
    if not resizeDragging then
        setResizeGripHighlight(false)
    end
end)

resizeGrip.InputBegan:Connect(function(input)
    if resizeDragging or input.UserInputState ~= Enum.UserInputState.Begin then
        return
    end
    if input.UserInputType ~= Enum.UserInputType.MouseButton1
        and input.UserInputType ~= Enum.UserInputType.Touch
    then
        return
    end
    local pointer = Vector2.new(input.Position.X, input.Position.Y)
    local gripPosition = resizeGrip.AbsolutePosition
    local gripSize = resizeGrip.AbsoluteSize
    if pointer.X < gripPosition.X
        or pointer.X > gripPosition.X + gripSize.X
        or pointer.Y < gripPosition.Y
        or pointer.Y > gripPosition.Y + gripSize.Y
    then
        return
    end
    resizeDragging = true
    resizeActiveTouch = input.UserInputType == Enum.UserInputType.Touch
        and input
        or nil
    resizeStartPointer = Vector2.new(input.Position.X, input.Position.Y)
    resizeStartSize = mainFrame.AbsoluteSize
    setResizeGripHighlight(true)
end)

trackRootConnection(UserInputService.InputChanged:Connect(function(input)
    if not resizeDragging then
        return
    end
    if resizeActiveTouch then
        if input == resizeActiveTouch then
            resizeFromInputPosition(input.Position)
        end
    elseif input.UserInputType == Enum.UserInputType.MouseMovement then
        resizeFromInputPosition(input.Position)
    end
end))

trackRootConnection(UserInputService.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1
        or input == resizeActiveTouch
    then
        if resizeDragging then
            resizeDragging = false
            resizeActiveTouch = nil
            setResizeGripHighlight(false)
        end
    end
end))


ContentScale.OnChanged(function(scaleX, scaleY)
    resizeGrip.Position = UDim2.fromScale(
        1 - 0.002 / scaleX,
        1 - 0.005 / scaleY
    )
    resizeGrip.Size = UDim2.fromScale(0.05 / scaleX, 0.05 / scaleY)
end)



ContentScale.OnChanged(function(scaleX, scaleY)
    topBar.Size = UDim2.new(1, 0, 0.125 / scaleY, 0)
    objects.obj12.Position = UDim2.new(
        0.06700000166893005 / scaleX,
        0,
        0.44999998807907104,
        0
    )
    objects.obj12.Size = UDim2.new(
        0.11656716465950012 / scaleX,
        0,
        1.1833335161209106,
        0
    )
    objects.obj9.Position = UDim2.new(
        0.5687711238861084 / scaleX,
        0,
        0.5,
        0
    )
    objects.obj9.Size = UDim2.new(
        0.8620089292526245 / scaleX,
        0,
        0.7499999403953552,
        0
    )
    objects.obj14.Position = UDim2.new(
        1 - 0.045000016689300537 / scaleX,
        0,
        0.4339999854564667,
        0
    )
    objects.obj14.Size = UDim2.new(
        0.06637302041053772 / scaleX,
        0,
        0.6588137149810791,
        0
    )
end)

local normalTextFont = Font.new(
    "rbxasset://fonts/families/GothamSSm.json",
    Enum.FontWeight.ExtraBold,
    Enum.FontStyle.Normal
)

local italicTextFont = Font.new(
    "rbxasset://fonts/families/GothamSSm.json",
    Enum.FontWeight.ExtraBold,
    Enum.FontStyle.Italic
)

local shinyTextGradient = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 255, 255)),
    ColorSequenceKeypoint.new(0.486159176, Color3.fromRGB(255, 255, 255)),
    ColorSequenceKeypoint.new(0.519031167, Color3.fromRGB(221, 221, 221)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(236, 236, 236)),
})

local blueStrokeGradient = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(0, 36, 84)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(0, 31, 54)),
})

local function clearDirectGradients(container)
    for _, child in ipairs(container:GetChildren()) do
        if child:IsA("UIGradient") then
            child:Destroy()
        end
    end
end

local function getTextStroke(label)
    local stroke = label:FindFirstChildOfClass("UIStroke")
    if not stroke then
        stroke = Instance.new("UIStroke")
        stroke.Name = "UIStroke"
        stroke.Parent = label
    end
    return stroke
end

local function configureScaledStroke(stroke, color, thickness)
    stroke.ApplyStrokeMode = Enum.ApplyStrokeMode.Contextual
    stroke.Color = color
    stroke.Enabled = true
    stroke.LineJoinMode = Enum.LineJoinMode.Round
    stroke.Thickness = thickness
    stroke.Transparency = 0
    pcall(function()
        stroke.BorderOffset = UDim.new(0, 0)
        stroke.BorderStrokePosition = Enum.BorderStrokePosition.Outer
        stroke.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
    end)
end

local function applyShinyTextStyle(label, fontFace)
    if fontFace then
        label.FontFace = fontFace
    end
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.TextTransparency = 0
    label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    label.TextStrokeTransparency = 1
    label.TextScaled = true
    label.LineHeight = 1

    clearDirectGradients(label)

    local stroke = getTextStroke(label)
    clearDirectGradients(stroke)
    configureScaledStroke(stroke, Color3.fromRGB(255, 255, 255), 0.06499999761581421)

    local strokeGradient = Instance.new("UIGradient")
    strokeGradient.Name = "StrokeStyleGradient"
    strokeGradient.Color = blueStrokeGradient
    strokeGradient.Offset = Vector2.new(0, 0)
    strokeGradient.Rotation = 90
    strokeGradient.Transparency = NumberSequence.new(0)
    strokeGradient.Parent = stroke

    local textGradient = Instance.new("UIGradient")
    textGradient.Name = "TextStyleGradient"
    textGradient.Color = shinyTextGradient
    textGradient.Offset = Vector2.new(0, 0)
    textGradient.Rotation = 90
    textGradient.Transparency = NumberSequence.new(0)
    textGradient.Parent = label
end

local function applyPlainTextStyle(label)
    label.FontFace = normalTextFont
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.TextTransparency = 0
    label.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)
    label.TextStrokeTransparency = 1
    label.TextScaled = true
    label.LineHeight = 1

    clearDirectGradients(label)

    local stroke = getTextStroke(label)
    clearDirectGradients(stroke)
    configureScaledStroke(stroke, Color3.fromRGB(0, 0, 0), 0.07999999821186066)
end

local rebirthOuterGradient = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 193, 194)),
    ColorSequenceKeypoint.new(0.0570934266, Color3.fromRGB(255, 132, 123)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(239, 28, 28)),
})

local rebirthInnerGradient = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(255, 193, 194)),
    ColorSequenceKeypoint.new(0.0155709349, Color3.fromRGB(255, 132, 123)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(239, 28, 28)),
})

local function addRedGradient(parent, name, color)
    local gradient = Instance.new("UIGradient")
    gradient.Name = name
    gradient.Color = color
    gradient.Rotation = 90
    gradient.Parent = parent
    return gradient
end

local function addScaledStroke(parent, mode, thickness)
    local stroke = Instance.new("UIStroke")
    stroke.ApplyStrokeMode = mode
    stroke.Color = Color3.fromRGB(0, 0, 0)
    stroke.LineJoinMode = Enum.LineJoinMode.Round
    stroke.Thickness = thickness
    stroke.Transparency = 0
    pcall(function()
        stroke.BorderOffset = UDim.new(0, 0)
        stroke.BorderStrokePosition = Enum.BorderStrokePosition.Outer
        stroke.StrokeSizingMode = Enum.StrokeSizingMode.ScaledSize
    end)
    stroke.Parent = parent
    return stroke
end

local function createRebirthStyleButton(parent, text, layoutOrder)
    local button = Instance.new("TextButton")
    button.Name = text
    button.Active = true
    button.AnchorPoint = Vector2.new(0.5, 0.5)
    button.AutoButtonColor = false
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.LayoutOrder = layoutOrder
    button.Size = UDim2.new(1, 0, 0.130, 0)
    button.Text = ""
    button.ZIndex = 99
    button.Parent = parent

    local buttonScale = Instance.new("UIScale")
    buttonScale.Scale = 1
    buttonScale.Parent = button

    local base = Instance.new("Frame")
    base.Name = "Main"
    base.Active = false
    base.AnchorPoint = Vector2.new(0.5, 0.5)
    base.BackgroundColor3 = Color3.fromRGB(175, 0, 0)
    base.BorderSizePixel = 0
    base.Position = UDim2.fromScale(0.5, 0.5)
    base.Size = UDim2.fromScale(1, 0.92)
    base.ZIndex = 1
    base.Parent = button
    addScaledStroke(base, Enum.ApplyStrokeMode.Border, 0.0599999987)

    local colorFrame = Instance.new("Frame")
    colorFrame.Name = "ColorFrame"
    colorFrame.Active = false
    colorFrame.AnchorPoint = Vector2.new(0.5, 0)
    colorFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    colorFrame.BorderSizePixel = 0
    colorFrame.Position = UDim2.fromScale(0.5, 0)
    colorFrame.Size = UDim2.fromScale(1, 0.9)
    colorFrame.ZIndex = 1
    colorFrame.Parent = base
    addRedGradient(colorFrame, "RedGradient", rebirthOuterGradient)

    local highlight = Instance.new("Frame")
    highlight.Name = "Transparent"
    highlight.Active = false
    highlight.AnchorPoint = Vector2.new(0.5, 0.5)
    highlight.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    highlight.BorderSizePixel = 0
    highlight.Position = UDim2.fromScale(0.5, 0.5)
    highlight.Size = UDim2.fromScale(0.965, 0.88)
    highlight.ZIndex = 2
    highlight.Parent = colorFrame
    addRedGradient(highlight, "RedGradient", rebirthInnerGradient)

    local label = Instance.new("TextLabel")
    label.Name = "Label"
    label.Active = false
    label.AnchorPoint = Vector2.new(0.5, 0.5)
    label.BackgroundTransparency = 1
    label.BorderSizePixel = 0
    label.Position = UDim2.fromScale(0.5, 0.5)
    label.Size = UDim2.fromScale(0.94, 0.72)
    label.Text = text
    label.ZIndex = 6
    label.Parent = colorFrame
    applyShinyTextStyle(label, normalTextFont)

    local activeTween
    local hovered = false
    local function tweenScale(value, duration)
        if activeTween then
            activeTween:Cancel()
        end
        activeTween = TweenService:Create(
            buttonScale,
            TweenInfo.new(duration, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
            { Scale = value }
        )
        activeTween:Play()
    end

    button.MouseEnter:Connect(function()
        hovered = true
        tweenScale(1.035, 0.1)
    end)
    button.MouseLeave:Connect(function()
        hovered = false
        tweenScale(1, 0.1)
    end)
    button.MouseButton1Down:Connect(function()
        tweenScale(0.96, 0.055)
    end)
    button.MouseButton1Up:Connect(function()
        tweenScale(hovered and 1.035 or 1, 0.08)
    end)

    return button
end

local sideButtons = Instance.new("Frame")
sideButtons.Name = "SideButtons"
sideButtons.Active = false
sideButtons.AnchorPoint = Vector2.new(1, 0.5)
sideButtons.BackgroundTransparency = 1
sideButtons.BorderSizePixel = 0



sideButtons.Position = UDim2.new(-0.025, 0, 0.558, 0)
sideButtons.Size = UDim2.new(0.2612044513, 0, 1, 0)
sideButtons.ZIndex = 99
sideButtons.Parent = mainFrame














local ACCENT_GRADIENT = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(58, 255, 55)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(20, 109, 0)),
})


local ROW_ASPECT = 10
local ROW_WIDTH_SCALE = 0.97





local CONTROL_LAYOUT = {
    NarrowWidth = 0.20062215626239776,
    NarrowCenterX = 0.8846889218690012,
    WideWidth = 0.28,
    WideCenterX = 0.845,
}



local CHEVRON_COLOR = Color3.fromRGB(58, 255, 55)


local UNIT_CHEVRON_COLOR = Color3.fromRGB(255, 255, 255)


local MAX_CHIPS_PER_LINE = 4




local BALANCE_CHIP_LINES = false



local ACCENT_WIDTH_RATIO = 0.17



local SEARCH_MIN_OPTIONS = 5




local ROW_ASPECT_WITH_NOTE = 7.5




local NOTE_TITLE_SCALE = 0.9

local function addAccentGradient(parent)
    local gradient = Instance.new("UIGradient")
    gradient.Name = "AccentGradient"
    gradient.Color = ACCENT_GRADIENT
    gradient.Rotation = 90
    gradient.Parent = parent
    return gradient
end

local function attachScaleFeedback(button, hoverScale, pressScale)
    local scale = button:FindFirstChildOfClass("UIScale")
    if not scale then
        scale = Instance.new("UIScale")
        scale.Name = "InteractionScale"
        scale.Scale = 1
        scale.Parent = button
    end

    local activeTween
    local hovered = false

    local function play(value, duration)
        if activeTween then
            activeTween:Cancel()
        end
        activeTween = TweenService:Create(
            scale,
            TweenInfo.new(duration, Enum.EasingStyle.Quad, Enum.EasingDirection.Out),
            { Scale = value }
        )
        activeTween:Play()
    end

    button.MouseEnter:Connect(function()
        hovered = true
        play(hoverScale, 0.1)
    end)
    button.MouseLeave:Connect(function()
        hovered = false
        play(1, 0.1)
    end)
    button.MouseButton1Down:Connect(function()
        play(pressScale, 0.055)
    end)
    button.MouseButton1Up:Connect(function()
        play(hovered and hoverScale or 1, 0.08)
    end)

    return scale
end


local function buildRowPlate(parent, labelText)
    local main = Instance.new("Frame")
    main.Name = "Main"
    main.Active = false
    main.AnchorPoint = Vector2.new(0.5, 0.5)
    main.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    main.BackgroundTransparency = 0.5
    main.BorderSizePixel = 0
    main.Position = UDim2.fromScale(0.5, 0.5)
    main.Size = UDim2.fromScale(1, 0.85)
    main.ZIndex = 3
    main.Parent = parent
    addScaledStroke(main, Enum.ApplyStrokeMode.Border, 0.05)

    local label = Instance.new("TextLabel")
    label.Name = "Label"
    label.Active = false
    label.AnchorPoint = Vector2.new(0, 0.5)
    label.BackgroundTransparency = 1
    label.BorderSizePixel = 0
    label.Position = UDim2.fromScale(0.025, 0.5)
    
    
    label.Size = UDim2.fromScale(0.65, 0.64)
    label.Text = labelText
    label.TextWrapped = true
    label.TextXAlignment = Enum.TextXAlignment.Left
    label.TextYAlignment = Enum.TextYAlignment.Center
    label.ZIndex = 5
    label.Parent = main
    applyPlainTextStyle(label)

    return main, label
end


local function buildFixedRow(name, labelText)
    local row = Instance.new("Frame")
    row.Name = name
    row.Active = false
    row.AnchorPoint = Vector2.new(0.5, 0.5)
    row.BackgroundTransparency = 1
    row.BorderSizePixel = 0
    row.Position = UDim2.fromScale(0.5, 0.5)
    row.Size = UDim2.fromScale(ROW_WIDTH_SCALE, 0.6)
    row.ZIndex = 3

    local aspect = Instance.new("UIAspectRatioConstraint")
    aspect.AspectRatio = ROW_ASPECT
    aspect.AspectType = Enum.AspectType.FitWithinMaxSize
    aspect.DominantAxis = Enum.DominantAxis.Width
    aspect.Parent = row

    local main, label = buildRowPlate(row, labelText)
    return row, main, label
end




Runtime.activeDropdownCloser = nil

local function closeActiveDropdown()
    if Runtime.activeDropdownCloser then
        Runtime.activeDropdownCloser()
    end
end











local function createButtonRow(name, labelText, buttonText, confirmText)
    local row, main = buildFixedRow(name, labelText)
    local currentButtonText = tostring(buttonText or "")
    local currentConfirmText = tostring(confirmText or "")

    local button = Instance.new("TextButton")
    button.Name = "Action"
    button.Active = true
    button.AutoButtonColor = false
    button.AnchorPoint = Vector2.new(0.5, 0.5)
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.Position = UDim2.fromScale(CONTROL_LAYOUT.NarrowCenterX, 0.5)
    button.Size = UDim2.fromScale(CONTROL_LAYOUT.NarrowWidth, 0.68)
    button.Text = ""
    button.ZIndex = 6
    button.Parent = main
    attachScaleFeedback(button, 1.035, 0.96)

    local base = Instance.new("Frame")
    base.Name = "Main"
    base.Active = false
    base.AnchorPoint = Vector2.new(0.5, 0.5)
    base.BackgroundColor3 = Color3.fromRGB(175, 0, 0)
    base.BorderSizePixel = 0
    base.Position = UDim2.fromScale(0.5, 0.5)
    base.Size = UDim2.fromScale(1, 0.92)
    base.ZIndex = 1
    base.Parent = button
    addScaledStroke(base, Enum.ApplyStrokeMode.Border, 0.06)

    local colorFrame = Instance.new("Frame")
    colorFrame.Name = "ColorFrame"
    colorFrame.Active = false
    colorFrame.AnchorPoint = Vector2.new(0.5, 0)
    colorFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    colorFrame.BorderSizePixel = 0
    colorFrame.Position = UDim2.fromScale(0.5, 0)
    colorFrame.Size = UDim2.fromScale(1, 0.9)
    colorFrame.ZIndex = 1
    colorFrame.Parent = base
    addRedGradient(colorFrame, "RedGradient", rebirthOuterGradient)

    local highlight = Instance.new("Frame")
    highlight.Name = "Transparent"
    highlight.Active = false
    highlight.AnchorPoint = Vector2.new(0.5, 0.5)
    highlight.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    highlight.BorderSizePixel = 0
    highlight.Position = UDim2.fromScale(0.5, 0.5)
    highlight.Size = UDim2.fromScale(0.965, 0.88)
    highlight.ZIndex = 2
    highlight.Parent = colorFrame
    addRedGradient(highlight, "RedGradient", rebirthInnerGradient)

    local caption = Instance.new("TextLabel")
    caption.Name = "Label"
    caption.Active = false
    caption.AnchorPoint = Vector2.new(0.5, 0.5)
    caption.BackgroundTransparency = 1
    caption.BorderSizePixel = 0
    caption.Position = UDim2.fromScale(0.5, 0.5)
    caption.Size = UDim2.fromScale(0.9, 0.62)
    caption.Text = currentButtonText
    caption.TextWrapped = true
    caption.ZIndex = 6
    caption.Parent = colorFrame
    applyShinyTextStyle(caption, normalTextFont)

    
    local busy = false
    
    
    local function playPress()
        local scale = button:FindFirstChildOfClass("UIScale")
        if scale then
            TweenService:Create(
                scale,
                TweenInfo.new(
                    0.055,
                    Enum.EasingStyle.Quad,
                    Enum.EasingDirection.Out
                ),
                { Scale = 0.96 }
            ):Play()
            task.delay(0.07, function()
                if scale.Parent then
                    TweenService:Create(
                        scale,
                        TweenInfo.new(
                            0.09,
                            Enum.EasingStyle.Quad,
                            Enum.EasingDirection.Out
                        ),
                        { Scale = 1 }
                    ):Play()
                end
            end)
        end
        if busy or currentConfirmText == "" then
            return
        end
        busy = true
        caption.Text = currentConfirmText
        task.delay(0.9, function()
            caption.Text = currentButtonText
            busy = false
        end)
    end

    connectSafeActivation(button, playPress)

    return row, playPress
end







local function safeCallback(callback, ...)
    if type(callback) ~= "function" then
        return
    end

    local arguments = table.pack(...)
    task.spawn(function()
        local ok, message = xpcall(function()
            callback(table.unpack(arguments, 1, arguments.n))
        end, function(problem)
            return tostring(problem)
        end)
        if not ok then
            warn("[MIKOTOH UI] Callback: " .. tostring(message))
        end
    end)
end

local function copyTable(source)
    local result = {}
    if type(source) == "table" then
        for key, value in pairs(source) do
            result[key] = value
        end
    end
    return result
end

local function normalizeConfig(config, fallbackName)
    if type(config) == "string" then
        return {
            Name = config,
        }
    end
    assert(type(config) == "table", "config phai la string hoac table")

    local result = copyTable(config)
    result.Name = tostring(
        result.Name
            or result.Title
            or result.Text
            or fallbackName
            or "Unnamed"
    )
    assert(result.Name ~= "", "Name khong duoc de trong")
    return result
end

local function findDescendant(root, name)
    local found = root:FindFirstChild(name, true)
    assert(found, ("Khong tim thay thanh phan UI '%s'"):format(name))
    return found
end

































local function createLibrarySliderRow(config)
    local rawMinimum = tonumber(config.Min) or 0
    local rawMaximum = tonumber(config.Max) or 100
    local rawDefault = tonumber(config.Default)
    local requestedIncrement = tonumber(config.Increment or config.Step)

    local function decimalCount(value)
        value = tonumber(value)
        if not value then
            return 0
        end
        for places = 0, 6 do
            local scale = 10 ^ places
            if math.abs(value * scale - math.round(value * scale)) < 1e-6 then
                return places
            end
        end
        return 6
    end

    local configuredDecimals = config.AllowDecimals
    if configuredDecimals == nil then
        configuredDecimals = config.Decimals
    end

    local allowDecimals
    if configuredDecimals == nil then
        allowDecimals = decimalCount(requestedIncrement) > 0
            or decimalCount(rawMinimum) > 0
            or decimalCount(rawMaximum) > 0
            or decimalCount(rawDefault) > 0
    else
        allowDecimals = configuredDecimals == true
    end

    local configuredPlaces = tonumber(
        config.DecimalPlaces or config.Precision
    )
    local decimalPlaces = 0
    if allowDecimals then
        decimalPlaces = math.clamp(
            math.floor(
                configuredPlaces
                    or math.max(
                        1,
                        decimalCount(requestedIncrement),
                        decimalCount(rawMinimum),
                        decimalCount(rawMaximum),
                        decimalCount(rawDefault)
                    )
            ),
            1,
            6
        )
    end

    local function roundForMode(value)
        value = tonumber(value) or 0
        if not allowDecimals then
            return math.round(value)
        end
        local scale = 10 ^ decimalPlaces
        return math.round(value * scale) / scale
    end

    local minimum = roundForMode(rawMinimum)
    local maximum = roundForMode(rawMaximum)
    if maximum < minimum then
        minimum, maximum = maximum, minimum
    end

    local function normalizeIncrement(value)
        if allowDecimals then
            local quantum = 10 ^ -decimalPlaces
            local normalized = math.abs(tonumber(value) or quantum)
            normalized = roundForMode(normalized)
            return math.max(quantum, normalized)
        end
        return math.max(1, math.round(math.abs(tonumber(value) or 1)))
    end

    local increment = normalizeIncrement(requestedIncrement)

    
    
    
    
    local valueFormatFn = type(config.ValueFormat or config.InputFormat)
            == "function"
        and (config.ValueFormat or config.InputFormat)
        or nil
    local valueParseFn = type(config.ValueParse or config.InputParse)
            == "function"
        and (config.ValueParse or config.InputParse)
        or nil

    
    local function normalizeUnitOptions(list)
        local result = {}
        if type(list) ~= "table" then
            return result
        end
        for _, entry in ipairs(list) do
            if type(entry) == "string" or type(entry) == "number" then
                local text = tostring(entry)
                table.insert(result, { Name = text, Suffix = text })
            elseif type(entry) == "table" then
                local name = tostring(
                    entry.Name or entry.Text or entry.Suffix or "Unit"
                )
                local suffix = entry.Suffix ~= nil
                    and tostring(entry.Suffix)
                    or name
                table.insert(result, {
                    Name = name,
                    Suffix = suffix,
                    Prefix = entry.Prefix ~= nil
                        and tostring(entry.Prefix)
                        or nil,
                    Format = type(entry.Format) == "function"
                        and entry.Format
                        or nil,
                    FromBase = type(entry.FromBase) == "function"
                        and entry.FromBase
                        or nil,
                    ToBase = type(entry.ToBase) == "function"
                        and entry.ToBase
                        or nil,
                })
            end
        end
        return result
    end

    local unitConfig = config.Unit or config.Units
    if type(unitConfig) == "string" then
        unitConfig = { Options = { unitConfig } }
    elseif type(unitConfig) == "table"
        and unitConfig.Options == nil
        and unitConfig.List == nil
        and #unitConfig > 0
    then
        unitConfig = { Options = unitConfig }
    elseif type(unitConfig) ~= "table" then
        unitConfig = nil
    end

    local unitOptions = normalizeUnitOptions(
        unitConfig and (unitConfig.Options or unitConfig.List)
    )
    local unitEnabled = unitConfig ~= nil
        and unitConfig.Enabled ~= false
        and #unitOptions > 0
    local unitSelectorEnabled
    if unitConfig and unitConfig.Selector ~= nil then
        unitSelectorEnabled = unitConfig.Selector == true
    else
        unitSelectorEnabled = #unitOptions > 1
    end
    local unitCallback = unitConfig and unitConfig.Callback or nil
    local unitGlobalFormat = unitConfig
            and type(unitConfig.Format) == "function"
            and unitConfig.Format
        or nil
    
    local filteringValueText = false

    
    
    local valueColors = {
        Number = Color3.fromRGB(255, 255, 255),
        Prefix = CHEVRON_COLOR,
        Suffix = CHEVRON_COLOR,
    }
    local valueColorEnabled = true

    local function applyColorConfig(colors)
        if type(colors) ~= "table" then
            return
        end
        
        if typeof(colors.Unit) == "Color3" then
            valueColors.Prefix = colors.Unit
            valueColors.Suffix = colors.Unit
        end
        for _, key in ipairs({ "Number", "Prefix", "Suffix" }) do
            if typeof(colors[key]) == "Color3" then
                valueColors[key] = colors[key]
            end
        end
    end

    applyColorConfig(config.Colors)
    applyColorConfig(unitConfig and unitConfig.Colors)
    if config.ColorEnabled ~= nil then
        valueColorEnabled = config.ColorEnabled == true
    end
    if unitConfig and unitConfig.ColorEnabled ~= nil then
        valueColorEnabled = unitConfig.ColorEnabled == true
    end

    local function escapeRichText(text)
        local result = tostring(text)
        result = result:gsub("&", "&amp;")
        result = result:gsub("<", "&lt;")
        result = result:gsub(">", "&gt;")
        return result
    end

    local function colorTag(color, text)
        return ('<font color="rgb(%d,%d,%d)">%s</font>'):format(
            math.floor(color.R * 255 + 0.5),
            math.floor(color.G * 255 + 0.5),
            math.floor(color.B * 255 + 0.5),
            escapeRichText(text)
        )
    end

    
    local unitPrefix = ""
    if unitConfig and unitConfig.Prefix ~= nil then
        unitPrefix = tostring(unitConfig.Prefix)
    end
    local currentUnitIndex = 1

    local row, main, label = buildFixedRow(config.Name, config.Name)
    
    
    label.Size = UDim2.fromScale(0.43, 0.64)

    local sliderNote = tostring(config.Note or config.Description or "")
    local noteVScale = ROW_ASPECT_WITH_NOTE / ROW_ASPECT
    local noteLabel = Instance.new("TextLabel")
    noteLabel.Name = "Note"
    noteLabel.Active = false
    noteLabel.AnchorPoint = Vector2.new(0, 0.5)
    noteLabel.BackgroundTransparency = 1
    noteLabel.BorderSizePixel = 0
    noteLabel.Position = UDim2.fromScale(0.025, 0.755)
    noteLabel.Size = UDim2.fromScale(0.48, 0.3)
    noteLabel.Text = ""
    noteLabel.TextWrapped = false
    noteLabel.TextXAlignment = Enum.TextXAlignment.Left
    noteLabel.TextYAlignment = Enum.TextYAlignment.Center
    noteLabel.Visible = false
    noteLabel.ZIndex = 5
    noteLabel.Parent = main
    applyPlainTextStyle(noteLabel)
    noteLabel.TextTransparency = 0.32
    do
        local noteStroke = noteLabel:FindFirstChildOfClass("UIStroke")
        if noteStroke then
            noteStroke.Thickness = 0.06
            noteStroke.Transparency = 0.2
        end
    end

    local valueLabel = Instance.new("TextBox")
    valueLabel.Name = "Value"
    valueLabel.Active = true
    valueLabel.AnchorPoint = Vector2.new(0, 0.5)
    valueLabel.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    valueLabel.BackgroundTransparency = 0.6
    valueLabel.BorderSizePixel = 0
    valueLabel.ClearTextOnFocus = false
    valueLabel.MultiLine = false
    valueLabel.Position = UDim2.fromScale(0.525, 0.5)
    valueLabel.Size = UDim2.fromScale(0.095, 0.56)
    valueLabel.Text = ""
    valueLabel.TextEditable = true
    valueLabel.TextWrapped = false
    valueLabel.TextXAlignment = Enum.TextXAlignment.Center
    valueLabel.TextYAlignment = Enum.TextYAlignment.Center
    valueLabel.ZIndex = 5
    valueLabel.Parent = main
    applyPlainTextStyle(valueLabel)
    
    
    
    addScaledStroke(valueLabel, Enum.ApplyStrokeMode.Border, 0.1)

    local valuePadding = Instance.new("UIPadding")
    valuePadding.Name = "ValuePadding"
    
    
    valuePadding.PaddingLeft = UDim.new(0, 0)
    valuePadding.PaddingRight = UDim.new(0, 0)
    valuePadding.PaddingTop = UDim.new(0, 0)
    valuePadding.PaddingBottom = UDim.new(0, 0)
    valuePadding.Parent = valueLabel

    local track = Instance.new("Frame")
    track.Name = "Slider"
    track.Active = true
    track.AnchorPoint = Vector2.new(0.5, 0.5)
    track.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    track.BackgroundTransparency = 0.6
    track.BorderSizePixel = 0
    track.ClipsDescendants = false
    track.Position = UDim2.fromScale(0.8075, 0.5)
    track.Size = UDim2.fromScale(0.345, 0.45)
    track.ZIndex = 3
    track.Parent = main
    addScaledStroke(track, Enum.ApplyStrokeMode.Border, 0.1)

    local bar = Instance.new("Frame")
    bar.Name = "Bar"
    bar.Active = true
    bar.AnchorPoint = Vector2.new(0, 0.5)
    bar.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    bar.BorderSizePixel = 0
    bar.Position = UDim2.fromScale(0, 0.5)
    bar.Size = UDim2.fromScale(0.5, 1)
    bar.ZIndex = 4
    bar.Parent = track
    addAccentGradient(bar)

    local hold = Instance.new("Frame")
    hold.Name = "Hold"
    hold.Active = true
    hold.AnchorPoint = Vector2.new(0.5, 0.5)
    hold.BackgroundColor3 = Color3.fromRGB(89, 89, 89)
    hold.BackgroundTransparency = 1
    hold.BorderSizePixel = 0
    hold.ClipsDescendants = false
    hold.Position = UDim2.fromScale(0.5, 0.5)
    hold.Size = UDim2.fromScale(0.115, 1.2)
    hold.ZIndex = 5
    hold.Parent = track

    local holdStroke = addScaledStroke(
        hold,
        Enum.ApplyStrokeMode.Border,
        0.09
    )
    holdStroke.Color = Color3.fromRGB(39, 39, 39)

    local holdColor = Instance.new("Frame")
    holdColor.Name = "Color"
    holdColor.Active = false
    holdColor.AnchorPoint = Vector2.new(0.5, 0)
    holdColor.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    holdColor.BorderSizePixel = 0
    holdColor.Position = UDim2.fromScale(0.5, 0)
    holdColor.Size = UDim2.fromScale(1, 1)
    holdColor.ZIndex = 6
    holdColor.Parent = hold

    
    
    
    
    
    
    local unitDivider = Instance.new("Frame")
    unitDivider.Name = "UnitDivider"
    unitDivider.Active = false
    unitDivider.AnchorPoint = Vector2.new(0.5, 0.5)
    unitDivider.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    unitDivider.BackgroundTransparency = 0.3
    unitDivider.BorderSizePixel = 0
    unitDivider.Position = UDim2.fromScale(0.5935, 0.5)
    unitDivider.Size = UDim2.fromScale(0.0025, 0.36)
    unitDivider.Visible = false
    unitDivider.ZIndex = 7
    unitDivider.Parent = main

    local unitButton = Instance.new("TextButton")
    unitButton.Name = "UnitSelector"
    unitButton.Active = true
    unitButton.AutoButtonColor = false
    unitButton.AnchorPoint = Vector2.new(1, 0.5)
    unitButton.BackgroundTransparency = 1
    unitButton.BorderSizePixel = 0
    unitButton.Position = UDim2.fromScale(0.618, 0.5)
    unitButton.Size = UDim2.fromScale(0.025, 0.46)
    unitButton.Text = ""
    unitButton.Visible = false
    unitButton.ZIndex = 8
    unitButton.Parent = main

    local unitScale = Instance.new("UIScale")
    unitScale.Name = "InteractionScale"
    unitScale.Scale = 1
    unitScale.Parent = unitButton

    local unitCaret = Instance.new("Frame")
    unitCaret.Name = "Caret"
    unitCaret.Active = false
    unitCaret.AnchorPoint = Vector2.new(0.5, 0.5)
    unitCaret.BackgroundTransparency = 1
    unitCaret.BorderSizePixel = 0
    unitCaret.Position = UDim2.fromScale(0.5, 0.5)
    unitCaret.Size = UDim2.fromScale(0.75, 0.6)
    unitCaret.ZIndex = 8
    unitCaret.Parent = unitButton

    local unitCaretAspect = Instance.new("UIAspectRatioConstraint")
    unitCaretAspect.AspectRatio = 1
    unitCaretAspect.AspectType = Enum.AspectType.FitWithinMaxSize
    unitCaretAspect.DominantAxis = Enum.DominantAxis.Height
    unitCaretAspect.Parent = unitCaret

    for _, arm in ipairs({ { 0.335355, 45 }, { 0.664645, -45 } }) do
        local piece = Instance.new("Frame")
        piece.Name = "Arm"
        piece.Active = false
        piece.AnchorPoint = Vector2.new(0.5, 0.5)
        piece.BackgroundColor3 = UNIT_CHEVRON_COLOR
        piece.BorderSizePixel = 0
        piece.Position = UDim2.fromScale(arm[1], 0.535355)
        piece.Rotation = arm[2]
        piece.Size = UDim2.fromScale(0.6657, 0.2)
        piece.ZIndex = 9
        piece.Parent = unitCaret
    end

    local currentValue = minimum
    local dragging = false
    local activeTouch = nil
    local globalConnections = {}
    local setValue
    local setRange
    local setUnit
    local closeUnitMenu
    local refreshValueBoxGeometry

    local function formatValue(value)
        if not allowDecimals then
            return tostring(math.round(value))
        end
        return string.format(
            "%." .. tostring(decimalPlaces) .. "f",
            value
        )
    end

    
    
    local function numberText()
        if valueFormatFn then
            local ok, text = pcall(valueFormatFn, currentValue)
            if ok and text ~= nil then
                return tostring(text)
            end
            if not ok then
                
                
                
            end
        end
        return formatValue(currentValue)
    end

    
    
    
    
    
    
    local function displayValueText()
        local text = numberText()
        local unit = nil
        if unitEnabled then
            unit = unitOptions[currentUnitIndex]
        end

        local formatter = nil
        if unit then
            formatter = unitGlobalFormat or unit.Format
        end
        if formatter then
            local ok, composed = pcall(
                formatter,
                text,
                unit.Name,
                unit,
                currentValue
            )
            if ok and composed ~= nil then
                return tostring(composed), valueColorEnabled
            end
            if not ok then
                
                
                
            end
        end

        if not unit then
            if not valueColorEnabled then
                return text, false
            end
            return colorTag(valueColors.Number, text), true
        end

        local prefix = unit.Prefix or unitPrefix
        if not valueColorEnabled then
            return prefix .. text .. unit.Suffix, false
        end
        return colorTag(valueColors.Prefix, prefix)
            .. colorTag(valueColors.Number, text)
            .. colorTag(valueColors.Suffix, unit.Suffix), true
    end

    local function visibleCharacterCount(text)
        local plain = tostring(text or ""):gsub("<.->", "")
        local ok, length = pcall(utf8.len, plain)
        return (ok and length) or #plain
    end

    
    
    refreshValueBoxGeometry = function(text)
        local showUnit = unitEnabled and #unitOptions > 0
        local showSelector = showUnit and unitSelectorEnabled
        local minimumWidth = showUnit and 0.125 or 0.095
        local maximumWidth = showUnit and 0.195 or 0.175
        local baseCharacters = showUnit and 7 or 5
        local extraCharacters = math.max(
            0,
            visibleCharacterCount(text) - baseCharacters
        )
        local width = math.clamp(
            minimumWidth + extraCharacters * 0.0095,
            minimumWidth,
            maximumWidth
        )
        local leftEdge = 0.62 - width

        local hasNote = sliderNote ~= ""
        local controlScale = hasNote and noteVScale or 1
        valueLabel.Position = UDim2.fromScale(leftEdge, 0.5)
        valueLabel.Size = UDim2.fromScale(width, 0.56 * controlScale)
        track.Size = UDim2.fromScale(0.345, 0.45 * controlScale)
        unitDivider.Size = UDim2.fromScale(0.0025, 0.36 * controlScale)
        unitButton.Size = UDim2.fromScale(0.025, 0.46 * controlScale)

        local normalLabelWidth = showUnit and 0.43 or 0.45
        label.Position = UDim2.fromScale(0.025, hasNote and 0.34 or 0.5)
        label.Size = UDim2.fromScale(
            math.min(normalLabelWidth, math.max(0.28, leftEdge - 0.045)),
            hasNote and 0.64 * noteVScale * NOTE_TITLE_SCALE or 0.64
        )

        noteLabel.Text = sliderNote
        noteLabel.Visible = hasNote
        noteLabel.Size = UDim2.fromScale(math.max(0.2, leftEdge - 0.045), 0.3)
        local rowAspect = row:FindFirstChildOfClass("UIAspectRatioConstraint")
        if rowAspect then
            rowAspect.AspectRatio = hasNote and ROW_ASPECT_WITH_NOTE or ROW_ASPECT
        end
        row:SetAttribute(
            "ChilliResponsiveAspect",
            hasNote and ROW_ASPECT_WITH_NOTE or ROW_ASPECT
        )

        
        valuePadding.PaddingRight = UDim.new(
            showSelector
                and math.min(0.45, 0.034 / math.max(width, 0.001))
                or 0,
            0
        )
    end

    local function applyDisplayText()
        if valueLabel:IsFocused() then
            return
        end
        local text, richText = displayValueText()
        filteringValueText = true
        valueLabel.RichText = richText
        valueLabel.Text = text
        filteringValueText = false
        refreshValueBoxGeometry(text)
    end

    local function snapValue(value)
        value = math.clamp(tonumber(value) or minimum, minimum, maximum)
        if value <= minimum then
            return minimum
        end
        if value >= maximum then
            return maximum
        end
        local steps = math.floor(((value - minimum) / increment) + 0.5)
        local snapped = minimum + steps * increment
        return math.clamp(roundForMode(snapped), minimum, maximum)
    end

    local function updateUnitDisplay()
        applyDisplayText()
    end

    local function resolveUnitIndex(choice)
        if choice == nil or #unitOptions == 0 then
            return nil
        end
        if type(choice) == "number" then
            return math.clamp(math.floor(choice), 1, #unitOptions)
        end
        local wanted = tostring(choice)
        for index, unit in ipairs(unitOptions) do
            if unit.Name == wanted or unit.Suffix == wanted then
                return index
            end
        end
        return nil
    end

    
    
    
    
    
    
    local unitOverlay = nil
    local unitMenu = nil
    local unitMenuList = nil
    local unitMenuPadding = nil
    local unitMenuOpen = false
    local unitMenuConnections = {}

    local function disconnectUnitMenuConnections()
        for index = #unitMenuConnections, 1, -1 do
            local connection = unitMenuConnections[index]
            if connection.Connected then
                connection:Disconnect()
            end
            unitMenuConnections[index] = nil
        end
    end

    closeUnitMenu = function()
        if not unitMenuOpen then
            return
        end
        unitMenuOpen = false
        disconnectUnitMenuConnections()
        if unitOverlay then
            unitOverlay.Visible = false
        end
        TweenService:Create(
            unitCaret,
            TweenInfo.new(
                0.18,
                Enum.EasingStyle.Quad,
                Enum.EasingDirection.Out
            ),
            { Rotation = 0 }
        ):Play()
        if Runtime.activeDropdownCloser == closeUnitMenu then
            Runtime.activeDropdownCloser = nil
        end
    end

    local function ensureUnitOverlay()
        if unitOverlay then
            return
        end
        unitOverlay = Instance.new("TextButton")
        unitOverlay.Name = "UnitMenuOverlay"
        unitOverlay.Active = true
        unitOverlay.AutoButtonColor = false
        unitOverlay.BackgroundTransparency = 1
        unitOverlay.BorderSizePixel = 0
        unitOverlay.Position = UDim2.fromScale(0, 0)
        unitOverlay.Selectable = false
        unitOverlay.Size = UDim2.fromScale(1, 1)
        unitOverlay.Text = ""
        unitOverlay.Visible = false
        unitOverlay.ZIndex = 150
        unitOverlay.Parent = rootGui
        connectSafeActivation(unitOverlay, function()
            closeUnitMenu()
        end)

        unitMenu = Instance.new("Frame")
        unitMenu.Name = "UnitMenu"
        unitMenu.Active = true
        
        
        unitMenu.BackgroundTransparency = 1
        unitMenu.BorderSizePixel = 0
        unitMenu.ZIndex = 151
        unitMenu.Parent = unitOverlay

        unitMenuPadding = Instance.new("UIPadding")
        unitMenuPadding.Name = "MenuPadding"
        unitMenuPadding.Parent = unitMenu

        unitMenuList = Instance.new("UIListLayout")
        unitMenuList.Name = "MenuLayout"
        unitMenuList.FillDirection = Enum.FillDirection.Vertical
        unitMenuList.HorizontalAlignment = Enum.HorizontalAlignment.Center
        unitMenuList.VerticalAlignment = Enum.VerticalAlignment.Top
        unitMenuList.SortOrder = Enum.SortOrder.LayoutOrder
        unitMenuList.Parent = unitMenu
    end

    local function paintUnitMenuItems()
        if not unitMenu then
            return
        end
        for _, child in ipairs(unitMenu:GetChildren()) do
            if child:IsA("TextButton") then
                local chosen = child.LayoutOrder == currentUnitIndex
                child.BackgroundTransparency = chosen and 0.15 or 0.35
                child.TextTransparency = chosen and 0 or 0.15
            end
        end
    end

    local function rebuildUnitMenuItems(itemHeight)
        if not unitMenu then
            return
        end
        for _, child in ipairs(unitMenu:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy()
            end
        end
        for index, unit in ipairs(unitOptions) do
            local item = Instance.new("TextButton")
            item.Name = "Unit" .. index
            item.Active = true
            item.AutoButtonColor = false
            item.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
            item.BackgroundTransparency = 0.35
            item.BorderSizePixel = 0
            item.LayoutOrder = index
            item.Size = UDim2.new(1, 0, 0, itemHeight)
            item.Text = unit.Name
            item.TextWrapped = false
            item.ZIndex = 152
            item.Parent = unitMenu
            applyPlainTextStyle(item)
            addScaledStroke(item, Enum.ApplyStrokeMode.Border, 0.07)

            
            
            local itemPadding = Instance.new("UIPadding")
            itemPadding.Name = "ItemPadding"
            itemPadding.PaddingTop = UDim.new(0.18, 0)
            itemPadding.PaddingBottom = UDim.new(0.18, 0)
            itemPadding.PaddingLeft = UDim.new(0.08, 0)
            itemPadding.PaddingRight = UDim.new(0.08, 0)
            itemPadding.Parent = item

            item.MouseEnter:Connect(function()
                if index ~= currentUnitIndex then
                    item.BackgroundTransparency = 0.25
                end
            end)
            item.MouseLeave:Connect(function()
                paintUnitMenuItems()
            end)
            connectSafeActivation(item, function()
                setUnit(index, true)
                closeUnitMenu()
            end)
        end
        paintUnitMenuItems()
    end

    local function layoutUnitMenu()
        if not (unitOverlay and unitMenu) then
            return
        end
        
        local chipPosition = valueLabel.AbsolutePosition
        local chipSize = valueLabel.AbsoluteSize
        
        
        
        local originPosition = rootGui.AbsolutePosition
        local screenSize = rootGui.AbsoluteSize
        if screenSize.X <= 0 or screenSize.Y <= 0 then
            return
        end
        
        
        local itemHeight = math.max(14, math.floor(chipSize.Y * 0.85 + 0.5))
        local pad = math.max(2, math.floor(itemHeight * 0.14 + 0.5))
        
        
        local count = #unitOptions
        local totalWidth = math.max(math.floor(chipSize.X + 0.5), 24)
        local totalHeight = count * itemHeight
            + math.max(count - 1, 0) * pad

        unitMenuPadding.PaddingTop = UDim.new(0, 0)
        unitMenuPadding.PaddingBottom = UDim.new(0, 0)
        unitMenuPadding.PaddingLeft = UDim.new(0, 0)
        unitMenuPadding.PaddingRight = UDim.new(0, 0)
        unitMenuList.Padding = UDim.new(0, pad)
        for _, child in ipairs(unitMenu:GetChildren()) do
            if child:IsA("TextButton") then
                child.Size = UDim2.new(1, 0, 0, itemHeight)
            end
        end

        
        
        local x = chipPosition.X + chipSize.X - totalWidth
        x = math.min(
            x,
            originPosition.X + screenSize.X - totalWidth - 4
        )
        x = math.max(x, originPosition.X + 4)
        local y = chipPosition.Y + chipSize.Y + pad
        if y + totalHeight > originPosition.Y + screenSize.Y - 4 then
            y = chipPosition.Y - pad - totalHeight
        end
        y = math.max(y, originPosition.Y + 4)

        unitMenu.Position = UDim2.fromOffset(
            x - originPosition.X,
            y - originPosition.Y
        )
        unitMenu.Size = UDim2.fromOffset(totalWidth, totalHeight)
    end

    local function trackUnitChip()
        if not unitMenuOpen then
            return
        end
        local viewport = valueLabel:FindFirstAncestorOfClass(
            "ScrollingFrame"
        )
        if viewport then
            local viewportTop = viewport.AbsolutePosition.Y
            local viewportBottom = viewportTop + viewport.AbsoluteSize.Y
            local chipTop = valueLabel.AbsolutePosition.Y
            local chipBottom = chipTop + valueLabel.AbsoluteSize.Y
            if chipBottom < viewportTop or chipTop > viewportBottom then
                closeUnitMenu()
                return
            end
        end
        layoutUnitMenu()
    end

    local function openUnitMenu()
        if unitMenuOpen or #unitOptions == 0 then
            return
        end
        closeActiveDropdown()
        ensureUnitOverlay()
        local itemHeight = math.max(
            14,
            math.floor(valueLabel.AbsoluteSize.Y * 0.85 + 0.5)
        )
        rebuildUnitMenuItems(itemHeight)
        layoutUnitMenu()
        unitOverlay.Visible = true
        unitMenuOpen = true
        Runtime.activeDropdownCloser = closeUnitMenu
        TweenService:Create(
            unitCaret,
            TweenInfo.new(
                0.18,
                Enum.EasingStyle.Quad,
                Enum.EasingDirection.Out
            ),
            { Rotation = 180 }
        ):Play()
        
        
        
        
        
        table.insert(
            unitMenuConnections,
            valueLabel:GetPropertyChangedSignal("AbsolutePosition"):Connect(
                trackUnitChip
            )
        )
        table.insert(
            unitMenuConnections,
            valueLabel:GetPropertyChangedSignal("AbsoluteSize"):Connect(
                trackUnitChip
            )
        )
    end

    setUnit = function(choice, fireCallback)
        local index = resolveUnitIndex(choice)
        if not index then
            return false
        end
        local previousUnit = unitOptions[currentUnitIndex]
        local nextUnit = unitOptions[index]
        local previousName = previousUnit and previousUnit.Name or nil
        currentUnitIndex = index

        
        
        
        if previousUnit
            and previousUnit ~= nextUnit
            and (previousUnit.ToBase or nextUnit.FromBase)
        then
            local function convert(value)
                local result = value
                if previousUnit.ToBase then
                    local ok, converted = pcall(
                        previousUnit.ToBase,
                        result
                    )
                    if ok and tonumber(converted) then
                        result = tonumber(converted)
                    end
                end
                if nextUnit.FromBase then
                    local ok, converted = pcall(
                        nextUnit.FromBase,
                        result
                    )
                    if ok and tonumber(converted) then
                        result = tonumber(converted)
                    end
                end
                return result
            end
            local convertedValue = convert(currentValue)
            setRange(convert(minimum), convert(maximum), false)
            setValue(convertedValue, false)
        end

        updateUnitDisplay()
        paintUnitMenuItems()
        if fireCallback ~= false and nextUnit then
            safeCallback(
                unitCallback,
                nextUnit.Name,
                index,
                previousName
            )
        end
        return true
    end

    local function updateSliderLayout()
        local showUnit = unitEnabled and #unitOptions > 0
        local showSelector = showUnit and unitSelectorEnabled
        unitButton.Visible = showSelector
        unitDivider.Visible = showSelector
        
        
        if showSelector then
            unitDivider.Position = UDim2.fromScale(0.5935, 0.5)
            unitButton.Position = UDim2.fromScale(0.618, 0.5)
        end
        if not showSelector then
            closeUnitMenu()
        end
        updateUnitDisplay()
    end

    local unitScaleTween = nil
    local unitHovered = false
    local function tweenUnitScale(targetScale, duration)
        if unitScaleTween then
            unitScaleTween:Cancel()
        end
        unitScaleTween = TweenService:Create(
            unitScale,
            TweenInfo.new(
                duration,
                Enum.EasingStyle.Quad,
                Enum.EasingDirection.Out
            ),
            { Scale = targetScale }
        )
        unitScaleTween:Play()
    end

    unitButton.MouseEnter:Connect(function()
        unitHovered = true
        if unitSelectorEnabled then
            tweenUnitScale(1.03, 0.1)
        end
    end)
    unitButton.MouseLeave:Connect(function()
        unitHovered = false
        tweenUnitScale(1, 0.1)
    end)
    unitButton.MouseButton1Down:Connect(function()
        if unitSelectorEnabled then
            tweenUnitScale(0.97, 0.055)
        end
    end)
    unitButton.MouseButton1Up:Connect(function()
        tweenUnitScale(
            unitSelectorEnabled and unitHovered and 1.03 or 1,
            0.08
        )
    end)
    connectSafeActivation(unitButton, function()
        if not unitSelectorEnabled then
            return
        end
        if unitMenuOpen then
            closeUnitMenu()
        else
            openUnitMenu()
        end
    end)

    setValue = function(value, fireCallback)
        currentValue = snapValue(value)
        
        applyDisplayText()
        updateUnitDisplay()
        local alpha = 0
        if maximum > minimum then
            alpha = (currentValue - minimum) / (maximum - minimum)
        end
        
        local visualAlpha = math.clamp(alpha, 0.0575, 0.9425)
        bar.Size = UDim2.new(visualAlpha, 0, 1, 0)
        hold.Position = UDim2.new(visualAlpha, 0, 0.5, 0)
        if fireCallback ~= false then
            safeCallback(config.Callback, currentValue)
        end
    end

    setRange = function(newMinimum, newMaximum, fireCallback)
        local nextMinimum = tonumber(newMinimum)
        local nextMaximum = tonumber(newMaximum)
        assert(nextMinimum ~= nil, "Slider Min phai la number")
        assert(nextMaximum ~= nil, "Slider Max phai la number")

        minimum = roundForMode(nextMinimum)
        maximum = roundForMode(nextMaximum)
        if maximum < minimum then
            minimum, maximum = maximum, minimum
        end
        setValue(currentValue, fireCallback)
    end

    local function setDecimals(enabled, places, fireCallback)
        allowDecimals = enabled == true
        if allowDecimals then
            decimalPlaces = math.clamp(
                math.floor(tonumber(places) or math.max(decimalPlaces, 1)),
                1,
                6
            )
        else
            decimalPlaces = 0
        end

        minimum = roundForMode(minimum)
        maximum = roundForMode(maximum)
        if maximum < minimum then
            minimum, maximum = maximum, minimum
        end
        increment = allowDecimals and 10 ^ -decimalPlaces or 1
        setValue(currentValue, fireCallback)
    end

    local function setIncrement(value, fireCallback)
        increment = normalizeIncrement(value)
        setValue(currentValue, fireCallback)
    end

    local function sanitizeNumericText(text)
        text = tostring(text or "")
        local result = {}
        local hasDecimalSeparator = false
        for index = 1, #text do
            local character = text:sub(index, index)
            if character:match("%d") then
                table.insert(result, character)
            elseif (character == "." or character == ",")
                and allowDecimals
                and not hasDecimalSeparator
            then
                table.insert(result, ".")
                hasDecimalSeparator = true
            elseif character == "-"
                and minimum < 0
                and #result == 0
            then
                table.insert(result, character)
            end
        end
        return table.concat(result)
    end

    valueLabel:GetPropertyChangedSignal("Text"):Connect(function()
        if valueLabel:IsFocused() then
            refreshValueBoxGeometry(valueLabel.Text)
        end
        
        
        
        if filteringValueText
            or valueParseFn ~= nil
            or not valueLabel:IsFocused()
        then
            return
        end

        local originalText = valueLabel.Text
        local sanitizedText = sanitizeNumericText(originalText)
        if sanitizedText == originalText then
            return
        end

        local originalCursor = valueLabel.CursorPosition
        local sanitizedPrefix = sanitizedText
        if originalCursor > 0 then
            sanitizedPrefix = sanitizeNumericText(
                originalText:sub(1, originalCursor - 1)
            )
        end

        filteringValueText = true
        valueLabel.Text = sanitizedText
        if originalCursor > 0 then
            valueLabel.CursorPosition = math.clamp(
                #sanitizedPrefix + 1,
                1,
                #sanitizedText + 1
            )
        end
        filteringValueText = false
    end)

    local function commitTypedValue()
        local typedValue
        if valueParseFn then
            local ok, parsed = pcall(
                valueParseFn,
                valueLabel.Text,
                currentValue
            )
            if not ok then
                
                
                
            else
                typedValue = tonumber(parsed)
            end
        else
            typedValue = tonumber(valueLabel.Text)
        end
        if typedValue == nil then
            applyDisplayText()
            return
        end
        setValue(typedValue, true)
    end

    local function tweenValueFocus(focused)
        TweenService:Create(valueLabel, TweenInfo.new(0.16), {
            BackgroundTransparency = focused and 0.42 or 0.6,
        }):Play()
    end

    valueLabel.Focused:Connect(function()
        tweenValueFocus(true)
        
        
        filteringValueText = true
        valueLabel.RichText = false
        valueLabel.Text = formatValue(currentValue)
        filteringValueText = false
        refreshValueBoxGeometry(valueLabel.Text)
        task.defer(function()
            if valueLabel:IsFocused() then
                valueLabel.SelectionStart = 1
                valueLabel.CursorPosition = #valueLabel.Text + 1
            end
        end)
    end)

    valueLabel.FocusLost:Connect(function()
        tweenValueFocus(false)
        commitTypedValue()
    end)

    local function setFromScreenX(screenX)
        local width = math.max(track.AbsoluteSize.X, 1)
        local alpha = math.clamp(
            (screenX - track.AbsolutePosition.X) / width,
            0,
            1
        )
        setValue(minimum + (maximum - minimum) * alpha, true)
    end

    local function beginDrag(input)
        if dragging or input.UserInputState ~= Enum.UserInputState.Begin then
            return
        end
        if input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            activeTouch = nil
            setFromScreenX(input.Position.X)
        elseif input.UserInputType == Enum.UserInputType.Touch then
            dragging = true
            activeTouch = input
            setFromScreenX(input.Position.X)
        end
    end

    track.InputBegan:Connect(beginDrag)
    bar.InputBegan:Connect(beginDrag)
    hold.InputBegan:Connect(beginDrag)

    table.insert(globalConnections, trackRootConnection(UserInputService.InputChanged:Connect(function(input)
        if not dragging then
            return
        end
        if activeTouch then
            if input == activeTouch then
                setFromScreenX(input.Position.X)
            end
        elseif input.UserInputType == Enum.UserInputType.MouseMovement then
            setFromScreenX(input.Position.X)
        end
    end)))

    table.insert(globalConnections, trackRootConnection(UserInputService.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseButton1
            or input == activeTouch
        then
            dragging = false
            activeTouch = nil
        end
    end)))

    
    
    if unitConfig and unitConfig.Default ~= nil then
        local defaultUnitIndex = resolveUnitIndex(unitConfig.Default)
        if defaultUnitIndex then
            currentUnitIndex = defaultUnitIndex
        end
    end
    updateSliderLayout()
    updateUnitDisplay()
    setValue(config.Default ~= nil and config.Default or minimum, false)

    return row, {
        GetValue = function()
            return currentValue
        end,
        GetNote = function()
            return sliderNote
        end,
        SetNote = function(value)
            sliderNote = tostring(value or "")
            refreshValueBoxGeometry(valueLabel.Text)
        end,
        SetValue = setValue,
        GetRange = function()
            return minimum, maximum
        end,
        SetRange = setRange,
        SetMin = function(value, fireCallback)
            setRange(value, maximum, fireCallback)
        end,
        SetMax = function(value, fireCallback)
            setRange(minimum, value, fireCallback)
        end,
        GetDecimals = function()
            return allowDecimals, decimalPlaces
        end,
        SetDecimals = setDecimals,
        SetIncrement = setIncrement,
        SetValueFormat = function(formatFn)
            valueFormatFn = type(formatFn) == "function"
                and formatFn
                or nil
            applyDisplayText()
        end,
        SetValueParse = function(parseFn)
            valueParseFn = type(parseFn) == "function" and parseFn or nil
        end,
        GetValueColors = function()
            return {
                Number = valueColors.Number,
                Prefix = valueColors.Prefix,
                Suffix = valueColors.Suffix,
            }, valueColorEnabled
        end,
        SetValueColors = function(colors)
            applyColorConfig(colors)
            applyDisplayText()
        end,
        SetValueColorEnabled = function(enabled)
            valueColorEnabled = enabled == true
            applyDisplayText()
        end,
        GetUnit = function()
            local unit = unitOptions[currentUnitIndex]
            if not unit then
                return nil, nil
            end
            return unit.Name, currentUnitIndex
        end,
        SetUnit = setUnit,
        SetUnits = function(newOptions, selected, fireCallback)
            assert(
                type(newOptions) == "table",
                "SetUnits can danh sach don vi"
            )
            closeUnitMenu()
            local previousUnit = unitOptions[currentUnitIndex]
            unitOptions = normalizeUnitOptions(newOptions)
            local index = resolveUnitIndex(selected)
                or resolveUnitIndex(previousUnit and previousUnit.Name)
                or 1
            currentUnitIndex = math.clamp(
                index,
                1,
                math.max(#unitOptions, 1)
            )
            updateSliderLayout()
            updateUnitDisplay()
            if fireCallback ~= false
                and unitOptions[currentUnitIndex]
            then
                safeCallback(
                    unitCallback,
                    unitOptions[currentUnitIndex].Name,
                    currentUnitIndex,
                    previousUnit and previousUnit.Name
                )
            end
        end,
        SetUnitEnabled = function(enabled)
            unitEnabled = enabled == true
            updateSliderLayout()
        end,
        SetUnitSelectorEnabled = function(enabled)
            unitSelectorEnabled = enabled == true
            updateSliderLayout()
        end,
        SetUnitFormat = function(formatFn)
            unitGlobalFormat = type(formatFn) == "function"
                and formatFn
                or nil
            updateUnitDisplay()
        end,
        SetUnitCallback = function(callback)
            unitCallback = type(callback) == "function"
                and callback
                or nil
        end,
        Close = closeUnitMenu,
        Destroy = function()
            dragging = false
            activeTouch = nil
            closeUnitMenu()
            if unitOverlay then
                unitOverlay:Destroy()
                unitOverlay = nil
                unitMenu = nil
                unitMenuList = nil
                unitMenuPadding = nil
            end
            for index = #globalConnections, 1, -1 do
                local connection = globalConnections[index]
                if connection.Connected then
                    connection:Disconnect()
                end
                globalConnections[index] = nil
            end
        end,
    }
end

local function createLibraryToggleRow(config)
    local row, main, label = buildFixedRow(config.Name, config.Name)
    label.Size = UDim2.fromScale(0.72, 0.64)

    local switch = Instance.new("Frame")
    switch.Name = "Switch"
    switch.Active = false
    switch.AnchorPoint = Vector2.new(0.5, 0.5)
    switch.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    switch.BorderSizePixel = 0
    switch.Position = UDim2.fromScale(0.915, 0.5)
    switch.Size = UDim2.fromScale(0.142, 0.75)
    switch.ZIndex = 3
    switch.Parent = main
    addScaledStroke(switch, Enum.ApplyStrokeMode.Border, 0.06)

    local offGradient = Instance.new("UIGradient")
    offGradient.Name = "OFF"
    offGradient.Color = ColorSequence.new(Color3.fromRGB(0, 0, 0))
    offGradient.Rotation = 90
    offGradient.Transparency = NumberSequence.new(0.6)
    offGradient.Parent = switch

    local onGradient = Instance.new("UIGradient")
    onGradient.Name = "ON"
    onGradient.Color = ACCENT_GRADIENT
    onGradient.Rotation = 90
    onGradient.Parent = switch

    local knob = Instance.new("Frame")
    knob.Name = "Hold"
    knob.Active = false
    knob.AnchorPoint = Vector2.new(0.5, 0.5)
    knob.BackgroundColor3 = Color3.fromRGB(89, 89, 89)
    knob.BorderSizePixel = 0
    knob.Size = UDim2.fromScale(0.72, 0.72)
    knob.ZIndex = 5
    knob.Parent = switch
    addScaledStroke(knob, Enum.ApplyStrokeMode.Border, 0.09)

    local knobAspect = Instance.new("UIAspectRatioConstraint")
    knobAspect.AspectRatio = 1
    knobAspect.AspectType = Enum.AspectType.FitWithinMaxSize
    knobAspect.DominantAxis = Enum.DominantAxis.Width
    knobAspect.Parent = knob

    local knobColor = Instance.new("Frame")
    knobColor.Name = "Color"
    knobColor.Active = false
    knobColor.AnchorPoint = Vector2.new(0.5, 0)
    knobColor.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    knobColor.BorderSizePixel = 0
    knobColor.Position = UDim2.fromScale(0.5, 0)
    knobColor.Size = UDim2.fromScale(1, 0.9)
    knobColor.ZIndex = 6
    knobColor.Parent = knob

    local button = Instance.new("TextButton")
    button.Name = "Button"
    button.Active = true
    button.AutoButtonColor = false
    button.AnchorPoint = Vector2.new(0.5, 0.5)
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.Position = UDim2.fromScale(0.5, 0.5)
    button.Size = UDim2.fromScale(1, 1)
    button.Text = ""
    button.ZIndex = 99
    button.Parent = switch

    local enabled = config.Default == true

    local function setValue(value, fireCallback, animated)
        enabled = value == true
        offGradient.Enabled = not enabled
        onGradient.Enabled = enabled
        local target = UDim2.fromScale(enabled and 0.72 or 0.28, 0.5)
        if animated == false then
            knob.Position = target
        else
            TweenService:Create(
                knob,
                TweenInfo.new(
                    0.12,
                    Enum.EasingStyle.Quad,
                    Enum.EasingDirection.Out
                ),
                {
                    Position = target,
                }
            ):Play()
        end
        if fireCallback ~= false then
            safeCallback(config.Callback, enabled)
        end
    end

    connectSafeActivation(button, function()
        setValue(not enabled, true, true)
    end)

    setValue(enabled, false, false)

    return row, {
        GetValue = function()
            return enabled
        end,
        SetValue = function(value, fireCallback)
            setValue(value, fireCallback, true)
        end,
    }
end


local NOTE_LEFT = 0.025
local NOTE_GAP = 0.02
local NOTE_MAX_WIDTH = 0.94
local NOTE_MIN_WIDTH = 0.3

local function noteWidthFor(control)
    if not control then
        return NOTE_MAX_WIDTH
    end

    local controlLeft = control.Position.X.Scale
        - control.Size.X.Scale * control.AnchorPoint.X

    return math.clamp(
        controlLeft - NOTE_LEFT - NOTE_GAP,
        NOTE_MIN_WIDTH,
        NOTE_MAX_WIDTH
    )
end

local function addNoteToButtonRow(row, config, button)
    local vScale = ROW_ASPECT_WITH_NOTE / ROW_ASPECT
    local aspect = row:FindFirstChildOfClass(
        "UIAspectRatioConstraint"
    )
    local main = findDescendant(row, "Main")
    local title = main:FindFirstChild("Label")
    assert(title and title:IsA("TextLabel"), "Button row thieu Label")

    if aspect then
        aspect.AspectRatio = ROW_ASPECT_WITH_NOTE
    end
    row:SetAttribute(
        "ChilliResponsiveAspect",
        ROW_ASPECT_WITH_NOTE
    )

    title.Position = UDim2.fromScale(0.025, 0.34)
    title.Size = UDim2.fromScale(
        0.62,
        0.64 * vScale * NOTE_TITLE_SCALE
    )

    local note = Instance.new("TextLabel")
    note.Name = "Note"
    note.Active = false
    note.AnchorPoint = Vector2.new(0, 0.5)
    note.BackgroundTransparency = 1
    note.BorderSizePixel = 0
    note.Position = UDim2.fromScale(NOTE_LEFT, 0.755)
    note.Size = UDim2.fromScale(noteWidthFor(button), 0.3)
    note.Text = ""
    note.TextWrapped = false
    note.TextXAlignment = Enum.TextXAlignment.Left
    note.TextYAlignment = Enum.TextYAlignment.Center
    note.ZIndex = 5
    note.Parent = main
    applyPlainTextStyle(note)
    note.TextTransparency = 0.32

    local noteStroke = note:FindFirstChildOfClass("UIStroke")
    if noteStroke then
        noteStroke.Thickness = 0.06
        noteStroke.Transparency = 0.2
    end

    button.Size = UDim2.new(
        button.Size.X.Scale,
        button.Size.X.Offset,
        button.Size.Y.Scale * vScale,
        button.Size.Y.Offset
    )

    local currentNote = ""
    local function setNote(value)
        currentNote = tostring(value or "")
        note.Text = currentNote
    end
    setNote(config.Note or config.Description or "")

    return {
        GetNote = function()
            return currentNote
        end,
        SetNote = setNote,
    }
end

local function createLibraryButtonRow(config)
    local row, playPress = createButtonRow(
        config.Name,
        config.Name,
        tostring(config.ButtonText or config.Text or "Click"),
        tostring(config.ConfirmText or "Clicked!")
    )
    local button = findDescendant(row, "Action")
    local noteController = nil
    if config.Note ~= nil or config.Description ~= nil then
        noteController = addNoteToButtonRow(row, config, button)
    end
    connectSafeActivation(button, function()
        safeCallback(config.Callback)
    end)

    return row, {
        Press = function()
            
            if playPress then
                playPress()
            end
            safeCallback(config.Callback)
        end,
        GetNote = noteController and noteController.GetNote,
        SetNote = noteController and noteController.SetNote,
    }
end


local function createLibraryNoteToggleRow(config)
    
    
    local row, controller = createLibraryToggleRow(config)
    local vScale = ROW_ASPECT_WITH_NOTE / ROW_ASPECT
    local aspect = row:FindFirstChildOfClass("UIAspectRatioConstraint")
    local main = findDescendant(row, "Main")
    local title = findDescendant(main, "Label")
    local switch = findDescendant(main, "Switch")

    if aspect then
        aspect.AspectRatio = ROW_ASPECT_WITH_NOTE
    end

    title.Position = UDim2.fromScale(0.025, 0.34)
    title.Size = UDim2.fromScale(
        0.62,
        0.64 * vScale * NOTE_TITLE_SCALE
    )

    local note = Instance.new("TextLabel")
    note.Name = "Note"
    note.Active = false
    note.AnchorPoint = Vector2.new(0, 0.5)
    note.BackgroundTransparency = 1
    note.BorderSizePixel = 0
    note.Position = UDim2.fromScale(NOTE_LEFT, 0.755)
    note.Size = UDim2.fromScale(noteWidthFor(switch), 0.3)
    note.Text = tostring(config.Note or config.Description or "")
    note.TextWrapped = false
    note.TextXAlignment = Enum.TextXAlignment.Left
    note.TextYAlignment = Enum.TextYAlignment.Center
    note.ZIndex = 5
    note.Parent = main
    applyPlainTextStyle(note)
    note.TextTransparency = 0.32

    local noteStroke = note:FindFirstChildOfClass("UIStroke")
    if noteStroke then
        noteStroke.Thickness = 0.06
        noteStroke.Transparency = 0.2
    end

    switch.Size = UDim2.fromScale(0.142, 0.75 * vScale)

    
    
    
    local currentNote = note.Text
    controller.GetNote = function()
        return currentNote
    end
    controller.SetNote = function(value)
        currentNote = tostring(value or "")
        note.Text = currentNote
    end
    return row, controller
end






local TAB_LAYOUT = {
    Span = 0.895,
    NormalHeight = 0.130,
    GapRatio = 0.023 / 0.130,
}
local SECTION_ARROW = {
    Scale = 0.65,
    Spacing = 0.15,
    Arm = 0.22,
}
local SECTION_HEADER_ASPECT = 16

local sideButtonLayout = Instance.new("UIListLayout")
sideButtonLayout.FillDirection = Enum.FillDirection.Vertical
sideButtonLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center

sideButtonLayout.VerticalAlignment = Enum.VerticalAlignment.Top
sideButtonLayout.SortOrder = Enum.SortOrder.LayoutOrder
sideButtonLayout.Parent = sideButtons

local sideButtonPadding = Instance.new("UIPadding")
sideButtonPadding.Name = "TabPadding"
sideButtonPadding.PaddingTop = UDim.new(0.067, 0)
sideButtonPadding.Parent = sideButtons






local TabColumns = {}
do
    local function buildColumn(name, anchorX, edgeX)
        local frame = Instance.new("Frame")
        frame.Name = name
        frame.Active = false
        frame.AnchorPoint = Vector2.new(anchorX, 0.5)
        frame.BackgroundTransparency = 1
        frame.BorderSizePixel = 0
        frame.Position = UDim2.new(edgeX, 0, 0.558, 0)
        frame.Size = UDim2.new(0.2612044513, 0, 1, 0)
        frame.ZIndex = 99
        frame.Parent = mainFrame

        local layout = Instance.new("UIListLayout")
        layout.Name = "TabLayout"
        layout.FillDirection = Enum.FillDirection.Vertical
        layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
        layout.VerticalAlignment = Enum.VerticalAlignment.Top
        layout.SortOrder = Enum.SortOrder.LayoutOrder
        layout.Parent = frame

        local padding = Instance.new("UIPadding")
        padding.Name = "TabPadding"
        padding.PaddingTop = UDim.new(0.077, 0)
        padding.Parent = frame

        return {
            Frame = frame,
            Layout = layout,
            Padding = padding,
            AnchorX = anchorX,
            EdgeX = edgeX,
        }
    end

    TabColumns.Left = {
        Frame = sideButtons,
        Layout = sideButtonLayout,
        Padding = sideButtonPadding,
        AnchorX = 1,
        EdgeX = -0.025,
        CenterY = 0.558,
        TopPadding = 0.067,
        Width = 0.2612044513,
        GapRatio = TAB_LAYOUT.GapRatio,
    }
    TabColumns.Right = buildColumn("SideButtonsRight", 0, 1.025)
    TabColumns.Right.CenterY = 0.558
    TabColumns.Right.TopPadding = 0.067
    TabColumns.Right.Width = 0.2612044513
end



ContentScale.OnChanged(function(scaleX, scaleY)
    for _, column in pairs(TabColumns) do
        local gap = (column.EdgeX < 0) and (-0.025 / scaleX)
            or (1 + 0.025 / scaleX)
        column.Frame.Position = UDim2.new(
            gap,
            0,
            column.CenterY or 0.558,
            0
        )
        column.Frame.Size = UDim2.new(
            (column.Width or 0.2612044513) / scaleX,
            0,
            1,
            0
        )
        column.Padding.PaddingTop = UDim.new(
            (column.TopPadding or 0.067) / scaleY,
            0
        )
    end
end)


local function createSectionHeader(title, layoutOrder, clipViewport)
    local header = Instance.new("TextLabel")
    header.Name = title
    header.Active = false
    header.AnchorPoint = Vector2.new(0.5, 0.5)
    header.BackgroundTransparency = 1
    header.BorderSizePixel = 0
    header.LayoutOrder = layoutOrder
    
    
    
    header.Size = UDim2.new(0.97, 0, 0, 36)
    header.Text = title
    header.TextWrapped = true
    header.TextXAlignment = Enum.TextXAlignment.Center
    header.TextYAlignment = Enum.TextYAlignment.Center
    header.ZIndex = 4

    applyShinyTextStyle(header, normalTextFont)

    
    
    local arrowClip = Instance.new("Frame")
    arrowClip.Name = "ArrowClip"
    arrowClip.Active = false
    arrowClip.AnchorPoint = Vector2.new(0.5, 0.5)
    arrowClip.BackgroundTransparency = 1
    arrowClip.BorderSizePixel = 0
    arrowClip.ClipsDescendants = true
    arrowClip.Position = UDim2.fromScale(0.4, 0.5)
    arrowClip.Size = UDim2.fromOffset(1, 1)
    arrowClip.ZIndex = header.ZIndex + 2
    arrowClip.Parent = header

    local arrow = Instance.new("Frame")
    arrow.Name = "Arrow"
    arrow.Active = false
    arrow.AnchorPoint = Vector2.new(0.5, 0.5)
    arrow.BackgroundTransparency = 1
    arrow.BorderSizePixel = 0
    arrow.Position = UDim2.fromScale(0.5, 0.5)
    arrow.Size = UDim2.fromOffset(1, 1)
    arrow.ZIndex = header.ZIndex + 2
    arrow.Parent = arrowClip

    local armThickness = SECTION_ARROW.Arm
    local armInset = armThickness / 2
    local armLength = 0.56569 + armInset
    local armCenterX = 0.30 + 0.35355 * armInset
    local armCenterY = 0.50 + 0.35355 * armInset
    local outlineWidth = 0.06499999761581421 / SECTION_ARROW.Scale

    local function addChevronLayer(thickness, length, colors, zIndex)
        for _, arm in ipairs({
            {
                armCenterX,
                45,
            },
            {
                1 - armCenterX,
                -45,
            },
        }) do
            local piece = Instance.new("Frame")
            piece.Name = "Arm"
            piece.Active = false
            piece.AnchorPoint = Vector2.new(0.5, 0.5)
            piece.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            piece.BorderSizePixel = 0
            piece.Position = UDim2.fromScale(arm[1], armCenterY)
            piece.Rotation = arm[2]
            piece.Size = UDim2.fromScale(length, thickness)
            piece.ZIndex = zIndex
            piece.Parent = arrow

            local gradient = Instance.new("UIGradient")
            gradient.Color = colors
            gradient.Rotation = 90
            gradient.Parent = piece
        end
    end

    addChevronLayer(
        armThickness + outlineWidth * 2,
        armLength + outlineWidth * 2,
        blueStrokeGradient,
        header.ZIndex + 2
    )
    addChevronLayer(
        armThickness,
        armLength,
        shinyTextGradient,
        header.ZIndex + 3
    )

    local visualHalfWidth = 0.5
        - (
            armCenterX
            - (armLength + armThickness + outlineWidth * 4) * 0.35355
        )

    local function layoutArrow()
        local width = header.AbsoluteSize.X
        local height = header.AbsoluteSize.Y
        if width <= 0 or height <= 0 then
            return
        end
        local size = height * SECTION_ARROW.Scale
        local spacing = height * SECTION_ARROW.Spacing
        local textWidth = math.min(header.TextBounds.X, width)
        local reach = size * visualHalfWidth
        local centerX = (width - textWidth) / 2 - spacing - reach
        
        
        arrowClip.Size = UDim2.fromOffset(size * 1.35, size * 1.35)
        arrowClip.Position = UDim2.new(
            0,
            math.max(centerX, reach),
            0.5,
            0
        )
        arrow.Size = UDim2.fromOffset(size, size)
    end

    local function updateArrowVisibility()
        if not clipViewport then
            arrowClip.Visible = true
            return
        end

        local viewportTop = clipViewport.AbsolutePosition.Y
        local viewportBottom = viewportTop + clipViewport.AbsoluteSize.Y
        local arrowTop = arrowClip.AbsolutePosition.Y
        local arrowBottom = arrowTop + arrowClip.AbsoluteSize.Y
        arrowClip.Visible = arrowTop >= viewportTop
            and arrowBottom <= viewportBottom
    end

    header:GetPropertyChangedSignal("TextBounds"):Connect(layoutArrow)
    header:GetPropertyChangedSignal("AbsoluteSize"):Connect(layoutArrow)
    header:GetPropertyChangedSignal("AbsolutePosition"):Connect(
        updateArrowVisibility
    )
    arrowClip:GetPropertyChangedSignal("AbsolutePosition"):Connect(
        updateArrowVisibility
    )
    arrowClip:GetPropertyChangedSignal("AbsoluteSize"):Connect(
        updateArrowVisibility
    )
    if clipViewport then
        clipViewport:GetPropertyChangedSignal("CanvasPosition"):Connect(
            updateArrowVisibility
        )
        clipViewport:GetPropertyChangedSignal("AbsolutePosition"):Connect(
            updateArrowVisibility
        )
        clipViewport:GetPropertyChangedSignal("AbsoluteSize"):Connect(
            updateArrowVisibility
        )
    end
    task.defer(layoutArrow)
    task.defer(updateArrowVisibility)

    local button = Instance.new("TextButton")
    button.Name = "SectionButton"
    button.Active = true
    button.AutoButtonColor = false
    button.BackgroundTransparency = 1
    button.BorderSizePixel = 0
    button.Position = UDim2.fromScale(0, 0)
    button.Size = UDim2.fromScale(1, 1)
    button.Text = ""
    button.ZIndex = header.ZIndex + 4
    button.Parent = header

    return header, arrow, button
end





-- API reduzida; os construtores visuais acima sao os da biblioteca Chilli.
local WindowMethods, TabMethods, SectionMethods, OptionMethods = {}, {}, {}, {}
WindowMethods.__index = WindowMethods
TabMethods.__index = TabMethods
SectionMethods.__index = SectionMethods
OptionMethods.__index = OptionMethods
local ApiImpl = {}
local function assertObject(object, expectedKind)
    assert(type(object) == "table" and object._kind == expectedKind
        and not object._destroyed, expectedKind .. " foi destruido ou e invalido")
end
ApiImpl[85] = function(option)
    if option._destroyed then return end
    option._destroyed = true
    if option._controller.Destroy then option._controller.Destroy() end
    for _, connection in ipairs(option._connections or {}) do connection:Disconnect() end
    option.Instance:Destroy()
    local section = option.Section
    section._optionByName[option.Name] = nil
    for index, entry in ipairs(section.Options) do
        if entry == option then table.remove(section.Options, index); break end
    end
    if not section._destroyed then task.defer(section._refreshHeight) end
end

ApiImpl[87] = function(self, expanded, animated)
    assertObject(self, "Section")
    expanded = expanded == true
    if self.Expanded == expanded and animated ~= false then
        return self
    end

    closeActiveDropdown()
    self._measureExpandedHeight()
    self.Expanded = expanded
    self._animationSerial = self._animationSerial + 1
    local serial = self._animationSerial
    local targetHeight = expanded and self._expandedHeight or 0
    local targetRotation = expanded and 0 or -90

    if self._heightTween then
        self._heightTween:Cancel()
    end
    if self._arrowTween then
        self._arrowTween:Cancel()
    end

    
    
    
    self._group.ClipsDescendants = true

    if expanded then
        
        
        self._group.Visible = true
    end

    if animated == false then
        self._group.Size = UDim2.new(1, 0, 0, targetHeight)
        self._group.Visible = expanded
        self._group.ClipsDescendants = not expanded
        self._arrow.Rotation = targetRotation
        task.defer(self._refreshContainer)
        task.defer(self.Tab._updateCanvas)
        return self
    end

    local info = TweenInfo.new(
        0.28,
        Enum.EasingStyle.Quint,
        Enum.EasingDirection.Out
    )
    self._heightTween = TweenService:Create(
        self._group,
        info,
        {
            Size = UDim2.new(1, 0, 0, targetHeight),
        }
    )
    self._arrowTween = TweenService:Create(
        self._arrow,
        TweenInfo.new(
            0.24,
            Enum.EasingStyle.Quad,
            Enum.EasingDirection.Out
        ),
        {
            Rotation = targetRotation,
        }
    )

    self._heightTween.Completed:Connect(function()
        if serial == self._animationSerial then
            self._heightTween = nil
            self._arrowTween = nil
            self._group.Visible = self.Expanded
            self._group.ClipsDescendants = not self.Expanded
            self._refreshHeight()
            self._refreshContainer()
        end
    end)
    self._heightTween:Play()
    self._arrowTween:Play()
    return self
end

ApiImpl[88] = function(self)
    return ApiImpl[87](self, not self.Expanded, true)
end

ApiImpl[89] = function(self)
    assertObject(self, "Section")
    self._destroyed = true
    closeActiveDropdown()
    self._animationSerial = self._animationSerial + 1
    if self._heightTween then
        self._heightTween:Cancel()
        self._heightTween = nil
    end
    if self._arrowTween then
        self._arrowTween:Cancel()
        self._arrowTween = nil
    end
    for index = #self.Options, 1, -1 do
        local option = self.Options[index]
        if option and not option._destroyed then
            ApiImpl[85](option)
        end
    end
    for index = #self._connections, 1, -1 do
        local connection = self._connections[index]
        if connection.Connected then
            connection:Disconnect()
        end
        self._connections[index] = nil
    end
    self.Tab._sectionByName[self.Name] = nil
    for index, section in ipairs(self.Tab.Sections) do
        if section == self then
            table.remove(self.Tab.Sections, index)
            break
        end
    end
    self._container:Destroy()
    if not self.Tab._destroyed then
        task.defer(self.Tab._updateCanvas)
    end
end

ApiImpl[90] = function(self, config)
    assertObject(self, "Tab")
    local sectionConfig = normalizeConfig(config, "Section")
    assert(
        not self._sectionByName[sectionConfig.Name],
        ("Section '%s' da ton tai trong Tab '%s'")
            :format(sectionConfig.Name, self.Name)
    )

    local initiallyExpanded = sectionConfig.Expanded
    if initiallyExpanded == nil then
        initiallyExpanded = self.SectionsExpanded
    end

    self._nextSectionOrder = self._nextSectionOrder + 1

    
    
    
    
    
    
    
    
    
    local container = Instance.new("Frame")
    container.Name = sectionConfig.Name .. "Section"
    container.Active = false
    container.BackgroundTransparency = 1
    container.BorderSizePixel = 0
    container.ClipsDescendants = false
    container.LayoutOrder = self._nextSectionOrder
    container.Size = UDim2.new(1, 0, 0, 0)
    container.ZIndex = 3
    container.Parent = self.Page

    local sectionLayout = Instance.new("UIListLayout")
    sectionLayout.Name = "SectionLayout"
    sectionLayout.FillDirection = Enum.FillDirection.Vertical
    sectionLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    sectionLayout.VerticalAlignment = Enum.VerticalAlignment.Top
    sectionLayout.Padding = UDim.new(0, 2)
    sectionLayout.SortOrder = Enum.SortOrder.LayoutOrder
    sectionLayout.Parent = container

    local sectionDisplayName = tostring(
        sectionConfig.DisplayName or sectionConfig.Name
    )
    local header, arrow, headerButton = createSectionHeader(
        sectionDisplayName,
        1,
        self.Page
    )
    header.Parent = container

    local lastHeaderWidth = -1
    local function updateHeaderHeight(force)
        if not force and (Runtime.windowAnimating or not self.Page.Visible) then
            return
        end
        local availableWidth = container.AbsoluteSize.X
        if availableWidth <= 0 then
            availableWidth = self.Page.AbsoluteSize.X
        end
        if availableWidth <= 0 then
            return
        end
        local scale = ContentScale.X
        local referenceWidth = availableWidth / scale
        if math.abs(referenceWidth - lastHeaderWidth) < 0.5 then
            return
        end
        lastHeaderWidth = referenceWidth
        local headerHeight = math.max(
            1,
            math.floor(
                referenceWidth * 0.97 / SECTION_HEADER_ASPECT + 0.5
            )
        )
        local headerWidthScale = 0.97
        if RESIZE_KEEPS_OPTION_WIDTH then
            headerWidthScale = 0.97 / scale
        end
        header.Size = UDim2.new(headerWidthScale, 0, 0, headerHeight)
    end

    ContentScale.OnChanged(function()
        if container.Parent == nil then
            return false
        end
        updateHeaderHeight()
    end)

    local group = Instance.new("Frame")
    group.Name = "CollapsibleContent"
    group.Active = false
    group.BackgroundTransparency = 1
    group.BorderSizePixel = 0
    group.ClipsDescendants = true
    group.LayoutOrder = 2
    group.Size = UDim2.new(1, 0, 0, 0)
    group.ZIndex = 3
    group.Parent = container

    local content = Instance.new("Frame")
    content.Name = "Content"
    content.Active = false
    content.BackgroundTransparency = 1
    content.BorderSizePixel = 0
    content.Position = UDim2.fromScale(0, 0)
    content.Size = UDim2.new(1, 0, 0, 1)
    content.ZIndex = 3
    content.Parent = group

    local contentLayout = Instance.new("UIListLayout")
    contentLayout.Name = "OptionLayout"
    contentLayout.FillDirection = Enum.FillDirection.Vertical
    contentLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    contentLayout.VerticalAlignment = Enum.VerticalAlignment.Top
    contentLayout.Padding = UDim.new(0, 0)
    contentLayout.SortOrder = Enum.SortOrder.LayoutOrder
    contentLayout.Parent = content

    local section = setmetatable({
        _kind = "Section",
        _destroyed = false,
        _container = container,
        _header = header,
        _arrow = arrow,
        _group = group,
        _content = content,
        _connections = {},
        _layout = contentLayout,
        _optionByName = {},
        _sectionLayout = sectionLayout,
        _expandedHeight = 0,
        _nextOptionOrder = 0,
        _animationSerial = 0,
        DisplayName = sectionDisplayName,
        Expanded = initiallyExpanded ~= false,
        Name = sectionConfig.Name,
        Options = {},
        Tab = self,
    }, SectionMethods)

    local containerRefreshQueued = false
    section._refreshContainer = function()
        if containerRefreshQueued or section._destroyed then
            return
        end
        containerRefreshQueued = true
        task.defer(function()
            containerRefreshQueued = false
            if section._destroyed then
                return
            end
            local measuredHeight = math.max(
                0,
                math.ceil(sectionLayout.AbsoluteContentSize.Y)
            )
            local summedHeight = 0
            local visibleCount = 0
            for _, child in ipairs(container:GetChildren()) do
                if child:IsA("GuiObject") and child.Visible then
                    visibleCount = visibleCount + 1
                    summedHeight = summedHeight + math.max(
                        0,
                        child.AbsoluteSize.Y
                    )
                end
            end
            if visibleCount > 1 then
                summedHeight = summedHeight
                    + (visibleCount - 1)
                        * (
                            sectionLayout.Padding.Offset
                            + sectionLayout.Padding.Scale
                                * container.AbsoluteSize.Y
                        )
            end
            local sectionHeight = math.max(
                measuredHeight,
                math.ceil(summedHeight)
            )
            container.Size = UDim2.new(1, 0, 0, sectionHeight)
            self._updateCanvas()
        end)
    end

    
    
    
    local heightRefreshQueued = false
    local heightRefreshAgain = false
    section._measureExpandedHeight = function()
        local measuredHeight = math.max(
            0,
            math.ceil(contentLayout.AbsoluteContentSize.Y)
        )
        local summedHeight = 0
        local visibleCount = 0
        for _, child in ipairs(content:GetChildren()) do
            if child:IsA("GuiObject") and child.Visible then
                visibleCount = visibleCount + 1
                local childHeight = child.AbsoluteSize.Y
                if childHeight <= 0 then
                    childHeight = math.max(0, child.Size.Y.Offset)
                end
                summedHeight = summedHeight + childHeight
            end
        end
        if visibleCount > 1 then
            summedHeight = summedHeight
                + (visibleCount - 1)
                    * (
                        contentLayout.Padding.Offset
                        + contentLayout.Padding.Scale
                            * content.AbsoluteSize.Y
                    )
        end
        section._expandedHeight = math.max(
            measuredHeight,
            math.ceil(summedHeight)
        )
        return section._expandedHeight
    end

    local function applyMeasuredHeight()
        section._measureExpandedHeight()
        content.Size = UDim2.new(
            1,
            0,
            0,
            math.max(section._expandedHeight, 1)
        )
        if not section._heightTween then
            group.Size = UDim2.new(
                1,
                0,
                0,
                section.Expanded and section._expandedHeight or 0
            )
            group.Visible = section.Expanded
            group.ClipsDescendants = not section.Expanded
        end
        section._refreshContainer()
    end

    section._refreshHeight = function()
        if section._destroyed then
            return
        end
        if heightRefreshQueued then
            heightRefreshAgain = true
            return
        end
        heightRefreshQueued = true
        task.defer(function()
            if section._destroyed then
                heightRefreshQueued = false
                return
            end
            
            
            
            
            if Runtime.windowAnimating then
                heightRefreshQueued = false
                task.delay(0.12, section._refreshHeight)
                return
            end
            
            
            if not section.Tab.Page.Visible then
                heightRefreshQueued = false
                return
            end
            applyMeasuredHeight()
            heightRefreshQueued = false
            if heightRefreshAgain then
                heightRefreshAgain = false
                section._refreshHeight()
            end
        end)
    end

    
    section._refreshLayout = function()
        if section._destroyed then
            return
        end
        updateHeaderHeight(true)
        for _, updater in ipairs(section._rowUpdaters or {}) do
            updater(true)
        end
        applyMeasuredHeight()
        section._refreshContainer()
    end

    local stabilizationSerial = 0
    local stabilizationRunning = false
    section._stabilizeLayout = function()
        stabilizationSerial = stabilizationSerial + 1
        if stabilizationRunning then
            return
        end
        stabilizationRunning = true
        task.spawn(function()
            local observedSerial = -1
            local quietFrames = 0
            while quietFrames < 2 and not section._destroyed do
                RunService.Heartbeat:Wait()
                applyMeasuredHeight()
                if observedSerial == stabilizationSerial then
                    quietFrames = quietFrames + 1
                else
                    observedSerial = stabilizationSerial
                    quietFrames = 0
                end
            end
            stabilizationRunning = false
            if not section._destroyed
                and observedSerial ~= stabilizationSerial
            then
                section._stabilizeLayout()
            end
        end)
    end

    table.insert(section._connections, contentLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(
        section._refreshHeight
    ))
    table.insert(section._connections, self.Page:GetPropertyChangedSignal("AbsoluteSize"):Connect(
        section._refreshHeight
    ))
    table.insert(section._connections, self.Page:GetPropertyChangedSignal("AbsoluteSize"):Connect(
        updateHeaderHeight
    ))
    table.insert(section._connections, container:GetPropertyChangedSignal("AbsoluteSize"):Connect(
        updateHeaderHeight
    ))
    table.insert(section._connections, sectionLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(
        section._refreshContainer
    ))
    table.insert(section._connections, header:GetPropertyChangedSignal("AbsoluteSize"):Connect(
        section._refreshContainer
    ))
    table.insert(section._connections, connectSafeActivation(headerButton, function()
        ApiImpl[88](section)
    end))

    table.insert(self.Sections, section)
    self._sectionByName[section.Name] = section
    updateHeaderHeight()
    ApiImpl[87](section, section.Expanded, false)
    task.defer(updateHeaderHeight)
    task.defer(section._refreshHeight)
    task.defer(section._refreshContainer)
    return section
end



-- API reduzida com limite de cinco paginas e construtores visuais originais.
-- Toggle, slider, placas, fontes, strokes, cabecalho e botoes nao foram redesenhados.
local window = setmetatable({
    _kind = "Window", _destroyed = false, Name = tostring(config.Name or "Chilli Hub"),
    Gui = rootGui, Main = mainFrame, Launcher = launcherGui,
    Tabs = {}, _tabByName = {}, _tabCount = 0, MaxTabs = MAX_TABS,
    _baseline = setmetatable({}, {__mode = "k"}),
}, WindowMethods)

-- Camadas originais preservadas: face, brilho interno, base inferior e contornos.
local function blend(a, b, amount)
    return Color3.new(a.R + (b.R-a.R)*amount, a.G + (b.G-a.G)*amount, a.B + (b.B-a.B)*amount)
end
local rgb = Color3.fromRGB
local function makePalette(background, surface, accent, muted)
    local black, white = rgb(0,0,0), rgb(255,255,255)
    local shadow = blend(background, black, 0.62)
    return {
        Window=background, Surface=surface, Raised=blend(surface, accent, 0.12),
        Shadow=shadow, Outline=blend(background, black, 0.85),
        OutlineTop=blend(shadow, accent, 0.045), Border=blend(surface, accent, 0.18),
        HeaderBase=blend(surface, black, 0.40), HeaderTop=blend(surface, accent, 0.40),
        HeaderBottom=blend(surface, accent, 0.17),
        ButtonBase=blend(surface, black, 0.50), ButtonTop=blend(surface, accent, 0.28),
        ButtonBottom=blend(surface, accent, 0.10),
        InnerTop=blend(surface, accent, 0.23), InnerBottom=blend(surface, black, 0.08),
        SelectedBase=blend(surface, accent, 0.14), SelectedTop=blend(surface, accent, 0.44),
        SelectedBottom=blend(surface, accent, 0.24), SelectedInnerTop=blend(surface, accent, 0.35),
        SelectedInnerBottom=blend(surface, accent, 0.15),
        Text=rgb(244,245,249), TextShade=blend(rgb(244,245,249), surface, 0.20), Muted=muted,
        Track=blend(surface, black, 0.35), Accent=accent, AccentBottom=blend(accent, shadow, 0.60),
        AccentTextShade=blend(accent, surface, 0.22),
        ThumbBase=blend(surface, accent, 0.32), Thumb=blend(accent, white, 0.60),
    }
end
local themePresets = {
    Original=false,
    Dark=makePalette(rgb(12,15,22), rgb(25,30,41), rgb(141,166,210), rgb(166,174,189)),
    Rose=makePalette(rgb(21,11,17), rgb(43,26,36), rgb(227,151,178), rgb(192,164,178)),
    Roxo=makePalette(rgb(16,10,25), rgb(34,24,50), rgb(182,145,231), rgb(178,164,200)),
    Verde=makePalette(rgb(8,21,15), rgb(20,38,29), rgb(125,200,155), rgb(157,185,167)),
    VermelhoEscuro=makePalette(rgb(25,8,12), rgb(44,20,26), rgb(204,109,125), rgb(193,155,163)),
    Azul=makePalette(rgb(9,17,30), rgb(22,34,52), rgb(122,174,234), rgb(161,179,203)),
    Preto=makePalette(rgb(6,6,7), rgb(21,21,24), rgb(186,188,197), rgb(159,161,171)),
    Lilas=makePalette(rgb(19,14,29), rgb(37,29,52), rgb(198,177,235), rgb(187,174,209)),
    Dourado=makePalette(rgb(25,20,10), rgb(43,35,21), rgb(218,185,112), rgb(193,180,152)),
}
local function normalizeTheme(name) return resolveThemeName(name) end
local function remapColor(original, palette)
    if not palette then return original end
    local _, saturation = original:ToHSV()
    return saturation > 0.08 and palette.Accent or palette.Text
end
local function roleOf(instance)
    local current = instance
    while current do
        local role = current:GetAttribute("MikotohRole")
        if role then return role, current end
        current = current.Parent
    end
end
local function isText(instance)
    return instance:IsA("TextLabel") or instance:IsA("TextButton") or instance:IsA("TextBox")
end
local function brightness(color) return color.R*0.2126 + color.G*0.7152 + color.B*0.0722 end
-- Mantem a quantidade, os pontos e a distribuicao dos brilhos originais.
local function shadeSequence(original, light, dark)
    local minimum, maximum = 1, 0
    for _, point in ipairs(original.Keypoints) do
        local value = brightness(point.Value)
        minimum, maximum = math.min(minimum, value), math.max(maximum, value)
    end
    local points = {}
    for _, point in ipairs(original.Keypoints) do
        local amount = maximum-minimum > 0.0001 and (brightness(point.Value)-minimum)/(maximum-minimum) or 1
        table.insert(points, ColorSequenceKeypoint.new(point.Time, blend(dark, light, amount)))
    end
    return ColorSequence.new(points)
end
local function captureOriginal(instance)
    local values = window._baseline[instance]
    if values then return values end
    local properties = {}
    if instance:IsA("UIGradient") or instance:IsA("UIStroke") then
        properties.Color, properties.Transparency = instance.Color, instance.Transparency
    end
    if instance:IsA("GuiObject") then
        properties.BackgroundColor3 = instance.BackgroundColor3
        properties.BackgroundTransparency = instance.BackgroundTransparency
    end
    if isText(instance) then
        properties.TextColor3 = instance.TextColor3
        properties.TextStrokeColor3, properties.TextStrokeTransparency = instance.TextStrokeColor3, instance.TextStrokeTransparency
    end
    if instance:IsA("ScrollingFrame") then properties.ScrollBarImageColor3 = instance.ScrollBarImageColor3 end
    if instance:IsA("ImageLabel") or instance:IsA("ImageButton") then
        properties.ImageColor3, properties.ImageTransparency = instance.ImageColor3, instance.ImageTransparency
    end
    values = {Properties=properties, Changed={}}
    window._baseline[instance] = values
    return values
end
local function applyThemeTo(instance)
    if window._destroyed or not instance.Parent then return end
    local saved = captureOriginal(instance)
    local original = saved.Properties
    local palette = themePresets[window.Theme]
    local role, owner = roleOf(instance)
    local selected = role == "TabButton" and owner:GetAttribute("MikotohSelected") == true
    local function paint(property, value)
        instance[property] = value
        saved.Changed[property] = true
    end
    if not palette then
        -- A copia original nunca recebe cores tematicas ou estado de selecao.
        -- Restaurar so o que o tema alterou preserva edicao, visibilidade e animacoes.
        for property in pairs(saved.Changed) do instance[property] = original[property] end
        if role == "TabButton" and instance == owner:FindFirstChild("Main") then
            instance.BackgroundColor3 = selected and rgb(255,54,54) or original.BackgroundColor3
        end
        return
    end
    if instance:IsA("UIGradient") then
        local parent_ = instance.Parent
        local light, dark
        if instance.Name == "TextStyleGradient" then
            light, dark = selected and palette.Accent or palette.Text, selected and palette.AccentTextShade or palette.TextShade
        elseif instance.Name == "StrokeStyleGradient" or parent_:IsA("UIStroke") or role == "ArrowOutline" then
            light, dark = palette.OutlineTop, palette.Outline
        elseif role == "ArrowFace" then light, dark = palette.Text, palette.TextShade
        elseif instance.Name == "OFF" then
            light, dark = palette.Track, palette.Track
            paint("Transparency", NumberSequence.new(0))
        elseif instance.Name == "ON" or parent_.Name == "Bar" then light, dark = palette.Accent, palette.AccentBottom
        elseif parent_ == objects.obj6 then light, dark = palette.HeaderTop, palette.HeaderBottom
        elseif role == "TabButton" then
            if parent_.Name == "Transparent" then
                light, dark = selected and palette.SelectedInnerTop or palette.InnerTop,
                    selected and palette.SelectedInnerBottom or palette.InnerBottom
            else light, dark = selected and palette.SelectedTop or palette.ButtonTop,
                selected and palette.SelectedBottom or palette.ButtonBottom end
        elseif role == "ActionButton" or role == "OpenButton" or role == "CloseButton" then
            if parent_.Name == "Transparent" then light, dark = palette.InnerTop, palette.InnerBottom
            else light, dark = palette.ButtonTop, palette.ButtonBottom end
        else light, dark = palette.Raised, palette.Surface end
        paint("Color", shadeSequence(original.Color, light, dark))
        return
    end
    if instance:IsA("UIStroke") then
        local parent_ = instance.Parent
        local styled = instance:FindFirstChildOfClass("UIGradient")
        if styled then paint("Color", rgb(255,255,255))
        elseif isText(parent_) and instance.ApplyStrokeMode ~= Enum.ApplyStrokeMode.Border then
            paint("Color", palette.Outline)
        elseif parent_ == mainFrame then paint("Color", palette.Outline)
        elseif parent_ == topBar or parent_.Name == "Main" or parent_.Name == "Hold" then
            paint("Color", palette.Shadow)
        else paint("Color", palette.Border) end
        -- Contornos escuros visiveis preservam o volume, sem aumentar a espessura.
        paint("Transparency", isText(parent_) and 0 or 0.04)
        return
    end
    if original.BackgroundColor3 then
        if instance == mainFrame then
            paint("BackgroundColor3", palette.Window); paint("BackgroundTransparency", 0.03)
        elseif instance == topBar then paint("BackgroundColor3", palette.HeaderBase)
        elseif instance:FindFirstChildOfClass("UIGradient") then
            paint("BackgroundColor3", rgb(255,255,255))
        elseif instance == objects.obj7 or instance == objects.obj18 then
            paint("BackgroundColor3", palette.Shadow); paint("BackgroundTransparency", 0.72)
        elseif instance.Name == "Hold" then paint("BackgroundColor3", palette.ThumbBase)
        elseif instance.Name == "Color" and instance.Parent.Name == "Hold" then
            paint("BackgroundColor3", palette.Thumb)
        elseif instance.Name == "Slider" then
            paint("BackgroundColor3", palette.Track); paint("BackgroundTransparency", 0.20)
        elseif instance.Name == "Value" then paint("BackgroundColor3", palette.Track)
        elseif instance.Name == "Arm" then paint("BackgroundColor3", palette.Muted)
        elseif instance.Name == "Main" and not role then
            paint("BackgroundColor3", blend(palette.Surface, palette.Shadow, 0.12))
            if original.BackgroundTransparency < 1 then paint("BackgroundTransparency", 0.12) end
        elseif instance.Name == "Main" and role == "TabButton" then
            paint("BackgroundColor3", selected and palette.SelectedBase or palette.ButtonBase)
        elseif instance.Name == "Main" and (role == "ActionButton" or role == "OpenButton" or role == "CloseButton") then
            paint("BackgroundColor3", palette.ButtonBase)
        else paint("BackgroundColor3", palette.Surface) end
    end
    if original.TextColor3 then
        local styled = instance:FindFirstChild("TextStyleGradient")
        paint("TextColor3", styled and rgb(255,255,255) or (instance.Name == "Note" and palette.Muted or palette.Text))
        if original.TextStrokeColor3 then paint("TextStrokeColor3", palette.Outline) end
    end
    if original.ScrollBarImageColor3 then
        paint("BackgroundColor3", palette.Window); paint("ScrollBarImageColor3", palette.Muted)
    end
end
local function paintTree(container)
    local descendants = container:GetDescendants()
    -- Capturar todas as camadas completas ANTES de mudar qualquer propriedade.
    captureOriginal(container)
    for _, instance in ipairs(descendants) do captureOriginal(instance) end
    applyThemeTo(container)
    for _, instance in ipairs(descendants) do applyThemeTo(instance) end
end
function WindowMethods:SetTheme(name)
    assertObject(self, "Window")
    self.Theme = normalizeTheme(name)
    for _, tab in ipairs(self.Tabs) do
        if tab._selectionTween then tab._selectionTween:Cancel(); tab._selectionTween = nil end
        for _, section in ipairs(tab.Sections) do
            for _, control in ipairs(section.Options) do
                if control._valueColorBaseline then
                    local colors = {}
                    for key, color in pairs(control._valueColorBaseline) do colors[key] = remapColor(color, themePresets[self.Theme]) end
                    control._controller.SetValueColors(colors)
                end
            end
        end
    end
    paintTree(rootGui); paintTree(launcherGui)
    return self
end
function WindowMethods:GetThemes() return copyTable(THEME_NAMES) end
closeButton:SetAttribute("MikotohRole", "CloseButton")
chilliButton:SetAttribute("MikotohRole", "OpenButton")

-- Novas paginas copiam a estrutura original de objects.obj25, antes de inserir secoes.
local pageTemplate = objects.obj25:Clone()
pageTemplate.Parent = nil
local function reflowTabButtons()
    if window._destroyed then return false end
    local column = TabColumns.Left
    local height = column.Frame.AbsoluteSize.Y
    if height <= 0 then return end
    local count = math.max(1, window._tabCount)
    local gap = math.clamp(height * 0.022, 6, 10)
    local top = column.Padding.PaddingTop.Scale * height + column.Padding.PaddingTop.Offset
    local available = math.max(1, height - top - math.max(8, height * 0.04) - gap * (count - 1))
    local buttonHeight = math.max(1, math.min(height * TAB_LAYOUT.NormalHeight / ContentScale.Y, available / count))
    column.Layout.Padding = UDim.new(0, gap)
    for _, entry in ipairs(window.Tabs) do
        entry.Button.Size = UDim2.new(1, 0, 0, buttonHeight)
    end
end
local function markSelected(tab, selected, animate)
    tab.Page.Visible = selected
    tab.Button:SetAttribute("MikotohSelected", selected)
    if tab._selectionTween then tab._selectionTween:Cancel(); tab._selectionTween = nil end
    -- Todas as camadas precisam acompanhar a selecao, inclusive texto e gradientes.
    paintTree(tab.Button)
end
function WindowMethods:SelectTab(tabOrName)
    assertObject(self, "Window")
    local tab = type(tabOrName) == "string" and self._tabByName[tabOrName] or tabOrName
    assertObject(tab, "Tab")
    assert(tab.Window == self, "A pagina pertence a outra janela.")
    closeActiveDropdown()
    for _, candidate in ipairs(self.Tabs) do markSelected(candidate, candidate == tab, true) end
    self.SelectedTab, self.Page, self.Content = tab, tab, tab.Page
    task.defer(function()
        if tab._destroyed or self._destroyed then return end
        for _, section in ipairs(tab.Sections) do section._refreshLayout() end
        tab._updateCanvas()
    end)
    return tab
end
function WindowMethods:CreateTab(config_)
    assertObject(self, "Window")
    local settings = normalizeConfig(config_, "Pagina")
    assert(not self._tabByName[settings.Name], "Nome de pagina duplicado: " .. settings.Name)
    assert(self._tabCount < MAX_TABS, "Limite de 5 paginas atingido. A sexta pagina nao foi criada.")
    local page = self._tabCount == 0 and objects.obj25 or pageTemplate:Clone()
    page.Name, page.Parent = settings.Name, mainFrame
    page.ScrollingDirection = Enum.ScrollingDirection.Y
    page.CanvasPosition = Vector2.new(0, 0)
    page.Visible = false
    local layout = Instance.new("UIListLayout")
    layout.Name = "SectionList"
    layout.FillDirection = Enum.FillDirection.Vertical
    layout.HorizontalAlignment = Enum.HorizontalAlignment.Center
    layout.VerticalAlignment = Enum.VerticalAlignment.Top
    layout.SortOrder = Enum.SortOrder.LayoutOrder
    layout.Padding = UDim.new(0, 2)
    layout.Parent = page
    local tab = setmetatable({
        _kind="Tab", _destroyed=false, Name=settings.Name, DisplayName=settings.DisplayName or settings.Name,
        Page=page, Window=self, Sections={}, _sectionByName={}, _connections={},
        _nextSectionOrder=0, SectionsExpanded=settings.SectionsExpanded ~= false,
    }, TabMethods)
    tab._updateCanvas = function()
        if tab._destroyed or not page.Parent then return end
        local sum = 0
        for _, section in ipairs(tab.Sections) do
            if not section._destroyed then sum = sum + section._container.Size.Y.Offset + 2 end
        end
        page.CanvasSize = UDim2.new(0, 0, 0, math.ceil(math.max(layout.AbsoluteContentSize.Y, sum)) + 8)
    end
    table.insert(tab._connections, layout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(tab._updateCanvas))
    table.insert(tab._connections, page:GetPropertyChangedSignal("AbsoluteSize"):Connect(tab._updateCanvas))
    tab.Button = createRebirthStyleButton(TabColumns.Left.Frame, tab.DisplayName, #self.Tabs + 1)
    tab.Button:SetAttribute("MikotohRole", "TabButton")
    table.insert(tab._connections, connectSafeActivation(tab.Button, function() self:SelectTab(tab) end))
    self._tabByName[tab.Name] = tab
    table.insert(self.Tabs, tab)
    self._tabCount = self._tabCount + 1
    markSelected(tab, false, false)
    paintTree(page)
    reflowTabButtons()
    if not self.DefaultTab then self.DefaultTab = tab; self:SelectTab(tab) end
    return tab
end
function WindowMethods:GetTab(name) return self._tabByName[name] end
function WindowMethods:GetTabs() return copyTable(self.Tabs) end
function WindowMethods:GetTabCount() return self._tabCount end
function TabMethods:Destroy()
    if self._destroyed then return end
    assert(self ~= self.Window.DefaultTab, "A pagina principal nao pode ser removida.")
    self._destroyed = true
    if self._selectionTween then self._selectionTween:Cancel() end
    for index = #self.Sections, 1, -1 do
        local section = self.Sections[index]
        if not section._destroyed then ApiImpl[89](section) end
    end
    for _, connection in ipairs(self._connections) do connection:Disconnect() end
    self.Button:Destroy(); self.Page:Destroy()
    self.Window._tabByName[self.Name] = nil
    for index, entry in ipairs(self.Window.Tabs) do
        if entry == self then table.remove(self.Window.Tabs, index); break end
    end
    self.Window._tabCount = self.Window._tabCount - 1
    for index, entry in ipairs(self.Window.Tabs) do entry.Button.LayoutOrder = index end
    reflowTabButtons()
    if self.Window.SelectedTab == self then self.Window:SelectTab(self.Window.DefaultTab) end
end
window.Theme = normalizeTheme(config.Theme)
local tab = window:CreateTab({Name=config.DefaultTab or "FARM"})
ContentScale.ReflowTabs = reflowTabButtons
trackRootConnection(TabColumns.Left.Frame:GetPropertyChangedSignal("AbsoluteSize"):Connect(reflowTabButtons))
objects.obj9.Text = window.Name
-- Coluna da direita fica vazia; Settings, Config e Quick nunca sao criados.

local function bindOriginalRow(section, row)
    local stopped = false
    local connections = {}
    local function refresh(force)
        if stopped or section._destroyed or not row.Parent then return false end
        if not force and Runtime.windowAnimating then return end
        local width = section._content.AbsoluteSize.X
        if width <= 0 then width = section.Tab.Page.AbsoluteSize.X end
        local constraint = row:FindFirstChildOfClass("UIAspectRatioConstraint")
        local aspect = row:GetAttribute("ChilliResponsiveAspect")
            or (constraint and constraint.AspectRatio) or ROW_ASPECT
        if width <= 0 or aspect <= 0 then return end
        local widthScale = ROW_WIDTH_SCALE
        if RESIZE_KEEPS_OPTION_WIDTH then widthScale = widthScale / ContentScale.X end
        row.Size = UDim2.new(widthScale, 0, 0, math.max(1, math.floor(width * widthScale / aspect + 0.5)))
        section._refreshHeight()
    end
    table.insert(connections, section._content:GetPropertyChangedSignal("AbsoluteSize"):Connect(refresh))
    table.insert(connections, row:GetAttributeChangedSignal("ChilliResponsiveAspect"):Connect(refresh))
    section._rowUpdaters = section._rowUpdaters or {}
    table.insert(section._rowUpdaters, refresh)
    ContentScale.OnChanged(function() return refresh(true) end)
    refresh(true)
    return function()
        stopped = true
        for _, connection in ipairs(connections) do connection:Disconnect() end
        for index, updater in ipairs(section._rowUpdaters) do
            if updater == refresh then table.remove(section._rowUpdaters, index); break end
        end
    end
end

local function createControl(section, kind, config_)
    assertObject(section, "Section")
    local settings = normalizeConfig(config_, kind)
    assert(not section._optionByName[settings.Name], "Nome de controle duplicado: " .. settings.Name)
    local row, controller
    if kind == "Toggle" then
        if settings.Description ~= nil or settings.Note ~= nil then
            row, controller = createLibraryNoteToggleRow(settings)
        else row, controller = createLibraryToggleRow(settings) end
    elseif kind == "Button" then
        row, controller = createLibraryButtonRow(settings)
        row:FindFirstChild("Action", true):SetAttribute("MikotohRole", "ActionButton")
    else
        row, controller = createLibrarySliderRow(settings)
    end
    section._nextOptionOrder = section._nextOptionOrder + 1
    row.LayoutOrder, row.Parent = section._nextOptionOrder, section._content
    local option = setmetatable({
        _kind = "Option", _destroyed = false, Name = settings.Name, Type = kind,
        Instance = row, Section = section, _controller = controller, _connections = {},
    }, OptionMethods)
    table.insert(section.Options, option)
    if controller.GetValueColors then
        option._valueColorBaseline = controller.GetValueColors()
        local values = {}
        for key, color in pairs(option._valueColorBaseline) do
            values[key] = remapColor(color, themePresets[window.Theme])
        end
        controller.SetValueColors(values)
    end
    section._optionByName[option.Name] = option
    local originalDestroy = controller.Destroy
    local cleanup = bindOriginalRow(section, row)
    controller.Destroy = function()
        cleanup()
        if originalDestroy then originalDestroy() end
    end
    table.insert(option._connections, row:GetPropertyChangedSignal("AbsoluteSize"):Connect(section._refreshHeight))
    paintTree(row)
    section._refreshLayout()
    section._stabilizeLayout()
    if settings.FireOnInit then
        if controller.GetValue then safeCallback(settings.Callback, controller.GetValue())
        else safeCallback(settings.Callback) end
    end
    return option
end
function SectionMethods:CreateToggle(config_) return createControl(self, "Toggle", config_) end
function SectionMethods:CreateSlider(config_) return createControl(self, "Slider", config_) end
function SectionMethods:CreateButton(config_) return createControl(self, "Button", config_) end
SectionMethods.SetExpanded, SectionMethods.Toggle, SectionMethods.Destroy = ApiImpl[87], ApiImpl[88], ApiImpl[89]
function TabMethods:CreateSection(config_)
    local section = ApiImpl[90](self, config_)
    for _, arm in ipairs(section._arrow:GetChildren()) do
        if arm:IsA("GuiObject") then
            arm:SetAttribute("MikotohRole", arm.ZIndex > section._arrow.ZIndex and "ArrowFace" or "ArrowOutline")
        end
    end
    paintTree(section._container)
    return section
end
function TabMethods:Select() return self.Window:SelectTab(self) end
function TabMethods:CreateToggle(config_) return self:_defaultSection():CreateToggle(config_) end
function TabMethods:CreateSlider(config_) return self:_defaultSection():CreateSlider(config_) end
function TabMethods:CreateButton(config_) return self:_defaultSection():CreateButton(config_) end
function TabMethods:_defaultSection()
    if not self._implicit or self._implicit._destroyed then
        self._implicit = self._sectionByName.Controles or self:CreateSection({Name="Controles", Expanded=true})
    end
    return self._implicit
end
function OptionMethods:Get()
    assertObject(self, "Option")
    assert(self._controller.GetValue, "Button nao possui valor. Use Press().")
    return self._controller.GetValue()
end
function OptionMethods:Set(value, silent)
    assertObject(self, "Option")
    assert(self._controller.SetValue, "Button nao possui valor. Use Press().")
    self._controller.SetValue(value, not silent)
    return self
end
function OptionMethods:SetValue(value, fireCallback)
    assertObject(self, "Option")
    assert(self._controller.SetValue, "Button nao possui valor. Use Press().")
    self._controller.SetValue(value, fireCallback)
    return self
end
OptionMethods.GetValue, OptionMethods.Destroy = OptionMethods.Get, ApiImpl[85]
function OptionMethods:Press()
    assertObject(self, "Option")
    assert(self._controller.Press, "Press() so pode ser usado com Button.")
    self._controller.Press()
    return self
end
function OptionMethods:SetNote(note)
    assertObject(self, "Option")
    assert(self._controller.SetNote, "Este controle nao tem descricao.")
    self._controller.SetNote(note)
    self.Section._refreshLayout()
    return self
end
function WindowMethods:GetDefaultTab() return self.DefaultTab end
function WindowMethods:CreateSection(config_) return self.DefaultTab:CreateSection(config_) end
function WindowMethods:CreateToggle(config_) return self.DefaultTab:CreateToggle(config_) end
function WindowMethods:CreateSlider(config_) return self.DefaultTab:CreateSlider(config_) end
function WindowMethods:CreateButton(config_) return self.DefaultTab:CreateButton(config_) end
function WindowMethods:SetVisible(visible)
    assertObject(self, "Window")
    if visible then playOpenAnimation() else playCloseAnimation() end
    return self
end
function WindowMethods:IsVisible() return not self._destroyed and Runtime.chilliIsOpen == true end
function WindowMethods:ToggleVisible() return self:SetVisible(not self:IsVisible()) end
function WindowMethods:Finalize() return self end
function WindowMethods:Destroy()
    if self._destroyed then return end
    self._destroyed = true
    if Runtime.windowDragController then Runtime.windowDragController.Cancel() end
    cancelWindowTween()
    cancelHudTween()
    for _, currentTab in ipairs(self.Tabs) do
        currentTab._destroyed = true
        if currentTab._selectionTween then currentTab._selectionTween:Cancel() end
        for index = #currentTab.Sections, 1, -1 do
            local section = currentTab.Sections[index]
            if not section._destroyed then ApiImpl[89](section) end
        end
        for _, connection in ipairs(currentTab._connections) do connection:Disconnect() end
    end
    pageTemplate:Destroy()
    self.Tabs, self._tabByName, self._tabCount = {}, {}, 0
    ContentScale.Listeners = {}
    ContentScale.ReflowTabs = nil
    disconnectRootConnections()
    disconnectSourceConnections()
    pcall(function() RunService:UnbindFromRenderStep(HUD_RENDER_GUARD_NAME) end)
    if leftCenterFrame and leftCenterFrame.Parent then
        leftCenterFrame.Position, leftCenterFrame.Visible = hudRestorePosition, true
    end
    if sourceLeftCenterScreen and sourceLeftCenterScreen.Parent then sourceLeftCenterScreen.Enabled = true end
    rootGui:Destroy()
    launcherGui:Destroy()
end
-- Botao dedicado de abrir/fechar: usa as camadas e o feedback do botao original.
do
    local open = createRebirthStyleButton(rootGui, "OpenButton", 0)
    open.Name = "OpenButton"
    open.AnchorPoint = Vector2.new(0.5, 0.5)
    open.ZIndex = 200
    open.ClipsDescendants = true
    open:SetAttribute("MikotohRole", "OpenButton")
    local base = open:FindFirstChild("Main")
    base.Size = UDim2.fromScale(1, 1)
    local colorFrame = base:FindFirstChild("ColorFrame")
    colorFrame.Size = UDim2.fromScale(1, 1)
    local highlight = colorFrame:FindFirstChild("Transparent")
    local label = colorFrame:FindFirstChild("Label")
    local icon = Instance.new("ImageLabel")
    icon.Name = "CustomIcon"
    icon.BackgroundTransparency = 1
    icon.AnchorPoint = Vector2.new(0.5, 0.5)
    icon.Position = UDim2.fromScale(0.5, 0.5)
    icon.Size = UDim2.fromScale(1, 1)
    icon.ScaleType = Enum.ScaleType.Crop
    icon.ImageColor3 = Color3.fromRGB(255, 255, 255)
    icon.ZIndex = 206
    icon.Parent = open
    base.ZIndex, colorFrame.ZIndex, highlight.ZIndex, label.ZIndex = 201, 202, 203, 205
    window.OpenButton = open
    local drag, moved, activationInput = nil, false, nil
    local function clampPosition(x, y)
        local region = rootGui.AbsoluteSize
        if region.X <= 0 or region.Y <= 0 then return end
        local half = window._openOptions.Size / 2
        open.Position = UDim2.fromOffset(
            math.clamp(x, half + 4, math.max(half + 4, region.X - half - 4)),
            math.clamp(y, half + 4, math.max(half + 4, region.Y - half - 4)))
    end
    local function fitPosition()
        if window._destroyed or not window._openOptions then return end
        local size = rootGui.AbsoluteSize
        local position = open.Position
        clampPosition(position.X.Scale * size.X + position.X.Offset,
            position.Y.Scale * size.Y + position.Y.Offset)
    end
    function WindowMethods:SetOpenButton(options)
        assertObject(self, "Window")
        local settings = normalizeOpenOptions(options, self._openOptions)
        self._openOptions = settings
        drag, moved, activationInput = nil, false, nil
        open.Size = UDim2.fromOffset(settings.Size, settings.Size)
        if not options or options.Position ~= nil then open.Position = settings.Position end
        open.Visible = settings.Enabled
        launcherGui.Enabled = not settings.Enabled
        icon.Image, icon.Visible = settings.Image, settings.Image ~= ""
        base.Visible = settings.Image == ""
        label.Text, label.Visible = settings.Text, settings.Image == ""
        for _, object in ipairs({open, base, colorFrame, highlight, icon}) do
            local rounding = object:FindFirstChildOfClass("UICorner") or Instance.new("UICorner")
            rounding.CornerRadius = settings.Shape == "Round" and UDim.new(0.5, 0) or UDim.new(0, 0)
            rounding.Parent = object
        end
        fitPosition()
        return self
    end
    WindowMethods.ConfigureOpenButton = WindowMethods.SetOpenButton
    function WindowMethods:GetOpenButtonPosition() return open.Position end
    function WindowMethods:GetOpenButtonOptions() return copyTable(self._openOptions) end
    trackRootConnection(open.InputBegan:Connect(function(input)
        if drag then return end
        moved = false
        activationInput = input
        if not window._openOptions.Draggable or not window._openOptions.Enabled then return end
        if input.UserInputType ~= Enum.UserInputType.MouseButton1
            and input.UserInputType ~= Enum.UserInputType.Touch then return end
        if input.UserInputState ~= Enum.UserInputState.Begin then return end
        local size = rootGui.AbsoluteSize
        drag = {Input=input, Touch=input.UserInputType == Enum.UserInputType.Touch,
            Start=Vector2.new(input.Position.X, input.Position.Y),
            Origin=Vector2.new(open.Position.X.Scale * size.X + open.Position.X.Offset,
                open.Position.Y.Scale * size.Y + open.Position.Y.Offset)}
    end))
    trackRootConnection(UserInputService.InputChanged:Connect(function(input)
        if not drag then return end
        if drag.Touch and input ~= drag.Input then return end
        if not drag.Touch and input.UserInputType ~= Enum.UserInputType.MouseMovement then return end
        local delta = Vector2.new(input.Position.X, input.Position.Y) - drag.Start
        if delta.Magnitude > 6 then moved = true end
        clampPosition(drag.Origin.X + delta.X, drag.Origin.Y + delta.Y)
    end))
    trackRootConnection(UserInputService.InputEnded:Connect(function(input)
        if drag and input == drag.Input then drag = nil end
    end))
    trackRootConnection(connectSafeActivation(open, function(input)
        if input and activationInput and input ~= activationInput then return end
        if not moved then window:ToggleVisible() end
    end))
    trackRootConnection(UserInputService.WindowFocusReleased:Connect(function()
        drag, moved, activationInput = nil, false, nil
    end))
    trackRootConnection(rootGui:GetPropertyChangedSignal("AbsoluteSize"):Connect(fitPosition))
    window:SetOpenButton(config.OpenButton)
end

trackRootConnection(connectSafeActivation(closeButton, function() window:SetVisible(false) end))
trackRootConnection(connectSafeActivation(chilliButton, function()
    window:SetVisible(not Runtime.chilliIsOpen)
end))
makeButtonFeedback(closeButton)
makeButtonFeedback(chilliButton)
Runtime.windowDragController = makeDraggable(topBar, mainFrame,
    function() return Runtime.chilliIsOpen and not Runtime.windowAnimating end,
    function(position) Runtime.windowRestPosition = position end)
applyOriginalStrokeSizing()
window.Theme = normalizeTheme(config.Theme)
window:SetTheme(window.Theme)
for _, gui in ipairs({rootGui, launcherGui}) do
    trackRootConnection(gui.DescendantAdded:Connect(function(instance)
        task.defer(function() applyThemeTo(instance) end)
    end))
end
launcherGui.Enabled = not window._openOptions.Enabled
tab.Page.Visible = true
tab._updateCanvas()
mainFrame.Position = closedWindowPosition()
window:SetVisible(true)
rootGui.Destroying:Connect(function()
    if not window._destroyed then window:Destroy() end
end)
return window
end

local Library = {Version="3.2.0", VisualBase="Chilli Library 3.22.0", MaxTabs=MAX_TABS, Window=nil}
local environment = type(getgenv) == "function" and getgenv() or _G
function Library:CreateWindow(config)
    config = config or {}
    assert(type(config) == "table", "CreateWindow espera uma tabela.")
    resolveThemeName(config.Theme)
    normalizeOpenOptions(config.OpenButton)
    assert(tostring(config.DefaultTab or "FARM") ~= "", "DefaultTab nao pode ser vazio.")
    local previous = environment.MIKOTOH_UI_Window
    if type(previous) == "table" and type(previous.Destroy) == "function" then previous:Destroy() end
    local window = buildOriginal(config)
    self.Window, environment.MIKOTOH_UI_Window = window, window
    local destroy = window.Destroy
    window.Destroy = function(current)
        destroy(current)
        if self.Window == current then self.Window = nil end
        if environment.MIKOTOH_UI_Window == current then environment.MIKOTOH_UI_Window = nil end
    end
    return window
end
function Library:Finalize(config) return config and config.Window or self.Window end
function Library:GetThemes()
    local result = {}
    for index, name in ipairs(THEME_NAMES) do result[index] = name end
    return result
end
return Library

end)()
local janela = UI:CreateWindow({
    Name = "MIKOTOH HUB",
    DefaultTab = "FARM",
    Theme = "Dark",
    OpenButton = {
        Position = UDim2.fromScale(0.08, 0.5),
        Size = 54,
        Draggable = true, -- false deixa fixo.
        Shape = "Round", -- "Square" deixa quadrado.
        Image = "", -- ID numerico ou "rbxassetid://ID": imagem preenche o botao inteiro.
        Text = "M" -- Aparece quando Image esta vazio.
    }
})
local farm = janela:GetDefaultTab()
local player = janela:CreateTab({Name="PLAYER"})
local visual = janela:CreateTab({Name="VISUAL"})
local temas = janela:CreateTab({Name="TEMAS"})
local sobre = janela:CreateTab({Name="SOBRE"})

local automatico = farm:CreateSection({Name="Toggles", Expanded=true})
automatico:CreateToggle({
    Name="Toggle de teste", Default=false,
    Callback=function(ativo) print("[MIKOTOH UI] Toggle:", ativo) end
})
automatico:CreateToggle({
    Name="Toggle com descricao", Description="Componente original da Chilli",
    Default=true,
    Callback=function(ativo) print("[MIKOTOH UI] Toggle 2:", ativo) end
})
local ajustes = farm:CreateSection({Name="Sliders", Expanded=true})
ajustes:CreateSlider({
    Name="Velocidade", Min=16, Max=100, Default=16, Step=1,
    Callback=function(valor) print("[MIKOTOH UI] Velocidade selecionada:", valor) end
})
farm:CreateSection({Name="Button", Expanded=true}):CreateButton({
    Name="Botao de teste", Description="Mesmo componente visual da Chilli",
    ButtonText="Testar", ConfirmText="OK!",
    Callback=function() print("[MIKOTOH UI] Button funcionou!") end
})
player:CreateSection({Name="Ajustes de exemplo", Expanded=true}):CreateSlider({
    Name="Intensidade", Min=0, Max=10, Default=5, Step=0.1,
    AllowDecimals=true, DecimalPlaces=1,
    Callback=function(valor) print("[MIKOTOH UI] Intensidade:", valor) end
})
visual:CreateSection({Name="Visuais de exemplo", Expanded=true}):CreateToggle({
    Name="Exemplo visual", Default=false,
    Callback=function(ativo) print("[MIKOTOH UI] Visual:", ativo) end
})
local cores = temas:CreateSection({Name="Escolha um dos 10 temas", Expanded=true})
for _, name in ipairs(UI:GetThemes()) do
    local themeName = name
    cores:CreateButton({
        Name=themeName, ButtonText="Aplicar", ConfirmText="OK!",
        Callback=function() janela:SetTheme(themeName) end
    })
end
local info = sobre:CreateSection({Name="Biblioteca 3.2", Expanded=true})
info:CreateButton({
    Name="Fechar a interface", ButtonText="Fechar", ConfirmText="",
    Callback=function() janela:SetVisible(false) end
})
info:CreateButton({
    Name="Conferir limite", ButtonText="Contar", ConfirmText="OK!",
    Callback=function() print("[MIKOTOH UI] Paginas:", janela:GetTabCount(), "/", UI.MaxTabs) end
})
return janela
