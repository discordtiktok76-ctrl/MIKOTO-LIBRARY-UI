# MIKOTOH UI 3.2

Biblioteca de interface para Roblox no cliente, baseada nos construtores visuais do arquivo legível **Chilli Library 3.22.0**. Mantém a estrutura das placas, fontes, contornos e componentes originais. Os temas personalizados combinam a cor escolhida com sombras, relevos e brilho; `Original` restaura a paleta da Chilli. A API oferece páginas limitadas, três tipos de controle e um botão de abrir/fechar configurável.

## Conteúdo

- `MIKOTOH_UI.lua`: biblioteca inteira em um arquivo.
- `MIKOTOH_UI_TESTE.lua`: demonstração completa, com a biblioteca incorporada.
- `examples/studio.client.lua`: exemplo mínimo em um LocalScript.
- `examples/full.client.lua`: exemplo completo usando ModuleScript.
- `tests/`: validação de sintaxe e comportamento com APIs simuladas.
- `CHANGELOG.md` e `ATTRIBUTION.md`: histórico e origem dos componentes.

A biblioteca não carrega o engine ofuscado da Chilli, não faz HttpGet e não exige chave. Os recursos de fonte/mesh da interface original são assets do Roblox.

## Testar rapidamente

Execute `MIKOTOH_UI_TESTE.lua` no cliente. Ele mostra cinco páginas: FARM, PLAYER, VISUAL, TEMAS e SOBRE. Essas páginas são criadas explicitamente pelo exemplo. A biblioteca, sozinha, cria apenas a página principal.

O teste começa no tema `Dark`. Os controles de demonstração imprimem valores no console. Eles não alteram o personagem. A página TEMAS tem dez botões para experimentar as paletas. O botão flutuante **M** abre e fecha a janela; pode ser arrastado.

## Instalar no Roblox Studio

1. Crie um ModuleScript chamado `MikotohUI` em `ReplicatedStorage`.
2. Cole o conteúdo de `MIKOTOH_UI.lua` no ModuleScript.
3. Use o exemplo em um **LocalScript** de `StarterPlayerScripts`.

```lua
local UI = require(game:GetService("ReplicatedStorage"):WaitForChild("MikotohUI"))

local janela = UI:CreateWindow({
    Name = "MIKOTOH HUB",
    DefaultTab = "FARM",
    Theme = "Original",
    OpenButton = {
        Position = UDim2.fromScale(0.08, 0.5),
        Size = 54,
        Shape = "Round",
        Draggable = true,
        Image = "",
        Text = "M"
    }
})

local farm = janela:GetDefaultTab()
local secao = farm:CreateSection({Name = "Controles", Expanded = true})

local toggle = secao:CreateToggle({
    Name = "Minha função",
    Default = false,
    Callback = function(ativado)
        print("Ativado:", ativado)
    end
})

local slider = secao:CreateSlider({
    Name = "Velocidade",
    Min = 16, Max = 100, Default = 16, Step = 1,
    Callback = function(valor)
        print("Selecionado:", valor)
    end
})

local button = secao:CreateButton({
    Name = "Executar ação",
    ButtonText = "Executar",
    ConfirmText = "OK!",
    Callback = function()
        print("Button funcionou")
    end
})
```

No cliente, a biblioteca tenta `gethui`/`CoreGui` quando disponíveis e usa `PlayerGui` como alternativa. `Parent` opcional em `CreateWindow` escolhe outro contêiner de GUI. Por padrão, o botão flutuante controla apenas esta janela, sem integrar ou ocultar o HUD do jogo.

## Carregar a partir de um repositório

Publique `MIKOTOH_UI.lua` no repositório que você escolher e copie a URL **Raw real** desse arquivo. Em um ambiente de cliente que disponibilize `HttpGet` e `loadstring`:

```lua
local rawUrl = "COLE_AQUI_A_URL_RAW_DO_SEU_ARQUIVO"
local source = game:HttpGet(rawUrl)
local chunk, problem = loadstring(source)
assert(chunk, problem)
local UI = chunk()
-- Use UI:CreateWindow como no exemplo acima.
```

O download está no exemplo de carregamento, não dentro da biblioteca. No Studio, utilize ModuleScript e `require`.

## Páginas: limite fixo de cinco

A página principal conta no limite. O limite é uma constante interna de **5 páginas por janela**, sem Settings, Config ou Quick automáticas. Os botões das páginas têm um pequeno espaço entre si, recalculado ao redimensionar a janela e ao criar ou remover páginas.

```lua
local farm = janela:GetDefaultTab() -- Página 1
local player = janela:CreateTab({Name = "PLAYER"}) -- Página 2
local visual = janela:CreateTab({Name = "VISUAL"}) -- Página 3
local temas = janela:CreateTab({Name = "TEMAS"}) -- Página 4
local sobre = janela:CreateTab({Name = "SOBRE"}) -- Página 5

local ok, erro = pcall(function()
    janela:CreateTab({Name = "SEXTA"})
end)
-- ok será false; a sexta página não cria botões ou elementos parciais.
```

Nomes de página devem ser únicos e não vazios. Se o código precisar tentar criar uma página quando a janela estiver cheia, capture o erro com `pcall`.

```lua
player:Select()
janela:SelectTab("FARM")
local pagina = janela:GetTab("PLAYER")
local quantidade = janela:GetTabCount()
local paginas = janela:GetTabs() -- cópia da lista
player:Destroy() -- libera uma vaga; a página principal não pode ser removida.
```

Não altere os campos internos ou a lista `Tabs` diretamente. Use os métodos da API.

## Dez temas

Cada paleta tem cores próprias para fundo, superfícies, bordas, texto e estados ativos. As camadas da Chilli recebem tons diferentes: face iluminada, brilho interno, base inferior mais escura e contornos. Cabeçalho, botão de fechar, Toggles e Sliders também recebem sombras combinadas com a paleta. Os pontos e a distribuição dos gradientes originais são preservados, inclusive o brilho do texto. A página selecionada recebe destaque sem perder o relevo.

A cor chega a todas as páginas, inclusive às que estão ocultas ou são criadas depois de `SetTheme`. Alternar páginas mantém o tema escolhido. O tema `Original` restaura as cores, opacidades e gradientes registrados antes de aplicar os temas. Essa cópia permanece intacta ao selecionar páginas. Trocas repetidas não acumulam tintas nem alteram os valores dos controles, o campo numérico em edição ou a imagem do botão flutuante. Os temas não criam páginas.

| Nome para a API | Aparência | Fundo da janela |
|---|---|---|
| `Dark` | Grafite com azul discreto | `#0C0F16` |
| `Original` | Paleta original da Chilli, com vermelho e verde | Original |
| `Rose` | Rosé com fundo vinho | `#150B11` |
| `Roxo` | Roxo com fundo ameixa | `#100A19` |
| `Verde` | Verde com fundo floresta | `#08150F` |
| `VermelhoEscuro` | Vermelho profundo e vinho escuro | `#19080C` |
| `Azul` | Azul com fundo marinho | `#09111E` |
| `Preto` | Preto e cinza neutro | `#060607` |
| `Lilas` | Lilás suave com fundo escuro | `#130E1D` |
| `Dourado` | Dourado com fundo castanho | `#19140A` |

```lua
janela:SetTheme("Rose")
janela:SetTheme("VermelhoEscuro")
janela:SetTheme("Original") -- restaura a paleta registrada
local nomes = UI:GetThemes() -- cópia dos dez nomes
```

Também são aceitos `"vermelho escuro"`, `"lilás"` e `"rosé"`.

## Botão de abrir/fechar

É independente dos Buttons de ação. Sua única ação de clique é alternar a visibilidade da janela. O X do cabeçalho também fecha a janela; o botão flutuante permanece disponível para reabrir.

| Campo de `OpenButton` | Padrão | Uso |
|---|---|---|
| `Enabled` | `true` | Ativa o botão flutuante. `false` usa o lançador Chilli original. |
| `Position` | `UDim2.fromScale(0.08, 0.5)` | Posição do centro do botão na tela. |
| `Size` | `54` | Largura e altura em pixels, limitadas de 32 a 160. |
| `Image` | `""` | Seu ID numérico ou `"rbxassetid://ID"`; preenche todo o botão. Vazio mostra texto. |
| `Text` | `"M"` | Texto alternativo quando não há imagem. |
| `Draggable` | `true` | `false` fixa o botão na posição escolhida. |
| `Shape` | `"Round"` | `"Round"` redondo ou `"Square"` quadrado. |

`ImageId` e `Id` são aliases de `Image`. Se usar os aliases, passe apenas um campo de imagem por chamada. A imagem escolhida precisa ser um asset de imagem disponível no Roblox. Ela ocupa 100% da largura e altura, sem margem interna. `ScaleType.Crop` recorta as bordas de imagens que não são quadradas para preencher a área sem deformar; o recorte acompanha o formato redondo ou quadrado. Os temas não tingem a imagem.

```lua
-- Durante a execução:
janela:SetOpenButton({
    Shape = "Square",
    Draggable = false,
    Position = UDim2.new(1, -60, 0.5, 0)
})

-- Em Image, passe o ID do seu próprio asset:
janela:SetOpenButton({Image = meuIdDeImagem})
janela:SetOpenButton({Image = "", Text = "M"})

local posicaoAtual = janela:GetOpenButtonPosition()
local opcoes = janela:GetOpenButtonOptions()
```

`ConfigureOpenButton` é um alias de `SetOpenButton`. Atualizações parciais preservam as outras opções. A posição é limitada à área visível, inclusive após redimensionar a tela. Arrastar não dispara a ação de abrir/fechar. Mouse e toque são aceitos.

## Toggle, Slider e Button

Todos aceitam `Name`, `Callback` e `Description`/`Note opcional`. Nomes devem ser únicos dentro de cada seção. Uma seção pode ser recolhida pelo cabeçalho original.

- **Toggle**: `Default` booleano. `Callback(ativado)`.
- **Slider**: `Min`, `Max`, `Default`, `Step`/`Increment`. `Callback(valor)`. Mantém o campo numérico original editável. Para casas decimais: `AllowDecimals = true`, `DecimalPlaces = 1` (até 6); `Precision` também é aceita.
- **Button**: `ButtonText` e `ConfirmText`. `Callback()` sem valor. Mantém as camadas, gradientes e animação do Button original.

```lua
toggle:Set(true)
toggle:Set(false, true) -- segundo argumento true SILENCIA o callback.
local ativo = toggle:Get()
slider:Set(40)
local valor = slider:Get()
button:Press() -- anima e chama Callback.
controle:SetNote("Nova descrição") -- controles criados com nota; sliders também aceitam.
controle:Destroy()
```

Os nomes originais `GetValue` e `SetValue` também estão disponíveis. Em `SetValue(valor, false)`, **false** silencia o callback; em `Set(valor, true)`, **true** silencia. Button não tem Get/Set de valor; utilize `Press`.

`FireOnInit = true` chama o callback ao criar o controle. Sem essa opção, criar um controle não dispara a ação. Erros de callback são apresentados com o prefixo `[MIKOTOH UI]`.

Também é possível chamar `CreateToggle`, `CreateSlider` ou `CreateButton` diretamente na página ou janela; esses métodos usam uma seção `Controles`. Para organizar a interface, prefira seções explícitas.

## Ciclo de vida

```lua
janela:SetVisible(false)
janela:SetVisible(true)
janela:ToggleVisible()
local aberta = janela:IsVisible()
secao:SetExpanded(false)
secao:Toggle()
secao:Destroy()
janela:Destroy() -- encerra a janela, os lançadores e as conexões.
```

Criar outra janela desta biblioteca encerra a anterior. Uma instância gerencia uma janela ativa. `Finalize` é opcional e não adiciona páginas ou controles.

## Validação

A sintaxe e os comportamentos foram verificados numa simulação local: dez temas com face, sombra, brilho e contornos distintos; preservação dos pontos dos gradientes; herança de tema; comparação das cores, opacidades e gradientes de Original com uma janela criada diretamente nesse tema, após iniciar em cada uma das dez paletas e fazer várias trocas. Também foram verificados setas legíveis, espaçamento em janelas pequenas, imagem preenchendo todo o botão, limite de páginas, seleção e exclusão, callbacks, sliders, botão fixo/arrastável, formato, múltiplos toques e limpeza.

Os testes **não executam Roblox** nem conferem o carregamento de assets. A aparência, a animação e a imagem escolhida precisam de conferência final no cliente Roblox.

Para executar a simulação em Linux com Python 3 e `liblua5.4` disponíveis:

```sh
python3 tests/run_tests.py
```

Veja `ATTRIBUTION.md` para a origem dos componentes reutilizados.
