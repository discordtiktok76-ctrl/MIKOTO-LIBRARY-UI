-- Execute em LocalScript, com a biblioteca em ReplicatedStorage/MikotohUI.
local UI = require(game:GetService("ReplicatedStorage"):WaitForChild("MikotohUI"))
local janela = UI:CreateWindow({
    Name = "MIKOTOH HUB",
    DefaultTab = "FARM",
    Theme = "Dark",
    OpenButton = {
        Position = UDim2.fromScale(0.08, 0.5),
        Size = 54,
        Draggable = true, -- false deixa fixo.
        Shape = "Round", -- "Square" deixa quadrado.
        Image = "", -- ID numerico ou "rbxassetid://ID": imagem preenche o botao inteiro.
        Text = "M" -- Aparece quando Image esta vazio.
    }
})
local farm = janela:GetDefaultTab()
local player = janela:CreateTab({Name="PLAYER"})
local visual = janela:CreateTab({Name="VISUAL"})
local temas = janela:CreateTab({Name="TEMAS"})
local sobre = janela:CreateTab({Name="SOBRE"})

local automatico = farm:CreateSection({Name="Toggles", Expanded=true})
automatico:CreateToggle({
    Name="Toggle de teste", Default=false,
    Callback=function(ativo) print("[MIKOTOH UI] Toggle:", ativo) end
})
automatico:CreateToggle({
    Name="Toggle com descricao", Description="Componente original da Chilli",
    Default=true,
    Callback=function(ativo) print("[MIKOTOH UI] Toggle 2:", ativo) end
})
local ajustes = farm:CreateSection({Name="Sliders", Expanded=true})
ajustes:CreateSlider({
    Name="Velocidade", Min=16, Max=100, Default=16, Step=1,
    Callback=function(valor) print("[MIKOTOH UI] Velocidade selecionada:", valor) end
})
farm:CreateSection({Name="Button", Expanded=true}):CreateButton({
    Name="Botao de teste", Description="Mesmo componente visual da Chilli",
    ButtonText="Testar", ConfirmText="OK!",
    Callback=function() print("[MIKOTOH UI] Button funcionou!") end
})
player:CreateSection({Name="Ajustes de exemplo", Expanded=true}):CreateSlider({
    Name="Intensidade", Min=0, Max=10, Default=5, Step=0.1,
    AllowDecimals=true, DecimalPlaces=1,
    Callback=function(valor) print("[MIKOTOH UI] Intensidade:", valor) end
})
visual:CreateSection({Name="Visuais de exemplo", Expanded=true}):CreateToggle({
    Name="Exemplo visual", Default=false,
    Callback=function(ativo) print("[MIKOTOH UI] Visual:", ativo) end
})
local cores = temas:CreateSection({Name="Escolha um dos 10 temas", Expanded=true})
for _, name in ipairs(UI:GetThemes()) do
    local themeName = name
    cores:CreateButton({
        Name=themeName, ButtonText="Aplicar", ConfirmText="OK!",
        Callback=function() janela:SetTheme(themeName) end
    })
end
local info = sobre:CreateSection({Name="Biblioteca 3.2", Expanded=true})
info:CreateButton({
    Name="Fechar a interface", ButtonText="Fechar", ConfirmText="",
    Callback=function() janela:SetVisible(false) end
})
info:CreateButton({
    Name="Conferir limite", ButtonText="Contar", ConfirmText="OK!",
    Callback=function() print("[MIKOTOH UI] Paginas:", janela:GetTabCount(), "/", UI.MaxTabs) end
})
return janela
