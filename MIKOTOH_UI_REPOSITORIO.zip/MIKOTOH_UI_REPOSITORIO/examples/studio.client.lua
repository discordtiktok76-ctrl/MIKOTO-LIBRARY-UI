-- Cole a biblioteca em ReplicatedStorage/MikotohUI (ModuleScript).
-- Execute este exemplo num LocalScript de StarterPlayerScripts.
local UI = require(game:GetService("ReplicatedStorage"):WaitForChild("MikotohUI"))
local janela = UI:CreateWindow({
    Name="MIKOTOH HUB", DefaultTab="FARM", Theme="Rose",
    OpenButton={Position=UDim2.fromScale(0.08,0.5),Size=54,Shape="Round",Draggable=true,Image="",Text="M"}
})
local secao = janela:GetDefaultTab():CreateSection({Name="Controles",Expanded=true})
secao:CreateToggle({Name="Minha função",Default=false,Callback=function(ativo) print(ativo) end})
secao:CreateSlider({Name="Velocidade",Min=16,Max=100,Default=16,Step=1,Callback=function(valor) print(valor) end})
secao:CreateButton({Name="Minha ação",ButtonText="Testar",ConfirmText="OK!",Callback=function() print("Funcionou!") end})
return janela
