import ctypes
import ctypes.util
import json
from pathlib import Path
lib=ctypes.CDLL(ctypes.util.find_library('lua5.4') or 'liblua5.4.so.0')
lib.luaL_newstate.restype=ctypes.c_void_p
lib.luaL_openlibs.argtypes=[ctypes.c_void_p]
lib.luaL_loadfilex.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_char_p]
lib.lua_pcallk.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_int,ctypes.c_int,ctypes.c_longlong,ctypes.c_void_p]
lib.lua_tolstring.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.POINTER(ctypes.c_size_t)]
lib.lua_tolstring.restype=ctypes.c_char_p
lib.lua_settop.argtypes=[ctypes.c_void_p,ctypes.c_int]
lib.lua_close.argtypes=[ctypes.c_void_p]
lib.luaL_loadstring.argtypes=[ctypes.c_void_p,ctypes.c_char_p]
state=lib.luaL_newstate();lib.luaL_openlibs(state)
root=Path(__file__).resolve().parents[1]
def check(status):
    if status: raise RuntimeError(lib.lua_tolstring(state,-1,None).decode())
try:
    for name in ['MIKOTOH_UI.lua','MIKOTOH_UI_TESTE.lua']:
        check(lib.luaL_loadfilex(state,str(root/name).encode(),None));lib.lua_settop(state,0)
        print('Syntax PASS:',name,flush=True)
    check(lib.luaL_loadstring(state, ('TEST_ROOT='+json.dumps(str(root)+'/')).encode()))
    check(lib.lua_pcallk(state,0,0,0,0,None))
    for name in ['tests/roblox_mock.lua','tests/behavior.lua']:
        check(lib.luaL_loadfilex(state,str(root/name).encode(),None))
        check(lib.lua_pcallk(state,0,0,0,0,None))
finally:
    lib.lua_close(state)
