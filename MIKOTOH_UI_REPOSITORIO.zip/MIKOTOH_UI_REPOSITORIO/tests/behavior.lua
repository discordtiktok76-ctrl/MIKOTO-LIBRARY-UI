local root=assert(TEST_ROOT)
local UI=assert(loadfile(root..'MIKOTOH_UI.lua'))()
local function sameColor(a,b)
    return math.abs(a.R-b.R)<1e-8 and math.abs(a.G-b.G)<1e-8 and math.abs(a.B-b.B)<1e-8
end
local function sameSequence(a,b)
    if #a.Keypoints~=#b.Keypoints then return false end
    for index,point in ipairs(a.Keypoints) do
        if point.Time~=b.Keypoints[index].Time or not sameColor(point.Value,b.Keypoints[index].Value) then return false end
    end
    return true
end
local function luminance(color) return color.R*0.2126+color.G*0.7152+color.B*0.0722 end
local w=UI:CreateWindow({Name='Chilli Hub',DefaultTab='FARM',Theme='Original'})
drain(6)
assert(#w.Tabs==1 and w:GetDefaultTab().Name=='FARM')
assert(type(w.CreateTab)=='function' and type(w.CreateButton)=='function')
local farm=w:GetDefaultTab()
local section=farm:CreateSection({Name='Original',Expanded=true})
local toggled
local toggle=section:CreateToggle({Name='Toggle',Default=false,Callback=function(v) toggled=v end})
drain(6)
assert(toggle:Get()==false)
toggle:Set(true);drain(2);assert(toggle:Get()==true and toggled==true)
toggle:Set(false,true);drain(2);assert(toggle:Get()==false and toggled==true)
local switch=toggle.Instance:FindFirstChild('Switch',true)
assert(switch.Size.X.Scale==0.142 and switch.Size.Y.Scale==0.75)
assert(switch.Position.X.Scale==0.915)
local hold=switch:FindFirstChild('Hold');assert(hold.Position.X.Scale==0.28)
switch:FindFirstChild('Button').Activated:Fire();drain(2)
assert(toggle:Get()==true and hold.Position.X.Scale==0.72)
local noted=section:CreateToggle({Name='Note',Description='Original note',Default=true})
assert(noted.Instance:FindFirstChild('Note',true).Text=='Original note')
local slider=section:CreateSlider({Name='Speed',Min=16,Max=100,Default=16,Step=1})
drain(6)
assert(slider:Get()==16)
slider:Set(1000);assert(slider:Get()==100)
slider:Set(-99);assert(slider:Get()==16)
local main=slider.Instance:FindFirstChild('Main')
local track=main:FindFirstChild('Slider');local value=main:FindFirstChild('Value')
assert(track.Position.X.Scale==0.8075 and track.Size.X.Scale==0.345)
assert(value.Position.X.Scale==0.525,'Original numeric field position changed')
local originalPosition=track.Position;local originalSize=track.Size
local originalHeaderColor=w.Main:FindFirstChild('Top'):FindFirstChild('Color'):FindFirstChild('UIGradient').Color
assert(#UI:GetThemes()==10)
for _,theme in ipairs(UI:GetThemes()) do
    w:SetTheme(theme)
    assert(track.Position==originalPosition and track.Size==originalSize)
    assert(#w.Tabs==1)
end
w:SetTheme('Original')
local restored=w.Main:FindFirstChild('Top'):FindFirstChild('Color'):FindFirstChild('UIGradient').Color
assert(restored==originalHeaderColor,'Original palette not restored exactly')
local width=track.AbsoluteSize.X;local origin=track.AbsolutePosition.X
local touch=newInput('Touch',origin+width/2,0)
track.InputBegan:Fire(touch);assert(slider:Get()==58)
MOCK_INPUT.InputChanged:Fire(newInput('Touch',origin+width,0));assert(slider:Get()==58)
touch.Position=Vector3.new(origin+width,0,0);MOCK_INPUT.InputChanged:Fire(touch)
assert(slider:Get()==100)
MOCK_INPUT.InputEnded:Fire(touch)
local decimal=section:CreateSlider({Name='Decimal',Min=0,Max=10,Default=5,Step=0.1,AllowDecimals=true,DecimalPlaces=1})
decimal:Set(4.26);assert(math.abs(decimal:Get()-4.3)<1e-8)
-- Campo numerico original continua editavel.
value.Text='42';value.FocusLost:Fire();assert(slider:Get()==42)
assert(#section.Options==4)
local label=toggle.Instance:FindFirstChild('Label',true)
assert(label.TextScaled and label.FontFace[1]=='rbxasset://fonts/families/GothamSSm.json')
assert(w.Main.Size.X.Scale>0 and w.Main.Size.Y.Scale>0)
assert(w.Main:FindFirstChild('ResizeGrip'),'Original resize grip missing')
assert(w.Main:FindFirstChild('Top'):FindFirstChild('Close'),'Original close button missing')
w:SetVisible(false);drain(3);assert(w.Main.Position.Y.Scale==1.55)
w.Launcher:FindFirstChild('Chilli',true).Activated:Fire();drain(3)
assert(w.Main.Position.Y.Scale<1)
section:SetExpanded(false,false);drain(3);assert(section.Expanded==false)
section:SetExpanded(true,false);drain(3);assert(section.Expanded==true)

-- Button visual original, callback e metodos.
local presses=0
local action=section:CreateButton({Name='Action test',ButtonText='Run',Description='Original button',
    Callback=function() presses=presses+1 end})
local actionNode=action.Instance:FindFirstChild('Action',true)
assert(actionNode and actionNode.Position.X.Scale==0.8846889218690012)
assert(actionNode.Size.X.Scale==0.20062215626239776)
assert(actionNode:FindFirstChild('Main'):FindFirstChild('ColorFrame'))
actionNode.Activated:Fire();drain(3);assert(presses==1)
action:Press();drain(3);assert(presses==2)
assert(not pcall(function() action:Get() end))
assert(not pcall(function() action:Set(true) end))
assert(not pcall(function() toggle:Press() end))
action:SetNote('Updated');assert(action.Instance:FindFirstChild('Note',true).Text=='Updated')
-- Limite de paginas e ausencia de elementos parciais quando chega a seis.
local tabs={farm}
for index=2,5 do tabs[index]=w:CreateTab({Name='PAGE'..index}) end
assert(w:GetTabCount()==5 and #w:GetTabs()==5)
local before=#w.Gui:GetDescendants()
w.MaxTabs=99
local accepted,problem=pcall(function() w:CreateTab({Name='PAGE6'}) end)
assert(not accepted and tostring(problem):match('5 paginas'))
assert(w:GetTabCount()==5 and #w.Gui:GetDescendants()==before)
assert(not pcall(function() w:CreateTab({Name='PAGE2'}) end))
assert(not pcall(function() farm:Destroy() end))
local copy=w:GetTabs();table.remove(copy);assert(w:GetTabCount()==5)
local themeCopy=UI:GetThemes();themeCopy[1]='Fake';assert(UI:GetThemes()[1]=='Dark')
local otherSection=tabs[2]:CreateSection({Name='On second page'})
otherSection:CreateToggle({Name='Secondary'})
tabs[2]:Select();drain(4)
for _,page in ipairs(w:GetTabs()) do assert(page.Page.Visible==(page==tabs[2])) end
assert(w.SelectedTab==tabs[2])
tabs[2]:Destroy();drain(4)
assert(w:GetTabCount()==4 and w.SelectedTab==farm)
local newPage=w:CreateTab({Name='REPLACEMENT'})
assert(w:GetTabCount()==5 and newPage)
for index,page in ipairs(w:GetTabs()) do assert(page.Button.LayoutOrder==index) end
-- Regressoes visuais: cada tema deve chegar a todas as paginas e camadas dos botoes.
local originalTabGradient=farm.Button:FindFirstChild('ColorFrame',true):FindFirstChildOfClass('UIGradient').Color
local originalActionGradient=actionNode:FindFirstChild('ColorFrame',true):FindFirstChildOfClass('UIGradient').Color
local originalOff=switch:FindFirstChild('OFF').Transparency
local colors={
    Dark={{12,15,22},{141,166,210}}, Rose={{21,11,17},{227,151,178}},
    Roxo={{16,10,25},{182,145,231}}, Verde={{8,21,15},{125,200,155}},
    VermelhoEscuro={{25,8,12},{204,109,125}}, Azul={{9,17,30},{122,174,234}},
    Preto={{6,6,7},{186,188,197}}, Lilas={{19,14,29},{198,177,235}},
    Dourado={{25,20,10},{218,185,112}},
}
local white=Color3.fromRGB(255,255,255)
for _,theme in ipairs(UI:GetThemes()) do
    w:SetTheme(theme)
    for _,selectedPage in ipairs(w:GetTabs()) do
        selectedPage:Select();drain(2)
        for _,page in ipairs(w:GetTabs()) do
            assert(page.Page.Visible==(page==selectedPage))
            assert(page.Button:GetAttribute('MikotohSelected')==(page==selectedPage))
            local face=page.Button:FindFirstChild('ColorFrame',true)
            if theme=='Original' then
                assert(sameSequence(face:FindFirstChildOfClass('UIGradient').Color,originalTabGradient))
            else
                local background=Color3.fromRGB(table.unpack(colors[theme][1]))
                local accent=Color3.fromRGB(table.unpack(colors[theme][2]))
                assert(sameColor(w.Main.BackgroundColor3,background))
                assert(sameColor(page.Page.BackgroundColor3,background),'Theme missed page background')
                assert(sameColor(face.BackgroundColor3,white),'Gradient has double tint')
                local caption=face:FindFirstChild('Label')
                assert(sameColor(caption:FindFirstChild('TextStyleGradient').Color.Keypoints[1].Value,
                    page==selectedPage and accent or Color3.fromRGB(244,245,249)))
                assert(face:FindFirstChildOfClass('UIGradient').Color.Keypoints[1].Value.R<0.6,
                    'Page retained a bright original gradient')
                if page~=selectedPage then
                    assert(not sameColor(face:FindFirstChildOfClass('UIGradient').Color.Keypoints[1].Value,
                        selectedPage.Button:FindFirstChild('ColorFrame',true):FindFirstChildOfClass('UIGradient').Color.Keypoints[1].Value))
                end
                -- As camadas originais devem continuar diferentes: relevo e sombra.
                local outer=face:FindFirstChildOfClass('UIGradient').Color
                local inner=face:FindFirstChild('Transparent'):FindFirstChildOfClass('UIGradient').Color
                local base=page.Button:FindFirstChild('Main')
                assert(#outer.Keypoints==#originalTabGradient.Keypoints)
                for index,point in ipairs(outer.Keypoints) do assert(point.Time==originalTabGradient.Keypoints[index].Time) end
                assert(luminance(outer.Keypoints[1].Value)-luminance(base.BackgroundColor3)>0.08,'Bottom shadow disappeared')
                assert(luminance(outer.Keypoints[1].Value)-luminance(outer.Keypoints[#outer.Keypoints].Value)>0.04,'Face became flat')
                assert(not sameColor(outer.Keypoints[1].Value,inner.Keypoints[1].Value),'Inner bevel merged with outer face')
                assert(luminance(base:FindFirstChildOfClass('UIStroke').Color)<luminance(outer.Keypoints[#outer.Keypoints].Value),'Outline disappeared')
                local shine=caption:FindFirstChild('TextStyleGradient').Color
                assert(#shine.Keypoints==4 and shine.Keypoints[2].Time==0.486159176)
                assert(luminance(shine.Keypoints[1].Value)>luminance(shine.Keypoints[3].Value),'Text shine disappeared')
            end
        end
    end
    assert(switch:FindFirstChild('ON').Enabled==toggle:Get(),'Theme changed toggle state')
    assert(switch:FindFirstChild('OFF').Enabled~=toggle:Get())
    assert(hold.Position.X.Scale==(toggle:Get() and 0.72 or 0.28))
    if theme~='Original' then
        assert(actionNode:FindFirstChild('ColorFrame',true):FindFirstChildOfClass('UIGradient').Color.Keypoints[1].Value.R<0.4)
    end
end
-- Paginas, secoes e controles criados DEPOIS de escolher uma cor recebem o tema.
w:SetTheme('Rose');newPage:Destroy()
newPage=w:CreateTab({Name='AFTER_THEME'})
assert(sameColor(newPage.Page.BackgroundColor3,Color3.fromRGB(21,11,17)))
local futureSection=newPage:CreateSection({Name='Created under Rose'})
local futureButton=futureSection:CreateButton({Name='Future button'})
local futureFace=futureButton.Instance:FindFirstChild('Action',true):FindFirstChild('ColorFrame',true)
assert(futureFace:FindFirstChildOfClass('UIGradient').Color.Keypoints[1].Value.R<0.4)
for _,arm in ipairs(futureSection._arrow:GetChildren()) do
    local point=arm:FindFirstChildOfClass('UIGradient').Color.Keypoints[1].Value
    if arm:GetAttribute('MikotohRole')=='ArrowFace' then assert(sameColor(point,Color3.fromRGB(244,245,249)))
    else assert(point.R<0.1) end
end
newPage:Select();w:SetTheme('Original')
assert(sameSequence(farm.Button:FindFirstChild('ColorFrame',true):FindFirstChildOfClass('UIGradient').Color,originalTabGradient))
assert(sameSequence(actionNode:FindFirstChild('ColorFrame',true):FindFirstChildOfClass('UIGradient').Color,originalActionGradient))
assert(switch:FindFirstChild('OFF').Transparency==originalOff)
assert(toggle.Instance:FindFirstChild('Main').BackgroundTransparency==0.5)
assert(sameColor(newPage.Button:FindFirstChild('Main').BackgroundColor3,Color3.fromRGB(255,54,54)))
value.Focused:Fire();assert(value.BackgroundTransparency==0.42)
w:SetTheme('Rose');w:SetTheme('Original');assert(value.BackgroundTransparency==0.42)
value.FocusLost:Fire();assert(value.BackgroundTransparency==0.6)
-- Espaco positivo, recalculado sem ultrapassar a coluna em janelas pequenas.
local column=farm.Button.Parent
local tabLayout=column:FindFirstChildOfClass('UIListLayout')
local tabPadding=column:FindFirstChild('TabPadding')
local function assertFits()
    local sum=tabPadding.PaddingTop.Scale*column.AbsoluteSize.Y+tabPadding.PaddingTop.Offset
    assert(tabLayout.Padding.Offset>=6)
    for _,page in ipairs(w:GetTabs()) do sum=sum+page.Button.AbsoluteSize.Y end
    sum=sum+tabLayout.Padding.Offset*(w:GetTabCount()-1)
    assert(sum<=column.AbsoluteSize.Y,'Page buttons overflow the column')
end
assertFits()
column.AbsoluteSize=Vector2.new(120,100)
column:GetPropertyChangedSignal('AbsoluteSize'):Fire();assertFits()
column.AbsoluteSize=nil
column:GetPropertyChangedSignal('AbsoluteSize'):Fire();assertFits()
-- Dez temas, aliases e cores de unidades no slider.
w:SetTheme('vermelho escuro');assert(w.Theme=='VermelhoEscuro')
w:SetTheme('lilás');assert(w.Theme=='Lilas')
w:SetTheme('Original')
-- Botao flutuante: configuracao, toque, drag sem acionar e modo fixo.
local open=w.OpenButton
assert(open and open.Visible and w:GetOpenButtonOptions().Shape=='Round')
assert(open:FindFirstChildOfClass('UICorner').CornerRadius.Scale==0.5)
w:SetOpenButton({ImageId=12345,Shape='Square',Size=60,Draggable=false,Position=UDim2.fromOffset(120,120)})
assert(open:FindFirstChild('CustomIcon',true).Image=='rbxassetid://12345')
local icon=open:FindFirstChild('CustomIcon')
assert(icon.Parent==open and icon.Size==UDim2.fromScale(1,1))
assert(icon.ScaleType==Enum.ScaleType.Crop and open.ClipsDescendants)
assert(icon.Visible and not open:FindFirstChild('Main').Visible)
assert(sameColor(icon.ImageColor3,white),'Theme tinted the user image')
assert(open:FindFirstChildOfClass('UICorner').CornerRadius.Scale==0)
assert(icon:FindFirstChildOfClass('UICorner').CornerRadius.Scale==0)
w:SetOpenButton({Shape='Round'})
assert(icon:FindFirstChildOfClass('UICorner').CornerRadius.Scale==0.5)
w:SetOpenButton({Image='',Shape='Square'})
assert(not icon.Visible and open:FindFirstChild('Main').Visible)
assert(open:FindFirstChild('Label',true).Visible)
local fixed=open.Position
local press=newInput('MouseButton1',120,120)
open.InputBegan:Fire(press)
MOCK_INPUT.InputChanged:Fire(newInput('MouseMovement',200,200))
assert(open.Position==fixed,'Fixed open button moved')
MOCK_INPUT.InputEnded:Fire(press)
local visibility=w:IsVisible()
open.Activated:Fire(press);drain(3);assert(w:IsVisible()~=visibility)
w:SetVisible(true);drain(3)
w:SetOpenButton({Image='',Shape='Round',Draggable=true,Position=UDim2.fromOffset(120,120)})
local mouse=newInput('MouseButton1',120,120)
open.InputBegan:Fire(mouse)
MOCK_INPUT.InputChanged:Fire(newInput('MouseMovement',180,170))
MOCK_INPUT.InputEnded:Fire(mouse)
open.Activated:Fire(mouse);drain(2)
assert(w:IsVisible(),'Dragging open button closed the window')
assert(open.Position.X.Offset==180 and open.Position.Y.Offset==170)
local tap=newInput('Touch',180,170)
open.InputBegan:Fire(tap)
MOCK_INPUT.InputEnded:Fire(tap)
open.Activated:Fire(tap);drain(3);assert(not w:IsVisible())
-- Segundo toque nao move nem aciona enquanto o primeiro toca o botao.
local primary=newInput('Touch',180,170)
local unrelated=newInput('Touch',180,170)
open.InputBegan:Fire(primary);open.InputBegan:Fire(unrelated)
MOCK_INPUT.InputChanged:Fire(newInput('Touch',100,100))
assert(open.Position.X.Offset==180)
MOCK_INPUT.InputEnded:Fire(unrelated);open.Activated:Fire(unrelated)
assert(not w:IsVisible())
MOCK_INPUT.InputEnded:Fire(primary);open.Activated:Fire(primary);drain(3)
assert(w:IsVisible())
-- Posicao fora da tela e tamanho exagerado sao limitados.
w:SetOpenButton({Size=999,Position=UDim2.fromOffset(-999,-999)})
assert(w:GetOpenButtonOptions().Size==160)
assert(open.Position.X.Offset>=84 and open.Position.Y.Offset>=84)
assert(not pcall(function() w:SetOpenButton({Shape='Triangle'}) end))
assert(not pcall(function() w:SetOpenButton({Image='https://invalid'}) end))
assert(not pcall(function() w:SetOpenButton({Position='left'}) end))
w:SetOpenButton({Enabled=false});assert(not open.Visible and w.Launcher.Enabled)
w:SetOpenButton({Enabled=true});assert(open.Visible and not w.Launcher.Enabled)
-- Configuracao invalida nao destroi a janela atual nem cria uma interface parcial.
local beforeInvalid=#MOCK_CORE:GetDescendants()
assert(not pcall(function() UI:CreateWindow({Theme='Invalid'}) end))
assert(not w._destroyed and #MOCK_CORE:GetDescendants()==beforeInvalid)
assert(not pcall(function() UI:CreateWindow({OpenButton={Shape='Invalid'}}) end))
assert(not w._destroyed)

for _,gui in ipairs(MOCK_CORE:GetChildren()) do
    for _,instance in ipairs(gui:GetDescendants()) do
        assert(instance.Name~='Settings' and instance.Name~='Config' and instance.Name~='Quick g keys')
    end
end
w:Destroy();drain(3);assert(w.Gui._dead and w.Launcher._dead)
assert(UI.Window==nil and _G.MIKOTOH_UI_Window==nil)
for _,c in ipairs(MOCK_INPUT.InputChanged.connections) do assert(not c.Connected) end
for _,c in ipairs(MOCK_INPUT.InputEnded.connections) do assert(not c.Connected) end
local demo=assert(loadfile(root..'MIKOTOH_UI_TESTE.lua'))();drain(6)
assert(demo.Theme=='Dark' and #demo.Tabs==5 and #demo:GetDefaultTab().Sections==3)
assert(#demo:GetTab('TEMAS').Sections[1].Options==10)
local nextWindow=UI:CreateWindow({Theme='Rose'});drain(6)
assert(demo._destroyed and nextWindow.Theme=='Rose')
nextWindow.Gui:Destroy();drain(3)
assert(nextWindow._destroyed and nextWindow.Launcher._dead)

-- Comparacao de TODAS as cores/opacidades com uma janela criada em Original.
-- Cobre inicio em qualquer tema, objetos futuros e varias trocas consecutivas.
local function fixture(theme)
    local current=UI:CreateWindow({Name='RESTORE_CHECK',Theme=theme})
    local pages={current:GetDefaultTab(),current:CreateTab({Name='PAGE_A'}),current:CreateTab({Name='PAGE_B'})}
    for _,page in ipairs(pages) do
        local group=page:CreateSection({Name='Controls'})
        group:CreateToggle({Name='False',Default=false})
        group:CreateToggle({Name='True',Default=true,Description='Note'})
        group:CreateSlider({Name='Value',Min=0,Max=100,Default=38,Unit={Options={'m','km'}}})
        group:CreateButton({Name='Action',ButtonText='Run',ConfirmText=''})
    end
    pages[3]:Select();drain(6)
    return current
end
local function propertySnapshot(current)
    local result={}
    local function visit(parent,path)
        local counts={}
        for _,child in ipairs(parent:GetChildren()) do
            local name=child.ClassName..':'..child.Name
            counts[name]=(counts[name] or 0)+1
            local key=path..'/'..name..'#'..counts[name]
            local properties={}
            if child:IsA('GuiObject') then
                properties.BackgroundColor3=child.BackgroundColor3
                properties.BackgroundTransparency=child.BackgroundTransparency
            end
            if child:IsA('UIGradient') or child:IsA('UIStroke') then
                properties.Color,properties.Transparency=child.Color,child.Transparency
            end
            if child:IsA('TextLabel') or child:IsA('TextBox') or child:IsA('TextButton') then
                properties.TextColor3=child.TextColor3
                properties.TextStrokeColor3,properties.TextStrokeTransparency=child.TextStrokeColor3,child.TextStrokeTransparency
                properties.Text=child.Text
            end
            if child:IsA('ScrollingFrame') then properties.ScrollBarImageColor3=child.ScrollBarImageColor3 end
            if child:IsA('ImageLabel') or child:IsA('ImageButton') then
                properties.ImageColor3,properties.ImageTransparency=child.ImageColor3,child.ImageTransparency
            end
            result[key]=properties
            visit(child,key)
        end
    end
    visit(current.Gui,'Root');visit(current.Launcher,'Launcher')
    return result
end
local function equalValue(a,b)
    if typeof(a)=='Color3' then return typeof(b)=='Color3' and sameColor(a,b) end
    if typeof(a)=='ColorSequence' then return typeof(b)=='ColorSequence' and sameSequence(a,b) end
    if typeof(a)=='NumberSequence' then
        if typeof(b)~='NumberSequence' or #a.Keypoints~=#b.Keypoints then return false end
        for index,point in ipairs(a.Keypoints) do
            local other=b.Keypoints[index]
            if point.Time~=other.Time or point.Value~=other.Value or point.Envelope~=other.Envelope then return false end
        end
        return true
    end
    return a==b
end
local referenceWindow=fixture('Original')
local exactOriginal=propertySnapshot(referenceWindow)
referenceWindow:Destroy();drain(3)
for _,startingTheme in ipairs(UI:GetThemes()) do
    local current=fixture(startingTheme)
    for _,theme in ipairs({'Rose','Preto','Azul','Dourado','Original','Original'}) do current:SetTheme(theme);drain(2) end
    local actual=propertySnapshot(current)
    for path,properties in pairs(exactOriginal) do
        assert(actual[path],'Original lost an element: '..path)
        for name,value in pairs(properties) do
            assert(equalValue(value,actual[path][name]),'Original failed to restore '..path..'.'..name..' after starting in '..startingTheme)
        end
    end
    -- O cache original nao deve mudar quando outra pagina fica selecionada.
    local base=current:GetDefaultTab().Button:FindFirstChild('Main')
    assert(sameColor(current._baseline[base].Properties.BackgroundColor3,Color3.fromRGB(175,0,0)))
    current:SelectTab('FARM');current:SetTheme('Rose');current:SetTheme('Original')
    assert(sameColor(base.BackgroundColor3,Color3.fromRGB(255,54,54)))
    assert(sameColor(current._baseline[base].Properties.BackgroundColor3,Color3.fromRGB(175,0,0)))
    current:Destroy();drain(3)
end
print('PASS: original components; 10 themes with distinct shadow/bevel/shine layers; exact Original colors/opacities after every starting theme; inheritance; page gaps/cap; full-button image; controls; opener; cleanup.')
