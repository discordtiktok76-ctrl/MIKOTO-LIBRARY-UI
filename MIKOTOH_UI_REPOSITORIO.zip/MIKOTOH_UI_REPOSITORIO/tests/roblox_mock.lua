local all = {}
local jobs = {}
local function schedule(fn,...)
    local args=table.pack(...)
    table.insert(jobs,coroutine.create(function() fn(table.unpack(args,1,args.n)) end))
end
function drain(frames)
    for frame=1,frames or 12 do
        local queue=jobs;jobs={}
        for _,co in ipairs(queue) do
            local ok,err=coroutine.resume(co)
            if not ok then error(err) end
            if coroutine.status(co)~='dead' then table.insert(jobs,co) end
        end
    end
end
local function signal()
    local s={connections={}}
    function s:Connect(fn)
        local c={Connected=true,fn=fn}
        function c:Disconnect() self.Connected=false end
        table.insert(self.connections,c);return c
    end
    function s:Fire(...)
        for _,c in ipairs(self.connections) do if c.Connected then c.fn(...) end end
    end
    function s:Wait() coroutine.yield();return 1/60 end
    return s
end
math.clamp=function(x,lo,hi) return math.max(lo,math.min(hi,x)) end
math.round=function(x) return math.floor(x+0.5) end
table.find=function(t,v) for i,x in ipairs(t) do if x==v then return i end end end
table.clear=function(t) for k in pairs(t) do t[k]=nil end end
local VMT={}
VMT.__add=function(a,b) return Vector3.new(a.X+b.X,a.Y+b.Y,(a.Z or 0)+(b.Z or 0)) end
VMT.__sub=function(a,b) return Vector3.new(a.X-b.X,a.Y-b.Y,(a.Z or 0)-(b.Z or 0)) end
VMT.__mul=function(a,b)
    if type(a)=='number' then a,b=b,a end
    return Vector3.new(a.X*b,a.Y*b,(a.Z or 0)*b)
end
VMT.__index=function(a,k)
    if k=='Magnitude' then return math.sqrt(a.X*a.X+a.Y*a.Y+(a.Z or 0)^2) end
    if k=='Unit' then local m=math.sqrt(a.X*a.X+a.Y*a.Y+(a.Z or 0)^2);return Vector3.new(a.X/m,a.Y/m,(a.Z or 0)/m) end
end
Vector2={new=function(x,y) return setmetatable({X=x,Y=y,_type='Vector2'},VMT) end}
Vector3={new=function(x,y,z) return setmetatable({X=x,Y=y,Z=z or 0,_type='Vector3'},VMT) end}
UDim={new=function(s,o) return {Scale=s,Offset=o,_type='UDim'} end}
local udimMT={__eq=function(a,b)
    return a.X.Scale==b.X.Scale and a.X.Offset==b.X.Offset and a.Y.Scale==b.Y.Scale and a.Y.Offset==b.Y.Offset
end}
UDim2={new=function(xs,xo,ys,yo) return setmetatable({X=UDim.new(xs,xo),Y=UDim.new(ys,yo),_type='UDim2'},udimMT) end}
UDim2.fromScale=function(x,y) return UDim2.new(x,0,y,0) end
UDim2.fromOffset=function(x,y) return UDim2.new(0,x,0,y) end
local colorMT={}
function colorMT:ToHSV()
    local maximum=math.max(self.R,self.G,self.B);local minimum=math.min(self.R,self.G,self.B)
    local d=maximum-minimum;local h=0
    if d>0 then
        if maximum==self.R then h=((self.G-self.B)/d)%6
        elseif maximum==self.G then h=(self.B-self.R)/d+2
        else h=(self.R-self.G)/d+4 end
        h=h/6
    end
    return h, maximum==0 and 0 or d/maximum,maximum
end
function colorMT:ToHex() return string.format('%02x%02x%02x',math.floor(self.R*255),math.floor(self.G*255),math.floor(self.B*255)) end
colorMT.__index=colorMT
Color3={new=function(r,g,b) return setmetatable({R=r,G=g,B=b,_type='Color3'},colorMT) end}
Color3.fromRGB=function(r,g,b) return Color3.new(r/255,g/255,b/255) end
Color3.fromHSV=function(h,s,v)
    local i=math.floor(h*6);local f=h*6-i;local p=v*(1-s);local q=v*(1-f*s);local t=v*(1-(1-f)*s)
    local choices={{v,t,p},{q,v,p},{p,v,t},{p,q,v},{t,p,v},{v,p,q}}
    local c=choices[i%6+1];return Color3.new(c[1],c[2],c[3])
end
ColorSequenceKeypoint={new=function(t,v) return {Time=t,Value=v} end}
ColorSequence={new=function(a,b)
    if a._type=='Color3' then return {Keypoints={{Time=0,Value=a},{Time=1,Value=b or a}},_type='ColorSequence'} end
    return {Keypoints=a,_type='ColorSequence'}
end}
NumberSequenceKeypoint={new=function(t,v,e) return {Time=t,Value=v,Envelope=e or 0} end}
NumberSequence={new=function(x) return {Keypoints=type(x)=='table' and x or {{Time=0,Value=x},{Time=1,Value=x}},_type='NumberSequence'} end}
Font={new=function(...) return {...} end}
Rect={new=function(...) return {...} end}
BrickColor={new=function(value) return {Name=value} end}
local function cf(pos)
    return {Position=pos or Vector3.new(0,0,0),RightVector=Vector3.new(1,0,0),UpVector=Vector3.new(0,1,0),LookVector=Vector3.new(0,0,1)}
end
CFrame={new=function(v) return cf(type(v)=='table' and v or nil) end,Angles=function() return cf() end,lookAt=function(v) return cf(v) end}
TweenInfo={new=function(...) return {...} end}
Enum=setmetatable({}, {__index=function(t,k)
    local category=setmetatable({}, {__index=function(c,v) local n={Name=v,Value=10};rawset(c,v,n);return n end})
    rawset(t,k,category);return category
end})
local objectMT={}
local events={Activated=true,InputBegan=true,InputChanged=true,InputEnded=true,Destroying=true,
    MouseEnter=true,MouseLeave=true,MouseButton1Down=true,MouseButton1Up=true,Focused=true,FocusLost=true,
    DescendantAdded=true,ChildAdded=true,ChildRemoved=true,AncestryChanged=true}
local guiClasses={Frame=true,ScrollingFrame=true,TextLabel=true,TextBox=true,TextButton=true,ImageButton=true,ImageLabel=true,ViewportFrame=true}
objectMT.__index=function(self,k)
    if events[k] then
        local event=signal();rawset(self,k,event);return event
    end
    if k=='AbsoluteSize' then
        if self.ClassName=='ScreenGui' then return Vector2.new(1280,720) end
        if self.ClassName=='UIListLayout' then return Vector2.new(0,0) end
        local parent=self.Parent
        local ps=parent and parent.AbsoluteSize or Vector2.new(1280,720)
        return Vector2.new(self.Size.X.Scale*ps.X+self.Size.X.Offset,self.Size.Y.Scale*ps.Y+self.Size.Y.Offset)
    end
    if k=='AbsolutePosition' then
        local parent=self.Parent;local pp=parent and parent.AbsolutePosition or Vector2.new(0,0)
        local ps=parent and parent.AbsoluteSize or Vector2.new(1280,720);local size=self.AbsoluteSize
        return Vector2.new(pp.X+self.Position.X.Scale*ps.X+self.Position.X.Offset-size.X*self.AnchorPoint.X,
            pp.Y+self.Position.Y.Scale*ps.Y+self.Position.Y.Offset-size.Y*self.AnchorPoint.Y)
    end
    if k=='AbsoluteContentSize' then
        local size=0
        if self.Parent then for _,child in ipairs(self.Parent:GetChildren()) do
            if child:IsA('GuiObject') and child.Visible then size=size+child.AbsoluteSize.Y end
        end end
        return Vector2.new(0,size)
    end
    if k=='TextBounds' then
        local value=tostring(self.Text or '')
        if self.RichText then value=value:gsub('<[^>]+>','') end
        return Vector2.new(#value*7,20)
    end
    return objectMT[k]
end
function objectMT:IsA(class)
    return self.ClassName==class or class=='Instance'
        or (class=='GuiObject' and guiClasses[self.ClassName])
        or (class=='GuiButton' and (self.ClassName=='TextButton' or self.ClassName=='ImageButton'))
end
function objectMT:GetChildren()
    local children={};for _,obj in ipairs(all) do if obj.Parent==self and not obj._dead then children[#children+1]=obj end end
    return children
end
function objectMT:GetDescendants()
    local result={}
    local function visit(o) for _,child in ipairs(o:GetChildren()) do result[#result+1]=child;visit(child) end end
    visit(self);return result
end
function objectMT:FindFirstChild(name,recursive)
    for _,obj in ipairs(recursive and self:GetDescendants() or self:GetChildren()) do if obj.Name==name then return obj end end
end
function objectMT:FindFirstChildOfClass(class)
    for _,obj in ipairs(self:GetChildren()) do if obj:IsA(class) then return obj end end
end
function objectMT:FindFirstAncestorOfClass(class)
    local p=self.Parent;while p do if p:IsA(class) then return p end;p=p.Parent end
end
function objectMT:WaitForChild(name) return assert(self:FindFirstChild(name),'Missing child '..name) end
function objectMT:SetAttribute(k,v)
    self._attributes[k]=v
    if self._attrSignals[k] then self._attrSignals[k]:Fire() end
end
function objectMT:GetAttribute(k) return self._attributes[k] end
function objectMT:GetAttributeChangedSignal(k)
    self._attrSignals[k]=self._attrSignals[k] or signal();return self._attrSignals[k]
end
function objectMT:GetPropertyChangedSignal(k)
    self._signals[k]=self._signals[k] or signal();return self._signals[k]
end
function objectMT:IsFocused() return self._focused==true end
function objectMT:Destroy()
    if self._dead then return end
    self._dead=true;self.Destroying:Fire()
    for _,child in ipairs(self:GetChildren()) do child:Destroy() end
    self.Parent=nil
    for k,v in pairs(self) do
        if type(v)=='table' and v.connections then for _,c in ipairs(v.connections) do c:Disconnect() end end
    end
    for _,s in pairs(self._signals) do for _,c in ipairs(s.connections) do c:Disconnect() end end
end
function objectMT:Clone()
    local c=Instance.new(self.ClassName)
    for k,v in pairs(self) do if not k:match('^_') and k~='Parent' and type(v)~='function' and not(type(v)=='table' and v.connections) then c[k]=v end end
    return c
end
Instance={new=function(class)
    local obj=setmetatable({ClassName=class,Name=class,_instance=true,_attributes={},_signals={},_attrSignals={},
        Size=UDim2.fromOffset(100,100),Position=UDim2.fromOffset(0,0),AnchorPoint=Vector2.new(0,0),
        BackgroundColor3=Color3.new(1,1,1),TextColor3=Color3.new(0,0,0),Visible=true,Text='',
        Padding=UDim.new(0,0),AspectRatio=1,Rotation=0,TextSize=14,CanvasPosition=Vector2.new(0,0),
        Color=Color3.new(0,0,0),Transparency=0,ScrollingEnabled=true,Enabled=true},objectMT)
    all[#all+1]=obj;return obj
end}
typeof=function(x) return type(x)=='table' and (x._instance and 'Instance' or x._type) or type(x) end
local core=Instance.new('CoreGui')
local playerGui=Instance.new('PlayerGui')
local player={WaitForChild=function(self,name) assert(name=='PlayerGui');return playerGui end}
local UIS={InputChanged=signal(),InputEnded=signal(),InputBegan=signal(),WindowFocusReleased=signal(),TouchEnabled=false,
    KeyboardEnabled=true,MouseEnabled=true,GetFocusedTextBox=function() return nil end}
local rs={RenderStepped=signal(),Heartbeat=signal(),_bindings={}}
function rs:BindToRenderStep(name,priority,fn) self._bindings[name]=fn end
function rs:UnbindFromRenderStep(name) self._bindings[name]=nil end
local tween={Create=function(self,obj,info,props)
    local t={Completed=signal(),_cancelled=false}
    function t:Play()
        for k,v in pairs(props) do obj[k]=v end
        task.defer(function() if not self._cancelled then self.Completed:Fire() end end)
    end
    function t:Cancel() self._cancelled=true end
    return t
end}
local camera=Instance.new('Camera');camera.ViewportSize=Vector2.new(1280,720)
workspace={CurrentCamera=camera}
game={GameId=7709344486,GetService=function(self,name)
    if name=='Players' then return {LocalPlayer=player} end
    if name=='CoreGui' then return core end
    if name=='UserInputService' then return UIS end
    if name=='TweenService' then return tween end
    if name=='RunService' then return rs end
    if name=='GuiService' then return {GetGuiInset=function() return Vector2.new(0,0),Vector2.new(0,0) end} end
    error('Unexpected service '..name)
end}
task={spawn=schedule,defer=schedule,delay=function(seconds,fn,...) schedule(fn,...) end,wait=function() coroutine.yield() end}
warn=function(...) print(...) end
function newInput(kind,x,y) return {UserInputType=Enum.UserInputType[kind],UserInputState=Enum.UserInputState.Begin,Position=Vector3.new(x,y,0)} end
MOCK_INPUT=UIS
MOCK_RUN=rs
MOCK_CORE=core
